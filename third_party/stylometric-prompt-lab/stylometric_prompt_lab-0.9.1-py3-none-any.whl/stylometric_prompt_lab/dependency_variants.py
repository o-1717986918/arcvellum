"""Measured paragraph alternatives; cached counts never certify a whole new tree."""
from __future__ import annotations

import json
import re

from .dependency_scope import paragraph_rows, validate_scope
from .dependency_feedback import sha
from .dependency_metrics import analyze_dependencies
from .extended_metrics import extended_statistics
from .io import ContractError, digest
from .layout import OPEN_QUOTES
from .local_edit import _unique_object
from .metrics import measure, han_count
from .reporting import normalization_evidence

PLAN_SCHEMA = 'style-tree-variant-plan/v1'
LIBRARY_SCHEMA = 'style-tree-variant-library/v1'
VERSION = '0.1.0'


def balanced_single_paragraph(text):
    if not isinstance(text, str) or text != text.strip() or not han_count(text) or '\n' in text or '\r' in text:
        raise ContractError('variant must be one complete Chinese paragraph without exterior whitespace')
    pending = []
    for char in text:
        if char == '"' and pending and pending[-1] == '"':
            pending.pop()
        elif char in OPEN_QUOTES:
            pending.append(OPEN_QUOTES[char])
        elif char in set(OPEN_QUOTES.values()):
            if not pending or pending.pop() != char:
                raise ContractError('variant has mismatched supported double quotation marks')
    if pending:
        raise ContractError('variant has unclosed supported double quotation marks')


def render_variants(scope):
    original = scope['input_text'].split('## 唯一输出格式', 1)[0]
    replacements = {'你是现代中文叙事编辑。': '你是现代中文叙事编辑。为指定原段各写两个遵循同一全部参数的完整备选，返回下述JSON。',
                    '最多替换': '工具会从每个允许原段的备选中至多选一个，保留原段顺序及范围外原文。',
                    '输出完整所选段落': '每条备选独立成一个完整自然段，字符串内不写换行。',
                    '候选全文将重新解析': '组合后的全文会重新分词、计算完整MATTR并真实解析，不用缓存树冒充全文实测。',
                    '所有文风目标继续适用': '全部文风目标继续适用；外部组合选稿的效果另行记录。'}
    lines = []
    for line in original.splitlines():
        lines.append(next((new for prefix, new in replacements.items() if line.startswith(prefix)), line))
    selected = scope['allowed_paragraph_ids']
    lines += ['', '## 两种都遵循全部目标的备选',
              f"只为段落{','.join(map(str, selected))}各写A、B两条，共{2*len(selected)}条。其余原段由工具保留。",
              'A：在既有事实的动作、目的、手段及处置关系中，尝试自然的补充动作或从属关系，减少平行主干的碎句。',
              'B：用既有核查、认知及时间/条件关系组织句法层次，变换措辞；同样遵循原全部句段、对白、词性、MATTR、词频及树深目标。',
              '不要添加人物、事件或无关命令。两种备选都必须保留该段人物、行动、事实、因果和结果；人物、物件称谓和上下文要衔接。',
              '合并同一次发言的碎片引号并保持需要的对白正文；部分短句自然写成21–30汉字的完整关系句，避免把所有句子都拉长。',
              '指定LTP会测词到根的层级；逗号串联多个平行动词未必提高树深。不要自报或猜测标注器数值，交付文本即可。',
              '下面的分子需求逐项固定各自原分母，只是规划快照；共享分母会变，不把所有行作为同时成立的配额。',
              '| 指标 | 原全篇分母 | 保留范围分子/分母 | 原编辑范围分子/分母 | 替换范围分子快照 |',
              '| --- | --- | --- | --- | --- |']
    for item in scope['scoped_constraints']:
        bounds = item['replacement_numerator_interval_at_original_denominator']
        lines.append(f"| {item['group']}:{item['key']} | {item['whole_original_denominator']} | "
                     f"{item['kept_numerator']}/{item['kept_denominator']} | {item['original_edit_numerator']}/{item['original_edit_denominator']} | {bounds['min']}–{bounds['max']} |")
    lines += ['MATTR50必须对组合全文计算完整50词滑窗，不能由短段MATTR均值近似。', '',
              '## 唯一输出格式',
              '返回一个JSON对象，只含variants数组；每项必须且只能有paragraph_id整数、original_sha256原段哈希、variant为A或B、text完整单段正文字符串。',
              '每个指定段号A/B各一次，完整覆盖，不加代码围栏、计算、解释或自评。',
              '{"variants":[{"paragraph_id":指定段号,"original_sha256":"原段哈希","variant":"A","text":"完整备选段落"},{"paragraph_id":同段号,"original_sha256":"原段哈希","variant":"B","text":"另一完整备选段落"}]}', '']
    return '\n'.join(lines)


def prepare_variants(scope, corpus):
    validate_scope(scope, corpus)
    instruction = render_variants(scope)
    result = {'schema': PLAN_SCHEMA, 'version': VERSION, 'scope': scope,
              'scope_plan_sha256': scope['scope_plan_sha256'], 'labels': ['A', 'B'],
              'expected_batches': 2, 'input_text': instruction, 'input_sha256': sha(instruction),
              'web_modes': {'deep_think_pressed': 'true', 'web_search_pressed': 'false'}, 'experiment_design': 'target_only',
              'quality_status': 'unverified', 'length_in_gate': False,
              'selection_contract': 'independent pools and combined pool; all18 exact screening; final whole text requires new real parse'}
    result['variant_plan_sha256'] = digest(result)
    return result


def validate_variant_plan(plan, corpus):
    if plan.get('schema') != PLAN_SCHEMA or plan.get('variant_plan_sha256') != digest({k:v for k,v in plan.items() if k != 'variant_plan_sha256'}):
        raise ContractError('variant plan schema/hash differs')
    if prepare_variants(plan['scope'], corpus) != plan:
        raise ContractError('variant plan differs from full target source and scoped guidance')


def decode_variants(plan, response):
    payload = response.strip()
    match = re.fullmatch(r'```(?:json)?\s*\n(.*)\n```', payload, re.S)
    if match:
        payload = match.group(1).strip()
    try:
        value = json.loads(payload, object_pairs_hook=_unique_object)
    except json.JSONDecodeError as exc:
        raise ContractError('variant response must be JSON only') from exc
    if not isinstance(value, dict) or set(value) != {'variants'} or not isinstance(value['variants'], list):
        raise ContractError('variant response requires only a variants array')
    indexed = {r['paragraph_id']: r for r in plan['scope']['paragraphs']}
    expected = {(key, label) for key in plan['scope']['allowed_paragraph_ids'] for label in plan['labels']}
    seen, rows = set(), []
    for row in value['variants']:
        if not isinstance(row, dict) or set(row) != {'paragraph_id', 'original_sha256', 'variant', 'text'}:
            raise ContractError('variant has unexpected fields')
        key, label = row['paragraph_id'], row['variant']
        if type(key) is not int or not isinstance(label, str) or (key,label) not in expected or (key,label) in seen:
            raise ContractError('variant id/label is duplicated or outside frozen scope')
        if row['original_sha256'] != indexed[key]['original_sha256']:
            raise ContractError('variant has stale original paragraph hash')
        balanced_single_paragraph(row['text'])
        seen.add((key,label));rows.append(row)
    if seen != expected:
        raise ContractError('variant response does not cover every planned paragraph and label')
    return {'variants': sorted(rows,key=lambda r:(r['paragraph_id'],r['variant'])),
            'raw_response_sha256': sha(response), 'payload_sha256': sha(payload), 'fence_removed': bool(match)}


def variant_counts(text, parsed, base):
    if parsed.get('text') != text or parsed.get('text_sha256') != sha(text):
        raise ContractError('variant real parse belongs to a different paragraph')
    if parsed.get('annotator') != base['initial_parse']['annotator'] or parsed.get('annotation_scheme') != base['initial_parse']['annotation_scheme']:
        raise ContractError('variant parser/model/annotation provenance differs from source')
    analysis = analyze_dependencies(parsed)
    p = base['prompt']
    evidence = normalization_evidence(measure(text), extended_statistics(text), p['targets'], p['secondary_targets'], p['lexical_targets'])
    counts = {f'{group}:{key}': row for group in ('primary','secondary','lexical') for key,row in evidence[group].items() if key != 'word_mattr_50'}
    for key in p['dependency_targets']:
        item = analysis['summary']['metrics'][key]
        counts[f'dependency:{key}'] = {'numerator':item['numerator'],'denominator':item['denominator'],'scale':1}
    return counts, analysis['analysis_hash']


def build_variant_library(plan, batches, parses, corpus):
    validate_variant_plan(plan, corpus)
    if any(not isinstance(b, dict) or set(b) != {'job_id', 'response'} or
           not isinstance(b['job_id'], str) or not re.fullmatch(r'[A-Z][0-9]{3}', b['job_id']) or
           not isinstance(b['response'], str) for b in batches):
        raise ContractError('library requires explicit job identities and original response strings')
    if len(batches) != plan['expected_batches'] or len({b['job_id'] for b in batches}) != len(batches):
        raise ContractError('library batch count or identities differ')
    base = plan['scope']['joint_guidance']['base_feedback_plan']
    original = paragraph_rows(base)
    rows = [{'candidate_id': f"source:{r['paragraph_id']}", 'paragraph_id':r['paragraph_id'], 'batch_id':'source',
             'text':r['text'],'text_sha256':sha(r['text']),'counts':r['counts'],
             'source_tree':{'kind':'span_of_existing_full_source_parse','parse_hash':base['initial_parse']['parse_hash'],'sentence_ids':r['sentence_ids']}}
            for r in original]
    observed = []
    for batch in batches:
        decoded = decode_variants(plan, batch['response'])
        observed.append({'job_id':batch['job_id'], 'response':batch['response'], **decoded})
        for row in decoded['variants']:
            candidate_id = f"{batch['job_id']}:{row['paragraph_id']}:{row['variant']}"
            if candidate_id not in parses:
                raise ContractError('missing real candidate paragraph parse')
            parsed = parses[candidate_id]
            counts, analysis_hash = variant_counts(row['text'],parsed,base)
            rows.append({'candidate_id':candidate_id,'paragraph_id':row['paragraph_id'],'batch_id':batch['job_id'],
                         'variant':row['variant'],'text':row['text'],'text_sha256':sha(row['text']),'counts':counts,
                         'parsed':parsed,'analysis_hash':analysis_hash})
    expected = {r['candidate_id'] for r in rows if r['batch_id'] != 'source'}
    if set(parses) != expected:
        raise ContractError('candidate parse identities are missing or extraneous')
    result = {'schema':LIBRARY_SCHEMA,'version':VERSION,'plan':plan,'batches':observed,'candidates':rows,
              'model_manifest_hash':base['initial_parse']['annotator']['model_manifest_hash'],
              'measurement_policy':'additive paragraph counts and cached trees are provisional; full MATTR and final new parse required',
              'quality_status':'unverified'}
    result['library_sha256'] = digest(result)
    return result


def validate_variant_library(library, corpus):
    if library.get('schema') != LIBRARY_SCHEMA or library.get('library_sha256') != digest({k:v for k,v in library.items() if k != 'library_sha256'}):
        raise ContractError('variant library schema/hash differs')
    batches = [{'job_id':b['job_id'], 'response':b['response']} for b in library['batches']]
    parses = {r['candidate_id']:r['parsed'] for r in library['candidates'] if r['batch_id'] != 'source'}
    rebuilt = build_variant_library(library['plan'],batches,parses,corpus)
    if rebuilt != library:
        raise ContractError('variant library differs from actual paragraph/tree counts')

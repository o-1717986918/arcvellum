"""Explicit experiment arms; target-only is the default for new trials."""

from .io import ContractError


TARGET_ONLY = "target_only"
PAIRED_ARMS = ("baseline", "target")


def selected_arms(arms=("target",)) -> tuple[str, ...]:
    value = tuple(arms)
    if value not in (("target",), PAIRED_ARMS):
        raise ContractError("arms must be target only or explicit baseline/target pair")
    return value


def mark_design(value: dict, arms) -> dict:
    if selected_arms(arms) == ("target",):
        value["experiment_design"] = TARGET_ONLY
        value.pop("same_metric_filter_both_arms", None)
    return value


def validate_design(value: dict) -> None:
    design = value.get("experiment_design")
    if design is not None and design != TARGET_ONLY:
        raise ContractError("unsupported experiment design")
    rows = value.get("jobs", value.get("runs", []))
    if design == TARGET_ONLY and (not rows or any(row.get("arm") != "target" for row in rows)):
        raise ContractError("target-only design cannot contain baseline or missing jobs")


def local_target_gate() -> dict:
    return {"gate_version": "target_only_direct_v1", "all_planned_calls_completed": True,
            "target_accepted_patches_min": 1, "target_primary_all_in_range": True,
            "all_control_metrics_nonworse_vs_initial": True,
            "max_target_longest_shared_han": 24}


def require_selected_jobs(value: dict, *, paired: bool = False) -> None:
    """Do not resume an ordinary arm just because an old artifact contains it."""
    rows = value.get("jobs", value.get("runs", []))
    if not paired and any(row.get("arm") == "baseline" for row in rows):
        raise ContractError("默认只运行参数组；旧双组输入须显式 --arms paired。新试验使用参数组单组输入。")

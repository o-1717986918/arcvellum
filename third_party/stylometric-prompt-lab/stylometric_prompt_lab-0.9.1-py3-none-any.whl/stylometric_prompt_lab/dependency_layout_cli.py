"""Public plan/evaluate entry for explicit, tree-verified paragraph layout."""
from __future__ import annotations

import argparse
from pathlib import Path

from .corpus import load_corpus
from .dependency_feedback import render_result
from .dependency_layout import PLAN_SCHEMA, adjudicate_layout, prepare_layout
from .io import ContractError, read_object, write_object, write_text


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["plan", "evaluate"])
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--parse", type=Path)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.out.exists():
            raise ContractError("tree layout output already exists")
        corpus = load_corpus(args.corpus)
        if args.phase == "plan":
            result = prepare_layout(read_object(args.plan, "style-dependency-feedback-plan/v1"), corpus)
            write_object(args.out / "layout-plan.json", result)
            write_text(args.out / "candidate.txt", result["candidate_text"])
        else:
            if not args.parse:
                raise ContractError("layout evaluation requires --parse for candidate")
            result = adjudicate_layout(read_object(args.plan, PLAN_SCHEMA),
                                       read_object(args.parse, "style-dependency-parse/v1"), corpus)
            write_object(args.out / "layout-result.json", result)
            write_text(args.out / "assessment.md", render_result(result["assessment"]))
    except ContractError as error:
        parser.exit(2, f"error: {error}\n")
    print(args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

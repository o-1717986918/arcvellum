"""Offline public compiler for exact shared-denominator feedback guidance."""
from __future__ import annotations

import argparse
from pathlib import Path

from .construction_budget import compile_joint
from .corpus import load_corpus
from .dependency_feedback import PLAN_SCHEMA
from .io import ContractError, read_object, write_object, write_text


def main(argv=None):
    parser = argparse.ArgumentParser(description="从全目标反馈和真实句式库编译联动指导")
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.out.exists():
            raise ContractError("joint guidance output already exists")
        result = compile_joint(read_object(args.plan, PLAN_SCHEMA),
                               read_object(args.library, "style-dependency-examples/v1"), load_corpus(args.corpus))
        write_object(args.out / "joint-guidance.json", result)
        write_object(args.out / "feedback-plan.json", result["base_feedback_plan"])
        write_text(args.out / "feedback.txt", result["feedback_text"])
    except ContractError as error:
        parser.exit(2, f"error: {error}\n")
    print(result["joint_guidance_sha256"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

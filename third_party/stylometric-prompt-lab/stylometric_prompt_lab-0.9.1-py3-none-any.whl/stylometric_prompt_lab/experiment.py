"""Paired, blinded Pi Worker generation experiments."""

from __future__ import annotations

import csv
import hashlib
import io
import random
from typing import Any

from .corpus import Corpus, HAN
from .io import ContractError, digest
from .experiment_design import PAIRED_ARMS, mark_design, selected_arms
from .pi import PiWorker
from .structured_output import FORMAT as PARAGRAPH_JSON_FORMAT, assemble_paragraph_json


BASELINE_SYSTEM = (
    "你是现代中文叙事写作者。按用户给出的场景、人物和事实写原创、完整、自然的正文。"
    "优先保证事件因果、人物逻辑与清晰表达。只输出正文。"
)


def baseline_system(prompt: dict[str, Any], policy: str = "legacy") -> str:
    if policy == "legacy":
        return BASELINE_SYSTEM
    if policy != "length_matched":
        raise ContractError("baseline policy must be legacy or length_matched")
    structure = prompt.get("derived_structure") or {}
    if structure.get("length_policy") == "descriptive_only":
        raise ContractError("length_matched baseline is inapplicable to descriptive-only length policy")
    target = int(structure.get("target_han", 750))
    lower = int(structure.get("min_han", round(target * .8)))
    upper = int(structure.get("max_han", round(target * 1.2)))
    return (BASELINE_SYSTEM + f"\n正文以约 {target} 汉字为中心，严格落在 {lower}–{upper} 汉字内；"
            "输出前核对篇幅并删去重复解释。")


def comparison_baseline(target_prompt: dict[str, Any], other: dict[str, Any]) -> str:
    if (other.get("schema") != "literary-style-prompt/v1" or
            other.get("profile_sha256") != target_prompt.get("profile_sha256") or
            other.get("controls_sha256") != target_prompt.get("controls_sha256") or
            other.get("targets") != target_prompt.get("targets") or
            other.get("secondary_targets") != target_prompt.get("secondary_targets") or
            other.get("lexical_targets") != target_prompt.get("lexical_targets") or
            any((other.get("derived_structure") or {}).get(key) !=
                (target_prompt.get("derived_structure") or {}).get(key)
                for key in ("target_han", "min_han", "max_han")) or
            other.get("prompt_artifact_sha256") != digest({key: value for key, value in other.items()
                                                           if key != "prompt_artifact_sha256"}) or
            hashlib.sha256(str(other.get("prompt_markdown") or "").encode("utf-8")).hexdigest() !=
            other.get("prompt_sha256")):
        raise ContractError("comparison baseline must be an intact prompt with the same profile and targets")
    return str(other["prompt_markdown"])
DEFAULT_ACCEPTANCE = {
    "min_pairs": 6, "min_improved_pairs_per_axis": 4,
    "require_lower_mean_distance_each_axis": True,
    "min_human_rated_per_arm": 6,
    "min_target_content_and_naturalness": 4.0,
    "max_human_mean_drop": 0.5,
    "max_target_longest_shared_han": 24,
}


def validate_cases(value: dict[str, Any]) -> list[dict[str, str]]:
    if value.get("schema") != "style-cases/v1" or not isinstance(value.get("cases"), list):
        raise ContractError("cases must have schema style-cases/v1 and cases list")
    cases: list[dict[str, str]] = []
    ids: set[str] = set()
    for row in value["cases"]:
        if not isinstance(row, dict):
            raise ContractError("each case must be an object")
        case_id, topic, brief = (str(row.get(key) or "").strip() for key in ("case_id", "topic", "brief"))
        if not case_id or not topic or len(brief) < 20 or case_id in ids:
            raise ContractError("cases need unique IDs, topic, and a brief of at least 20 characters")
        ids.add(case_id)
        cases.append({"case_id": case_id, "topic": topic, "brief": brief})
    if not cases:
        raise ContractError("cases must not be empty")
    return cases


def _han_string(text: str) -> str:
    return "".join(HAN.findall(text))


def copy_risk(candidate: str, sources: Corpus) -> dict[str, Any]:
    chars = _han_string(candidate)
    grams = {chars[i:i + 12] for i in range(max(0, len(chars) - 11))}
    source_chars = [_han_string(item.text) for item in sources.sources]
    known = {gram for gram in grams if any(gram in body for body in source_chars)}
    overlap = len(grams & known) / len(grams) if grams else 0.0
    longest = 0
    for body in source_chars:
        for start in range(max(0, len(chars) - 11)):
            if chars[start:start + 12] not in known:
                continue
            required = max(12, longest + 1)
            if len(chars) - start < required or chars[start:start + required] not in body:
                continue
            end = start + required
            while end < len(chars) and chars[start:end + 1] in body:
                end += 1
            longest = max(longest, end - start)
    return {"shared_12gram_share": round(overlap, 4), "longest_shared_han": longest,
            "compared_source_count": len(source_chars)}


def _validate_inputs(profile: dict[str, Any], prompt: dict[str, Any], corpus: Corpus,
                     repetitions: int) -> None:
    if profile.get("schema") != "stylometric-profile/v1" or prompt.get("schema") != "literary-style-prompt/v1":
        raise ContractError("experiment needs versioned profile and prompt")
    if prompt.get("profile_sha256") != profile.get("profile_sha256"):
        raise ContractError("prompt belongs to a different profile")
    if profile.get("profile_sha256") != digest({key: value for key, value in profile.items()
                                                if key != "profile_sha256"}):
        raise ContractError("profile hash does not match its contents")
    if hashlib.sha256(str(prompt.get("prompt_markdown") or "").encode("utf-8")).hexdigest() != prompt.get("prompt_sha256"):
        raise ContractError("prompt hash does not match its contents")
    if prompt.get("prompt_artifact_sha256") != digest({key: value for key, value in prompt.items()
                                                       if key != "prompt_artifact_sha256"}):
        raise ContractError("prompt artifact hash does not match its contents")
    if prompt.get("response_format") not in (None, PARAGRAPH_JSON_FORMAT):
        raise ContractError("unsupported prompt response_format")
    if profile.get("source_digest") != digest([item.public() for item in corpus.sources]):
        raise ContractError("corpus differs from the profile sources")
    if repetitions < 1 or repetitions > 10:
        raise ContractError("repetitions must be between 1 and 10")


def run_experiment(profile: dict[str, Any], prompt: dict[str, Any], corpus: Corpus,
                   cases_value: dict[str, Any], worker: PiWorker, *, repetitions: int = 2,
                   seed: int = 20260928, baseline_policy: str = "legacy",
                   baseline_prompt: dict[str, Any] | None = None,
                   arms: tuple[str, ...] = ("target",)) -> dict[str, Any]:
    _validate_inputs(profile, prompt, corpus, repetitions)
    arms = selected_arms(arms)
    if arms != PAIRED_ARMS and (baseline_prompt is not None or baseline_policy != "legacy"):
        raise ContractError("baseline options require explicit paired arms")
    if baseline_prompt is not None and baseline_policy != "legacy":
        raise ContractError("baseline_prompt and baseline_policy cannot be combined")
    baseline = (comparison_baseline(prompt, baseline_prompt) if baseline_prompt is not None else
                baseline_system(prompt, baseline_policy))
    cases = validate_cases(cases_value)
    rng = random.Random(seed)
    jobs = [(case, repetition, arm) for case in cases for repetition in range(1, repetitions + 1)
            for arm in arms]
    rng.shuffle(jobs)
    worker_version = ""
    runs: list[dict[str, Any]] = []
    stopped_reason = ""
    try:
        worker_version = worker.version()
    except RuntimeError as exc:
        stopped_reason = f"worker version probe failed: {exc}"
    pending_jobs = jobs if not stopped_reason else []
    structure = prompt.get("derived_structure") or {}
    length_free = structure.get("length_policy") == "descriptive_only"
    lower = int(structure.get("min_han", 600)) if not length_free else None
    upper = int(structure.get("max_han", 900)) if not length_free else None
    for number, (case, repetition, arm) in enumerate(pending_jobs, 1):
        system = baseline if arm == "baseline" else str(prompt["prompt_markdown"])
        user_prompt = (case["brief"] + "\n写一个完整的现代中文叙事场景；篇幅由事件需要决定。"
                       if length_free else case["brief"] + f"\n写约 {lower}–{upper} 汉字的现代中文叙事场景。")
        result = worker.run(system, user_prompt)
        answer, status, failure = result.answer, result.status, result.failure
        parse_info = None
        if arm == "target" and prompt.get("response_format") == PARAGRAPH_JSON_FORMAT and status == "completed":
            try:
                answer, parse_info = assemble_paragraph_json(result.answer)
            except ContractError as exc:
                answer, status, failure = "", "failed", str(exc)
        row = {
            "blind_id": f"B{number:03d}", "case_id": case["case_id"], "topic": case["topic"],
            "repetition": repetition, "arm": arm, "status": status,
            "answer": answer, "failure": failure,
            "system_prompt_sha256": hashlib.sha256(system.encode("utf-8")).hexdigest(),
            "user_prompt_sha256": hashlib.sha256(user_prompt.encode("utf-8")).hexdigest(),
            "worker_version": result.worker_version or worker_version, "model": result.model,
            "model_version": getattr(worker, "model_version", "unreported"),
            "events": list(result.events),
            "copy_risk": copy_risk(answer, corpus) if answer else None,
        }
        if arm == "target" and prompt.get("response_format") == PARAGRAPH_JSON_FORMAT:
            row["response_format"] = PARAGRAPH_JSON_FORMAT
            row["raw_answer"] = result.answer
            row["raw_answer_sha256"] = hashlib.sha256(result.answer.encode("utf-8")).hexdigest()
            row["response_parse"] = parse_info
        runs.append(row)
        failure_lower = result.failure.lower()
        if result.status != "completed" and any(word in failure_lower for word in
                                                ("not authenticated", "not available", "quota", "authentication")):
            stopped_reason = result.failure
            break
    experiment = {
        "schema": "style-experiment/v1", "profile_sha256": profile["profile_sha256"],
        "prompt_sha256": prompt["prompt_sha256"], "cases_sha256": digest(cases_value),
        "worker_version": worker_version, "model": worker.model,
        "model_version": getattr(worker, "model_version", "unreported"),
        "seed": seed, "repetitions": repetitions, "planned_run_count": len(jobs),
        "acceptance": dict(DEFAULT_ACCEPTANCE),
        "completed_run_count": sum(row["status"] == "completed" for row in runs),
        "stopped_reason": stopped_reason, "cases": cases, "runs": runs,
        "warnings": list(dict.fromkeys([*corpus.warnings, *(profile.get("warnings") or [])])),
    }
    if baseline_policy != "legacy":
        experiment["baseline_policy"] = baseline_policy
    if baseline_prompt is not None:
        experiment["baseline_prompt_sha256"] = baseline_prompt["prompt_sha256"]
        experiment["baseline_prompt_artifact_sha256"] = baseline_prompt["prompt_artifact_sha256"]
    if prompt.get("response_format"):
        experiment["target_response_format"] = prompt["response_format"]
    mark_design(experiment, arms)
    if arms == ("target",):
        experiment["acceptance"] = None
        experiment["thinking"] = getattr(worker, "thinking", "unreported")
    return experiment


def blind_packet(experiment: dict[str, Any], prompt: dict[str, Any]) -> str:
    lines = ["# 盲评包", "", "请在 ratings.csv 中对每篇正文分别填写目标风格贴合、内容保持与自然度（1–5）。不要从文风特征猜测生成方案。", "",
             "目标风格范围（供盲评参考）：", ""]
    for key, target in prompt["targets"].items():
        lines.append(f"- {key}: {target['min']:g}–{target['max']:g} {target['unit']}")
    for key, target in (prompt.get("secondary_targets") or {}).items():
        lines.append(f"- {key}: {target['min']:g}–{target['max']:g} {target['unit']}")
    for target in prompt.get("lexical_targets") or []:
        lines.append(f"- 高频语法词「{target['word']}」: {target['min']:g}–{target['max']:g} {target['unit']}")
    lines.append("")
    for row in sorted(experiment["runs"], key=lambda item: (item["case_id"], item["repetition"], item["blind_id"])):
        if row["status"] != "completed":
            continue
        lines.extend([f"## {row['case_id']} · 第 {row['repetition']} 轮 · {row['blind_id']}", "",
                      next(case["brief"] for case in experiment["cases"] if case["case_id"] == row["case_id"]),
                      "", row["answer"], ""])
    # Model output sometimes contains Markdown hard-break spaces. Keep the raw
    # answer in experiment.json, but remove line-end padding in review packets.
    return "\n".join(line.rstrip(" \t") for line in "\n".join(lines).split("\n"))


def ratings_template(experiment: dict[str, Any]) -> str:
    stream = io.StringIO(newline="")
    writer = csv.writer(stream)
    writer.writerow(["blind_id", "style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5", "notes"])
    for row in sorted(experiment["runs"], key=lambda item: item["blind_id"]):
        if row["status"] == "completed":
            writer.writerow([row["blind_id"], "", "", "", ""])
    return stream.getvalue()

"""Bind a provisional finite-pool selection to a fresh complete candidate tree."""
from .dependency_feedback import adjudicate, sha
from .io import ContractError, digest
from .tree_candidate_selection import select_candidates


def evaluate_selection(library, selection, parsed, corpus):
    if selection.get('selection_sha256') != digest({k:v for k,v in selection.items() if k != 'selection_sha256'}):
        raise ContractError('candidate selection hash differs')
    replay = select_candidates(library, selection['batches'], corpus, selection['mode'], selection['node_budget'])
    if replay != selection or selection['candidate'] is None:
        raise ContractError('candidate selection differs from deterministic search or has no candidate')
    candidate = selection['candidate']
    if parsed is None or parsed.get('text') != candidate['text'] or parsed.get('text_sha256') != sha(candidate['text']):
        raise ContractError('selection requires a fresh complete parse of this assembled candidate')
    base = library['plan']['scope']['joint_guidance']['base_feedback_plan']
    final = adjudicate(base, candidate['text'], parsed, corpus)
    predicted = {(r['group'],r['key']):r for r in candidate['metric_inventory']}
    checks = [{'group':r['group'],'key':r['key'],'cached_basis':predicted[r['group'],r['key']]['basis'],
               'actual_full_basis':r['basis'],'counts_agree':predicted[r['group'],r['key']]['basis']==r['basis']}
              for r in final['metric_inventory']]
    result = {'schema':'style-tree-candidate-evaluation/v1','version':'0.1.0',
              'selection_sha256':selection['selection_sha256'],'library_sha256':library['library_sha256'],
              'candidate_parse_hash':parsed['parse_hash'],'result':final,'cached_vs_complete_checks':checks,
              'all_cached_counts_agree':all(r['counts_agree'] for r in checks),
              'measurement_policy':'actual new full-text counts are authoritative; cached predictions never certify acceptance',
              'quality_status':'unverified','prompt_only_control_evidence':False}
    result['evaluation_sha256'] = digest(result)
    return result

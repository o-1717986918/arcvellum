"""Exact integer composition screening of editable and immutable paragraphs.

Witnesses are count allocations, not natural language or sufficiency proofs.
MATTR and all surface features must still be remeasured on a real candidate.
"""

from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import json
from math import ceil, floor

from .count_feedback import ledger, ratio_interval, tokenizer_provenance
from .io import ContractError
from .local_edit import paragraph_index, sha


VERSION, SCHEMA = "0.1.0", "style-paragraph-balance/v1"


def compact(text, prompt):
    evidence, functions = ledger(text)
    pos = evidence["coarse_pos_counts"]
    return {"han": evidence["han_count"], "word_han": evidence["tokenized_han_count"],
            "tokens": evidence["word_token_count"], "function": evidence["function_token_count"],
            "n": pos.get("n", 0), "v": pos.get("v", 0), "a": pos.get("a", 0),
            "controlled": {band["word"]: functions[band["word"]] for band in prompt.get("lexical_targets", [])}}


def integer_band(total, band, scale=1):
    return ceil(Fraction(str(band["min"])) * total / scale), floor(Fraction(str(band["max"])) * total / scale)


def count_witness(fixed, word_han, tokens, prompt, *, preferred=None):
    """Solve disjoint n/v/a/function/other counts, with controlled-word floors."""
    bands = prompt["secondary_targets"]
    if not Fraction(str(bands["word_length_mean_han"]["min"])) <= Fraction(word_han, tokens) <= Fraction(str(bands["word_length_mean_han"]["max"])):
        return None
    capacity = tokens - fixed["tokens"]
    if capacity < 0:
        return None
    lexical = {}
    for band in prompt.get("lexical_targets", []):
        low, high = integer_band(tokens, band, 1000)
        count = fixed["controlled"][band["word"]]
        if high < count:
            return None
        lexical[band["word"]] = [max(0, low - count), high - count]
    f_low, f_high = integer_band(tokens, bands["function_pos_share_proxy"])
    functions = max(f_low, fixed["function"] + sum(row[0] for row in lexical.values()))
    if functions > min(f_high, fixed["function"] + capacity):
        return None
    other = fixed["tokens"] - fixed["n"] - fixed["v"] - fixed["a"] - fixed["function"]
    verb_domain = range(fixed["v"], fixed["v"] + capacity + 1)
    for verbs in sorted(verb_domain, key=lambda v: (abs(v - preferred["v"]), v)) if preferred else verb_domain:
        nouns = ratio_interval(0, 1, verbs, 1, bands["nominality_n_over_n_plus_v"],
                               (fixed["n"], fixed["n"] + capacity))
        adjectives = ratio_interval(verbs, 0, verbs, 1, bands["activity_v_over_v_plus_a"],
                                    (fixed["a"], fixed["a"] + capacity))
        if nouns is None or adjectives is None or verbs + nouns[0] == 0 or verbs + adjectives[0] == 0:
            continue
        n = max(nouns[0], min(nouns[1], preferred["n"])) if preferred else nouns[0]
        a = max(adjectives[0], min(adjectives[1], preferred["a"])) if preferred else adjectives[0]
        f = max(functions, min(f_high, preferred["function"])) if preferred else functions
        if n + verbs + a + f + other > tokens:
            n, a, f = nouns[0], adjectives[0], functions
        required = n + verbs + a + f + other
        if required <= tokens:
            return {"total_tokens": tokens, "word_han": word_han, "n": n, "v": verbs,
                    "a": a, "function": f, "other": other + tokens - required,
                    "edited_tokens": capacity, "edited_controlled_ranges": lexical,
                    "scope": "count allocation only; no words, MATTR or semantic feasibility proven"}
    return None


def intervals(values):
    rows = []
    for value in values:
        if rows and value == rows[-1][1] + 1:
            rows[-1][1] = value
        else:
            rows.append([value, value])
    return rows


def scenario(fixed, word_han, prompt, edited_paragraphs, preferred):
    band = prompt["secondary_targets"]["word_length_mean_han"]
    low = max(fixed["tokens"] + edited_paragraphs, ceil(Fraction(word_han) / Fraction(str(band["max"]))))
    high = min(word_han, floor(Fraction(word_han) / Fraction(str(band["min"]))))
    witnesses = [row for tokens in range(low, high + 1)
                 if (row := count_witness(fixed, word_han, tokens, prompt, preferred=preferred)) is not None]
    closest = min(witnesses, key=lambda row: (abs(row["total_tokens"] - preferred["tokens"]), row["total_tokens"])) if witnesses else None
    return {"assumed_full_word_han": word_han, "candidate_token_domain": [low, high],
            "compatible_token_intervals": intervals([row["total_tokens"] for row in witnesses]),
            "compatible_token_count": len(witnesses), "count_witness_near_current": closest,
            "assumption": "fixed remaining counts, edited tokens can take any disjoint coarse category"}


def additive(full, fixed, selected):
    keys = ("han", "word_han", "tokens", "function", "n", "v", "a")
    return all(full[key] == fixed[key] + sum(row[key] for row in selected) for key in keys) and all(
        full["controlled"][word] == fixed["controlled"][word] + sum(row["controlled"][word] for row in selected)
        for word in full["controlled"])


def _analyze(text, prompt, max_paragraphs):
    required = ("word_length_mean_han", "function_pos_share_proxy", "activity_v_over_v_plus_a", "nominality_n_over_n_plus_v")
    if any(key not in prompt.get("secondary_targets", {}) for key in required):
        raise ContractError("paragraph balance requires four explicit word/POS targets")
    for key in required:
        band = prompt["secondary_targets"][key]
        low, high = Fraction(str(band["min"])), Fraction(str(band["max"]))
        if not 0 < low <= high or (key != "word_length_mean_han" and high >= 1):
            raise ContractError("paragraph balance requires positive word targets and interior POS bands")
    if max_paragraphs not in (1, 2, 3):
        raise ContractError("paragraph balance supports 1..3 editable paragraphs")
    indexed = paragraph_index(text)
    if len(indexed) > 32:
        raise ContractError("paragraph balance pilot supports at most 32 original paragraphs")
    full = compact(text, prompt)
    rows = [{**row, "counts": compact(row["text"], prompt)} for row in indexed]
    candidates = []
    for group in combinations(rows, min(max_paragraphs, len(rows))):
        offsets = {row["line_offset"] for row in group}
        remaining = "".join(line for offset, line in enumerate(text.splitlines(keepends=True)) if offset not in offsets)
        fixed = compact(remaining, prompt) if remaining.strip() else {
            **{key: 0 for key in ("han", "word_han", "tokens", "function", "n", "v", "a")},
            "controlled": {word: 0 for word in full["controlled"]}}
        exact = additive(full, fixed, [row["counts"] for row in group])
        scenarios = [scenario(fixed, ceil(Fraction(full["word_han"]) * factor), prompt, len(group), full)
                     for factor in (Fraction(1), Fraction(11, 10), Fraction(6, 5))] if exact else []
        candidates.append({"paragraph_ids": [row["paragraph_id"] for row in group], "fixed_counts": fixed,
                           "additive_counts_verified": exact, "scenarios": scenarios})
    priority_words = sorted((band["word"] for band in prompt.get("lexical_targets", [])
                             if full["controlled"][band["word"]] * 1000 > Fraction(str(band["max"])) * full["tokens"]),
                            key=lambda word: (-full["controlled"][word], word))
    candidates.sort(key=lambda row: (-sum(bool(s["compatible_token_count"]) for s in row["scenarios"]),
                                     [row["fixed_counts"]["controlled"][word] for word in priority_words], row["paragraph_ids"]))
    compatible = [row for row in candidates if any(s["compatible_token_count"] for s in row["scenarios"])]
    if not compatible:
        raise ContractError("no editable group passed the stated conditional count scenarios")
    return {"schema": SCHEMA, "version": VERSION, "text_sha256": sha(text), "tokenizer": tokenizer_provenance(),
            "full_counts": full, "paragraphs": rows, "candidates": candidates,
            "overrepresented_word_priorities": priority_words,
            "selected_paragraph_ids": compatible[0]["paragraph_ids"],
            "scope": "conditional count screening; not natural-language feasibility or acceptance; no length gate"}


@lru_cache(maxsize=64)
def _cached(text, serialized_prompt, max_paragraphs):
    return json.dumps(_analyze(text, json.loads(serialized_prompt), max_paragraphs), ensure_ascii=False, sort_keys=True)


def analyze(text, prompt, max_paragraphs=2):
    return json.loads(_cached(text, json.dumps(prompt, ensure_ascii=False, sort_keys=True), max_paragraphs))


def feedback(text, prompt, max_paragraphs=2):
    value = analyze(text, prompt, max_paragraphs)
    ids = value["selected_paragraph_ids"]
    chosen = next(row for row in value["candidates"] if row["paragraph_ids"] == ids)
    selected = [row for row in value["paragraphs"] if row["paragraph_id"] in ids]
    lines = ["本次由工具选择可编辑原段：" + json.dumps(ids) + "；补丁只能引用这些编号，其他段固定。",
             "固定部分真实计数=" + json.dumps(chosen["fixed_counts"], ensure_ascii=False),
             "可编辑段的真实计数=" + json.dumps([{k: row[k] for k in ("paragraph_id", "counts")} for row in selected], ensure_ascii=False),
             "词元类别n/v/a/功能类/其余互斥并共享总词元预算，代词r归其余；不是各项独立加词。",
             "实际删除所选段后复算，已核验计数可加；改写仍可能改变分词，最终要测完整候选。"]
    for row in chosen["scenarios"]:
        lines.append("条件计数相容性=" + json.dumps(row, ensure_ascii=False))
    lines += ["以上汉字量只是条件演算，不限制全篇长度；计数见证不证明自然表达、MATTR或四主轴可行。",
              "用复合动词保留动作含义；保持必要因果和语法关系，减少重复的了时用完整句式重构，勿机械换词。",
              "所有17目标仍参与严格复算；对白不是给旁白随意套引号，事实和自然度仍未验证。"]
    return lines

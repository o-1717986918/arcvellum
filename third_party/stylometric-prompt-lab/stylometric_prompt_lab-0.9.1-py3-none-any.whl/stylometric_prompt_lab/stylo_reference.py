"""Formula-level port of a pinned subset of stylo 0.7.71, not its R package.

Source functions: txt.to.words.ext, txt.to.features, make.ngrams,
make.samples, make.frequency.list, make.table.of.frequencies,
perform.culling, dist.delta. See docs/reference-methods.md.
"""

from __future__ import annotations

from collections import Counter
import re
from statistics import mean, stdev
from typing import Any

from .corpus import Corpus
from .io import ContractError, digest
from . import __version__


UPSTREAM_COMMIT = "856f5f469ee808d367e5fcb31b938d30f37863dd"
# Mirrors corpus.lang="CJK" in stylo/R/txt.to.words.ext.R. No jieba here.
CJK_TOKEN = re.compile(
    r"[A-Za-z\u3040-\u309f\u30a0-\u30ff\u3005\u3031-\u3035"
    r"\u4e00-\u9fff\u3400-\u4dbf\uac00-\ud7af]+"
)


def cjk_tokens(text: str) -> list[str]:
    return CJK_TOKEN.findall(text)


def to_features(tokens: list[str], ngram_size: int) -> list[str]:
    """stylo features='c': paste tokens with spaces, then make.ngrams."""
    if not 1 <= ngram_size <= 3:
        raise ContractError("ngram_size must be 1, 2, or 3")
    chars = list(" ".join(tokens))
    if len(chars) < ngram_size:
        raise ContractError("sample is shorter than the requested character n-gram")
    if ngram_size == 1:
        return chars
    return [" ".join(chars[index:index + ngram_size])
            for index in range(len(chars) - ngram_size + 1)]


def normal_samples(tokens: list[str], size: int | None, overlap: int) -> tuple[list[list[str]], int]:
    if size is None:
        if overlap:
            raise ContractError("sample_overlap requires sample_size")
        return [tokens], 0
    if size < 10 or overlap < 0 or overlap >= size:
        raise ContractError("sample_size must be >=10 and 0 <= overlap < sample_size")
    if len(tokens) < size:
        raise ContractError(f"source has {len(tokens)} CJK tokens, fewer than sample_size={size}")
    step = size - overlap
    count = (len(tokens) - overlap) // step
    samples = [tokens[index * step:index * step + size] for index in range(count)]
    # The number reported by stylo's make.samples is overlap-adjusted; here
    # report the actual trailing tokens not included in the last sample.
    dropped = len(tokens) - ((count - 1) * step + size)
    return samples, dropped


def frequency_order(samples: list[list[str]]) -> tuple[list[str], Counter[str], int]:
    pooled = Counter(feature for sample in samples for feature in sample)
    total = sum(pooled.values())
    if total < 3:
        raise ContractError("at least three feature occurrences are needed")
    # R's table() sorts names before sort(..., decreasing=TRUE). Unicode
    # codepoint order is deterministic, but locale-specific R ties may differ.
    return sorted(pooled, key=lambda item: (-pooled[item], item)), pooled, total


def frequency_table(samples: list[list[str]], features: list[str]) -> list[list[float]]:
    rows = []
    for sample in samples:
        counts = Counter(sample)
        rows.append([100.0 * counts[feature] / len(sample) for feature in features])
    return rows


def cull(features: list[str], table: list[list[float]], level: float) -> tuple[list[str], list[list[float]]]:
    if not 0 <= level <= 100:
        raise ContractError("culling must be between 0 and 100 percent")
    selected = [index for index in range(len(features))
                if sum(row[index] > 0 for row in table) / len(table) >= level / 100]
    return [features[index] for index in selected], [[row[index] for index in selected] for row in table]


def select_features(samples: list[list[str]], mfw: int, list_cutoff: int,
                    culling: float) -> tuple[list[str], list[str], list[list[float]], Counter[str], int]:
    if mfw < 2 or list_cutoff < 2:
        raise ContractError("mfw and list_cutoff must each be at least 2")
    order, pooled, total = frequency_order(samples)
    ranked = order[:list_cutoff]
    table = frequency_table(samples, ranked)
    surviving, table = cull(ranked, table, culling)
    return ranked, surviving[:mfw], [row[:mfw] for row in table], pooled, total


def burrows_delta(table: list[list[float]]) -> list[list[float | None]]:
    """R scale() column sample SD, then dist(...,'manhattan') / columns.

    R dist() omits NA dimensions pairwise and rescales by p / valid_p;
    division by p leaves the mean absolute z difference over valid columns.
    A zero-variance column has NA z scores and is omitted.
    """
    if len(table) < 2 or not table or len(table[0]) < 2:
        raise ContractError("Delta requires at least two samples and two features")
    if any(len(row) != len(table[0]) for row in table):
        raise ContractError("frequency table is not rectangular")
    columns = list(zip(*table))
    z_columns: list[list[float] | None] = []
    for column in columns:
        spread = stdev(column)
        z_columns.append([(value - mean(column)) / spread for value in column] if spread else None)
    result: list[list[float | None]] = [[0.0] * len(table) for _ in table]
    for i in range(len(table)):
        for j in range(i + 1, len(table)):
            differences = [abs(column[i] - column[j]) for column in z_columns if column is not None]
            distance = sum(differences) / len(differences) if differences else None
            result[i][j] = result[j][i] = distance
    return result


def split_audit(corpus: Corpus) -> dict[str, Any]:
    train = [source for source in corpus.sources if source.split == "train"]
    holdout = [source for source in corpus.sources if source.split == "holdout"]
    train_works = {source.work_id for source in train}
    holdout_works = {source.work_id for source in holdout}
    train_topics = {source.topic for source in train}
    holdout_topics = {source.topic for source in holdout}
    topic_known = "unknown" not in train_topics | holdout_topics
    return {
        "train_works": sorted(train_works), "holdout_works": sorted(holdout_works),
        "work_disjoint": train_works.isdisjoint(holdout_works),
        "train_topics": sorted(train_topics), "holdout_topics": sorted(holdout_topics),
        "topic_disjoint": topic_known and train_topics.isdisjoint(holdout_topics),
        "cross_topic_holdout_eligible": (topic_known and train_topics.isdisjoint(holdout_topics)
                                         and train_works.isdisjoint(holdout_works)),
    }


def analyze(corpus: Corpus, *, ngram_size: int = 1, sample_size: int | None = None,
            sample_overlap: int = 0, mfw: int = 100, list_cutoff: int = 5000,
            culling: float = 0,
            require_cross_topic: bool = False) -> dict[str, Any]:
    audit = split_audit(corpus)
    if require_cross_topic and not audit["cross_topic_holdout_eligible"]:
        raise ContractError("cross-topic holdout requires distinct known topics and distinct works")
    sample_rows: list[dict[str, Any]] = []
    samples: list[list[str]] = []
    for source in corpus.sources:
        tokens = cjk_tokens(source.text)
        token_samples, dropped = normal_samples(tokens, sample_size, sample_overlap)
        for index, token_sample in enumerate(token_samples, start=1):
            features = to_features(token_sample, ngram_size)
            samples.append(features)
            sample_rows.append({
                "sample_id": f"{source.source_id}_{index}" if sample_size else source.source_id,
                "source_id": source.source_id, "work_id": source.work_id,
                "topic": source.topic, "split": source.split,
                "token_count": len(token_sample), "feature_count": len(features),
                "source_token_count": len(tokens), "source_tail_tokens_dropped": dropped,
            })
    # stylo.R builds a longer wordlist, culls the full frequency table,
    # and only then takes the first mfw surviving columns.
    ranked, selected, table, pooled, total = select_features(samples, mfw, list_cutoff, culling)
    if len(selected) < 2:
        raise ContractError("fewer than two features survive MFW selection and culling")
    distances = burrows_delta(table)
    result = {
        "schema": "stylo-reference-analysis/v1", "method": "stylo-cjk-char-delta-subset",
        "implementation_version": __version__,
        "upstream": {"repository": "computationalstylistics/stylo", "commit": UPSTREAM_COMMIT,
                     "version": "0.7.71"},
        "parameters": {"corpus_lang": "CJK", "features": "c", "ngram_size": ngram_size,
                       "sampling": "normal.sampling" if sample_size else "no.sampling",
                       "sample_size_tokens": sample_size, "sample_overlap_tokens": sample_overlap,
                       "mfw": mfw, "mfw_list_cutoff": list_cutoff,
                       "culling_percent": culling,
                       "relative_frequencies": True, "distance": "dist.delta"},
        "source_digest": digest([source.public() for source in corpus.sources]),
        "split_audit": audit, "samples": sample_rows,
        "pooled_feature_occurrences": total,
        "feature_list_before_culling": [{"feature": feature, "count": pooled[feature],
                                         "percent": 100 * pooled[feature] / total} for feature in ranked],
        "features_after_culling": selected,
        "frequency_percent_by_sample": table,
        "delta_by_sample": distances,
        "warnings": [
            "Holdout samples participate in unsupervised MFW selection and z-scaling; distances are descriptive, not predictive holdout accuracy.",
            "Character feature mode includes inter-token spaces exactly as stylo's paste(..., collapse=' ') does.",
            "Equal-frequency feature order may differ from R under a non-Unicode collation locale.",
        ] + ([] if audit["cross_topic_holdout_eligible"] else [
            "Distinct-work, distinct-topic holdout is unavailable; cross-topic generalization is not established."
        ]),
    }
    result["analysis_sha256"] = digest(result)
    return result

"""Versioned, evidence-scoped parameter card for Chinese narrative style."""

from __future__ import annotations

from typing import Any

from .io import ContractError, digest
from .extended_metrics import SECONDARY_AXES, secondary_summary_key
from .metrics import AXES
from .dependency_targets import card_extension, render_card_extension
from .prompting import validate_controls, validate_lexical_targets, validate_secondary_controls


CARD_VERSION = "1.2.0"
AXIS_META = {
    "sentence_length_han": ("句群节奏", "每句汉字数的窗口均值；按。！？；和英文对应符号断句。"),
    "paragraph_length_han": ("段落呼吸", "每段汉字数的窗口均值；以非空文本行为段落。"),
    "dialogue_share": ("对白显现", "成对引号内汉字数除以全部汉字数。"),
    "punctuation_per_1000_han": ("停顿密度", "归一化标点字符数除以汉字数，再乘以 1000。"),
}


def _warning(message: str) -> str:
    if message == "fewer than three training windows; target ranges have low stability":
        return "训练窗口少于 3 个；目标范围稳定性较低。"
    if message.startswith("same work in train and holdout: "):
        return "同一作品跨训练与留出；仅属探索性证据。" + message.split(": ", 1)[1].split(";", 1)[0]
    return message


def build_parameter_card(profile: dict[str, Any], controls: dict[str, Any],
                         *, title: str, intent: str = "", dependency_parse: dict | None = None) -> dict[str, Any]:
    if profile.get("schema") != "stylometric-profile/v1":
        raise ContractError("profile must have schema stylometric-profile/v1")
    unsigned = {key: value for key, value in profile.items() if key != "profile_sha256"}
    if profile.get("profile_sha256") != digest(unsigned):
        raise ContractError("profile hash does not match its contents")
    normalized = validate_controls(profile, controls)
    secondary = validate_secondary_controls(profile, controls)
    lexical_targets = validate_lexical_targets(profile, controls)
    title, intent = title.strip(), intent.strip()
    if not title or len(title) > 80 or len(intent) > 300:
        raise ContractError("card title must be 1..80 characters and intent at most 300 characters")
    sources = profile.get("source_evidence") or []
    training = [row for row in sources if row.get("split") == "train"]
    holdout = [row for row in sources if row.get("split") == "holdout"]
    lexical = profile.get("diagnostics") or {}
    axes = []
    for key in AXES:
        summary = profile["axes"][key]
        label, definition = AXIS_META[key]
        observed = {name: summary[name] for name in
                    ("min", "p25", "median", "p75", "max", "window_count")}
        target = normalized[key]
        center = (float(target["min"]) + float(target["max"])) / 2
        median = float(observed["median"])
        direction = "increase" if center > median else "decrease" if center < median else "maintain"
        axes.append({"id": key, "label": label, "definition": definition,
                     "unit": AXES[key], "observed": observed, "target": target,
                     "direction": direction, "measurement_status": "direct-measurement",
                     "generation_control_status": "unverified"})
    card = {
        "schema": "style-parameter-card/v1", "card_version": CARD_VERSION,
        "title": title, "intent": intent,
        "intent_status": "user-hypothesis" if intent else "unspecified",
        "profile_sha256": profile["profile_sha256"],
        "controls_sha256": digest(controls),
        "evidence": {"training_source_count": len(training),
                     "training_work_count": len({row.get("work_id") for row in training}),
                     "training_han_count": profile.get("train_han_count", 0),
                     "sentence_count": profile.get("sentence_count", 0),
                     "paragraph_count": profile.get("paragraph_count", 0),
                     "window_count": profile.get("window_count", 0),
                     "status": "descriptive-only",
                     "generation_effect": "not-verified"},
        "axes": axes,
        "secondary_axes": [
            {"id": key, "unit": unit,
             "observed": profile["extended_window_summary"][secondary_summary_key(key)],
             "target": secondary[key], "generation_control_status": "unverified"}
            for key, unit in SECONDARY_AXES.items() if key in secondary
        ],
        "lexical_targets": [
            {**row, "observed_per_1000_words": next(
                item["per_1000_words"] for item in
                profile["extended_diagnostics"]["grammar"]["function_word_top"]
                if item["word"] == row["word"]),
             "generation_control_status": "unverified"}
            for row in lexical_targets
        ],
        "diagnostics": {
            "sentence_length_distribution": profile.get("sentence_length_distribution", {}),
            "paragraph_length_distribution": profile.get("paragraph_length_distribution", {}),
            "punctuation_per_1000_han_by_mark": profile.get("punctuation_per_1000_han_by_mark", {}),
            "char_top": lexical.get("char_top", [])[:8],
            "word_top": lexical.get("word_top", [])[:8],
            "char_bigram_top": lexical.get("char_bigram_top", [])[:8],
            "tokenizer": lexical.get("tokenizer", {}),
            "extended_status": "measured" if profile.get("extended_diagnostics") else "not-in-profile",
            "extended": profile.get("extended_diagnostics", {}),
            "extended_window_summary": profile.get("extended_window_summary", {}),
            "extended_work_estimates": profile.get("extended_work_estimates", []),
            "extended_work_summary": profile.get("extended_work_summary", {}),
            "axis_work_summary": profile.get("axis_work_summary", {}),
            "holdout_char_bigram_cosine": (
                profile.get("holdout_diagnostic", {}).get("top50_char_bigram_cosine")
                if holdout else None
            ),
            "note": "诊断项用于解释分布，不自动成为可控目标；字词频、字二元组和跨组余弦相似度可能受题材影响，也不等于文学质量。",
        },
        "warnings": [_warning(str(message)) for message in (profile.get("warnings") or [])],
    }
    card.update(card_extension(controls, dependency_parse))
    card["card_sha256"] = digest(card)
    return card


def render_parameter_card(card: dict[str, Any]) -> str:
    if card.get("schema") != "style-parameter-card/v1":
        raise ContractError("card must have schema style-parameter-card/v1")
    lines = [f"# {card['title']}", "", f"意向：{card['intent'] or '未填写'}", "",
             "状态：描述性参数卡；意向解释和生成调控效果尚未验证。", "",
             "| 参数 | 语料中位数 | 语料四分位区间 | 目标区间 | 单位 |",
             "| --- | ---: | ---: | ---: | --- |"]
    for row in card["axes"]:
        observed, target = row["observed"], row["target"]
        lines.append(f"| {row['label']} | {observed['median']:g} | "
                     f"{observed['p25']:g}–{observed['p75']:g} | "
                     f"{target['min']:g}–{target['max']:g} | {row['unit']} |")
    if card.get("secondary_axes"):
        lines.extend(["", "## 次级实验目标", "",
                      "按固定计数口径生成；目前只证明可测，不代表模型能稳定遵守。", "",
                      "| 指标 | 来源窗口中位数 | 目标区间 | 单位 |",
                      "| --- | ---: | ---: | --- |"])
        for row in card["secondary_axes"]:
            band = row["target"]
            lines.append(f"| `{row['id']}` | {row['observed']['median']:g} | "
                         f"{band['min']:g}–{band['max']:g} | {row['unit']} |")
    if card.get("lexical_targets"):
        lines.extend(["", "## 高频语法词实验目标", "",
                      "按自动词性筛选，文本很短时频率波动较大；不能据此要求复用来源题材词。", "",
                      "| 词 | 来源/千词元 | 目标/千词元 |",
                      "| --- | ---: | ---: |"])
        for row in card["lexical_targets"]:
            lines.append(f"| {row['word']} | {row['observed_per_1000_words']:g} | "
                         f"{row['min']:g}–{row['max']:g} |")
    evidence = card["evidence"]
    lines.extend(["", f"训练来源 {evidence['training_source_count']} 篇、作品 "
                  f"{evidence['training_work_count']} 部、窗口 {evidence['window_count']} 个；"
                  f"句 {evidence['sentence_count']} 个、段 {evidence['paragraph_count']} 个。",
                  f"画像哈希：`{card['profile_sha256']}`", ""])
    diagnostics = card["diagnostics"]
    axis_works = diagnostics.get("axis_work_summary") or {}
    if axis_works:
        lines.extend(["## 作品级四轴对照", "",
                      "先在各训练作品内计算，再取作品间中位数；与上表的窗口中位数口径不同。", "",
                      "| 参数 | 作品级中位数 | 窗口级中位数 | 作品数 |",
                      "| --- | ---: | ---: | ---: |"])
        for row in card["axes"]:
            work = axis_works[row["id"]]
            lines.append(f"| {row['label']} | {work['median']:g} | "
                         f"{row['observed']['median']:g} | {work['work_count']} |")
        lines.append("")
    lines.extend(["## 扩展诊断（不作控制轴）", "",
                  "句段分布按全部训练文本统计，标点频率按每千汉字计算。"
                  " 高频字词和字二元组只供检查，可能反映题材。", ""])
    for label, key in (("句长", "sentence_length_distribution"),
                       ("段长", "paragraph_length_distribution")):
        summary = diagnostics[key]
        if summary:
            lines.append(f"- {label}：25% 位 {summary['p25']:g}，中位数 "
                         f"{summary['median']:g}，75% 位 {summary['p75']:g} 汉字。")
    marks = sorted(diagnostics["punctuation_per_1000_han_by_mark"].items(),
                   key=lambda item: (-item[1], item[0]))[:6]
    if marks:
        lines.append("- 高频标点：" + "；".join(f"{mark} {rate:g}/千字" for mark, rate in marks) + "。")
    for label, key in (("高频字", "char_top"), ("高频词", "word_top"),
                       ("高频字二元组", "char_bigram_top")):
        items = diagnostics[key][:6]
        if items:
            lines.append(f"- {label}：" + "、".join(str(item["item"]) for item in items) + "。")
    if diagnostics["holdout_char_bigram_cosine"] is not None:
        lines.append(f"- 训练/留出前 50 字二元组余弦相似度："
                     f"{diagnostics['holdout_char_bigram_cosine']:g}（非质量分数）。")
    extended = diagnostics.get("extended") or {}
    if extended:
        rhythm, lexical, grammar = (extended[name] for name in ("rhythm", "lexical", "grammar"))
        lines.extend(["", "### 节奏、词汇与语法代理", ""])
        for label, value, unit in (
            ("短句占比（≤20 汉字）", rhythm["short_sentence_share_le20_han"], "比例"),
            ("长句占比（>30 汉字）", rhythm["long_sentence_share_gt30_han"], "比例"),
            ("分句片段/句（标点代理）", rhythm["clause_segments_per_sentence_proxy"], "片段/句"),
            ("词 MATTR（50 词窗）", lexical["word_mattr_50"], "比例"),
            ("词 MATTR（100 词窗）", lexical["word_mattr_100"], "比例"),
            ("词 MATTR（150 词窗）", lexical["word_mattr_150"], "比例"),
            ("平均词长", lexical["word_length_mean_han"], "汉字/词"),
            ("虚词类词性占比（自动标注代理）", grammar["function_pos_share_proxy"], "比例"),
            ("动词比 V/(V+A)（自动标注）", grammar.get("activity_v_over_v_plus_a"), "比例"),
            ("描写 A/(V+A)（自动标注）", grammar.get("descriptivity_a_over_v_plus_a"), "比例"),
            ("名词比 N/(N+V)（自动标注）", grammar.get("nominality_n_over_n_plus_v"), "比例"),
        ):
            lines.append(f"- {label}：{value:g} {unit}。" if value is not None
                         else f"- {label}：样本不足，未计算。")
        lengths = lexical["word_length_shares"]
        lines.append("- MATTR 画像值为有效作品的等权均值；不跨作品滑动。"
                     f"50 词窗有效作品 {lexical.get('mattr_valid_work_counts', {}).get('word_mattr_50', 0)} 部。")
        lines.append("- 词长分布：" + "；".join(
            f"{'≥4' if key == '4_plus' else key} 汉字 {value:.1%}"
            if value is not None else f"{'≥4' if key == '4_plus' else key} 汉字无数据"
            for key, value in lengths.items()) + "。")
        pos = grammar["pos_shares"]
        pos_labels = {"n": "名词", "v": "动词", "a": "形容词", "r": "代词",
                      "d": "副词", "p": "介词", "c": "连词", "u": "助词"}
        lines.append("- 自动词性占比：" + "；".join(
            f"{pos_labels[key]} {value:.1%}" if value is not None else f"{pos_labels[key]} 无数据"
            for key, value in pos.items() if key in ("n", "v", "a", "r", "d", "p", "c", "u")) + "。")
        lines.append("- 高频句内词性二元组：" + "；".join(
            f"{item['pair']} {item['count']} 次"
            for item in grammar["pos_bigram_top"][:6]) + "。")
        lines.append("- 高频功能字（每千汉字）：" + "；".join(
            f"{char} {rate:g}" for char, rate in sorted(
                ((key, value) for key, value in grammar["function_character_per_1000_han"].items()
                 if value is not None), key=lambda item: (-item[1], item[0]))[:8]) + "。")
        lines.append("- 作品级估计：" + str(len(diagnostics["extended_work_estimates"]))
                     + " 部；窗口四分位见 JSON，窗口不视为独立作品。")
    else:
        lines.extend(["", "旧画像没有扩展统计；请从语料清单重新生成画像。"])
    lines.extend(["", diagnostics["note"], ""])
    if card["warnings"]:
        lines.extend(["## 数据提醒", ""] + [f"- {item}" for item in card["warnings"]] + [""])
    return "\n".join(lines) + render_card_extension(card)

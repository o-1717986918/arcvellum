# Original stylo 0.7.71 performs all feature extraction and Delta prediction.
# The Python layer prepares normalized text, enforces split checks and reports.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 10L) stop("expected 10 arguments")
source_library <- args[[1]]
dependency_library <- args[[2]]
input_csv <- args[[3]]
output_dir <- args[[4]]
ngram_size <- as.integer(args[[5]])
sample_size <- as.integer(args[[6]])
sample_overlap <- as.integer(args[[7]])
mfw <- as.integer(args[[8]])
list_cutoff <- as.integer(args[[9]])
culling <- as.numeric(args[[10]])
.libPaths(c(source_library, dependency_library, .libPaths()))
Sys.setlocale("LC_COLLATE", "C")
library(stylo, lib.loc = source_library)
if (as.character(packageVersion("stylo")) != "0.7.71") stop("unexpected stylo version")

index <- read.csv(input_csv, fileEncoding = "UTF-8", stringsAsFactors = FALSE)
load_split <- function(split) {
  rows <- index[index$split == split, , drop = FALSE]
  texts <- lapply(rows$path, function(path) {
    paste(readLines(path, encoding = "UTF-8", warn = FALSE), collapse = "\n")
  })
  names(texts) <- rows$source_id
  texts
}
parse_split <- function(texts) {
  parse.corpus(
    input.data = texts, markup.type = "plain", corpus.lang = "CJK",
    sample.size = if (sample_size > 0L) sample_size else 10000L,
    sampling = if (sample_size > 0L) "normal.sampling" else "no.sampling",
    sample.overlap = sample_overlap, features = "c", ngram.size = ngram_size,
    preserve.case = TRUE
  )
}
training <- parse_split(load_split("train"))
testing <- parse_split(load_split("holdout"))
if (any(index$split == "candidate")) {
  testing <- c(testing, parse_split(load_split("candidate")))
}
if (length(training) < 2L || length(testing) < 1L) stop("insufficient samples")

# All feature selection and culling are fitted on training samples only.
ranked <- names(sort(table(unlist(training, use.names = FALSE)), decreasing = TRUE))
ranked <- head(ranked, list_cutoff)
train_freq <- make.table.of.frequencies(training, features = ranked,
                                        absent.sensitive = FALSE, relative = TRUE)
test_freq <- make.table.of.frequencies(testing, features = ranked,
                                       absent.sensitive = FALSE, relative = TRUE)
train_culled <- perform.culling(train_freq, culling.level = culling)
if (ncol(train_culled) < 2L) stop("fewer than two features survive culling")
selected <- colnames(train_culled)[seq_len(min(mfw, ncol(train_culled)))]
train_selected <- train_culled[, selected, drop = FALSE]
test_selected <- test_freq[, selected, drop = FALSE]
nonconstant <- sum(apply(train_selected, 2, sd) > 0)
if (nonconstant < 2L) stop("fewer than two nonconstant training features")

style_of <- function(sample_ids) {
  source_ids <- sub("_.*$", "", sample_ids)
  index$style_id[match(source_ids, index$source_id)]
}
classes_train <- style_of(rownames(train_selected))
classes_test <- style_of(rownames(test_selected))
original_test_ids <- rownames(test_selected)
# perform.delta() 0.7.71 has a one-row dimension bug. A duplicate test row
# makes its internal distance matrix two-dimensional; train-only scaling means
# this cannot alter the original row's distances. Remove the duplicate below.
if (nrow(test_selected) == 1L) {
  test_selected <- rbind(test_selected, test_selected)
  rownames(test_selected)[2] <- paste0(original_test_ids[[1]], "_internal_copy")
  classes_test <- c(classes_test, classes_test)
}
result <- perform.delta(
  training.set = train_selected, test.set = test_selected,
  classes.training.set = classes_train, classes.test.set = classes_test,
  distance = "delta", no.of.candidates = min(2L, nrow(train_selected)),
  z.scores.both.sets = FALSE
)
distance <- result$distance_table[original_test_ids, , drop = FALSE]
colnames(distance) <- rownames(train_selected)
write.csv(data.frame(feature = selected), file.path(output_dir, "features.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(as.data.frame(distance), file.path(output_dir, "distances.csv"),
          row.names = TRUE, fileEncoding = "UTF-8")
write.csv(data.frame(
  sample_id = original_test_ids,
  expected_style = classes_test[seq_along(original_test_ids)],
  predicted_style = as.character(result$y[original_test_ids])
), file.path(output_dir, "predictions.csv"), row.names = FALSE,
fileEncoding = "UTF-8")
writeLines(c(
  paste0("R=", R.version.string),
  paste0("stylo=", as.character(packageVersion("stylo"))),
  paste0("locale=", Sys.getlocale()),
  paste0("training_samples=", length(training)),
  paste0("test_samples=", length(testing)),
  paste0("nonconstant_features=", nonconstant)
), file.path(output_dir, "runtime.txt"), useBytes = TRUE)

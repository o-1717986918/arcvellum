"""Exact conditional count constraints, plus the real tokenizer's evidence."""

from __future__ import annotations

from collections import Counter
from fractions import Fraction
import hashlib
import json
from math import ceil, floor
from pathlib import Path

import jieba
import jieba.posseg as pseg

from .corpus import HAN
from .extended_metrics import FUNCTION_POS, POS_KEYS, mattr_components
from .io import ContractError


SCHEMA = "style-count-repair-analysis/v1"
VERSION = "0.2.0"


def tokenizer_provenance() -> dict:
    dictionary = Path(jieba.__file__).with_name("dict.txt")
    return {"name": "jieba.posseg", "version": jieba.__version__, "HMM": False,
            "dictionary_sha256": hashlib.sha256(dictionary.read_bytes()).hexdigest()}


def nonnegative_interval(constant, slope, low, high):
    """Solve constant+slope*k >= 0 for integer k in a closed domain."""
    if slope > 0:
        low = max(low, ceil(-constant / slope))
    elif slope < 0:
        high = min(high, floor(constant / -slope))
    elif constant < 0:
        return None
    return (low, high) if low <= high else None


def ratio_interval(numerator, added, denominator, denominator_added, band, domain):
    """Exact affine ratio bounds; the caller supplies a positive denominator domain."""
    lower, upper = Fraction(str(band["min"])), Fraction(str(band["max"]))
    value = nonnegative_interval(Fraction(numerator) - lower * denominator,
                                Fraction(added) - lower * denominator_added, *domain)
    if value is not None:
        value = nonnegative_interval(upper * denominator - Fraction(numerator),
                                     upper * denominator_added - Fraction(added), *value)
    return value


def ledger(text):
    tokens = [(t.word, t.flag) for t in pseg.cut(text, HMM=False)
              if t.word and all(HAN.fullmatch(char) for char in t.word)]
    if not tokens:
        raise ContractError("count repair requires Han word tokens")
    tags = Counter(tag[0] if tag and tag[0] in POS_KEYS else "other" for _, tag in tokens)
    counts = Counter(tokens)
    functions = Counter(word for word, tag in tokens if tag and tag[0] in FUNCTION_POS)
    return {"text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "han_count": len(HAN.findall(text)), "tokenized_han_count": sum(len(word) for word, _ in tokens),
            "word_token_count": len(tokens),
            "function_token_count": sum(functions.values()), "coarse_pos_counts": dict(sorted(tags.items())),
            "tokens": tokens, "mattr50_components": mattr_components([word for word, _ in tokens], 50),
            "tagged_word_counts": [{"word": word, "tag": tag, "count": count,
                                   "function": bool(tag and tag[0] in FUNCTION_POS)}
                                  for (word, tag), count in sorted(counts.items(), key=lambda x: (-x[1], x[0]))]}, functions


def shared_constraints(evidence, functions, prompt, *, version=VERSION):
    rows = []
    for key, count in (("word_length_mean_han", evidence["han_count"] if version == "0.1.0" else evidence["tokenized_han_count"]),
                       ("function_pos_share_proxy", evidence["function_token_count"])):
        band = prompt.get("secondary_targets", {}).get(key)
        if band:
            rows.append({"metric": key, "numerator": count, "scale": 1, "band": band})
    rows += [{"metric": "function_word:" + band["word"], "numerator": functions[band["word"]],
              "scale": 1000, "band": band} for band in prompt.get("lexical_targets", [])]
    return rows


def conditional_scenario(rows, evidence, *, added_han=None, version=VERSION):
    fixed = added_han is None
    domain = (1, evidence["han_count"] if version == "0.1.0" else evidence["tokenized_han_count"]) if fixed else (0, evidence["word_token_count"])
    joint, constraints = domain, []
    for row in rows:
        increment = 0 if fixed else (added_han if row["metric"] == "word_length_mean_han"
                                    else 1 if row["metric"] == "function_pos_share_proxy" else 0)
        interval = ratio_interval(row["numerator"] * row["scale"], increment * row["scale"],
                                  0 if fixed else evidence["word_token_count"], 1, row["band"], domain)
        constraints.append({"metric": row["metric"], "integer_range": interval})
        joint = ((max(joint[0], interval[0]), min(joint[1], interval[1]))
                 if joint is not None and interval is not None else None)
        if joint is not None and joint[0] > joint[1]:
            joint = None
    return {"variable": "new_total_word_tokens" if fixed else "added_function_word_tokens",
            "domain": domain, "added_han_per_token": added_han,
            "constraints": constraints, "joint_integer_range": joint,
            "assumption": "All listed counts fixed" if fixed else
            "Each new token is functional, has the given Han length, and is not a controlled lexical word"}


def analyze(text, prompt, *, version=VERSION):
    if version not in ("0.1.0", VERSION):
        raise ContractError("unsupported count repair version")
    evidence, functions = ledger(text)
    rows = shared_constraints(evidence, functions, prompt, version=version)
    return {"schema": SCHEMA, "version": version, "tokenizer": tokenizer_provenance(),
            "evidence": evidence, "shared_constraints": rows,
            "fixed_counts": conditional_scenario(rows, evidence, version=version),
            "add_one_han_functions": conditional_scenario(rows, evidence, added_han=1, version=version),
            "add_two_han_functions": conditional_scenario(rows, evidence, added_han=2, version=version),
            "scope": "Conditional arithmetic only; not a feasible rewrite or a quality judgment. "
                     "All other counts, POS ratios and moving windows must be remeasured after editing."}


def feedback(text, prompt, *, version=VERSION):
    value = analyze(text, prompt, version=version)
    e = value["evidence"]
    parts = ["词元证据与联动检查（工具实际标注，不采用模型自行估计）：",
             f"汉字={e['han_count']}，全部词元={e['word_token_count']}，功能类词元={e['function_token_count']}。",
             "粗类词性计数=" + json.dumps(e["coarse_pos_counts"], ensure_ascii=False, sort_keys=True),
             "MATTR50的不同类型总和/完整窗数=" + str(e["mattr50_components"]) + "；分母还需乘50，不是全篇不同词数。"]
    if version != "0.1.0":
        parts.insert(2, f"词长分子为分词后汉字={e['tokenized_han_count']}，不可替换成全部汉字。")
    singles = [t for t in e["tagged_word_counts"] if len(t["word"]) == 1 and not t["function"]][:16]
    functional = [t for t in e["tagged_word_counts"] if t["function"]][:16]
    parts += ["常见单字非功能词（词/实际标签/次数）=" + json.dumps(singles, ensure_ascii=False),
              "常见功能词（词/实际标签/次数）=" + json.dumps(functional, ensure_ascii=False)]
    for band in prompt.get("lexical_targets", []):
        tags = [t for t in e["tagged_word_counts"] if t["word"] == band["word"]]
        parts.append("受控词的所有实际标签=" + json.dumps({"word": band["word"], "tags": tags}, ensure_ascii=False))
    for key, label in (("fixed_counts", "保持列出的汉字/功能词/受控词分子不变，仅改变总词元数"),
                       ("add_one_han_functions", "只新增单字非受控功能词，同时增加分母"),
                       ("add_two_han_functions", "只新增二字非受控功能词，同时增加汉字及分母")):
        scenario = value[key]
        parts.append(f"条件演算：{label}；变量{scenario['variable']}；逐项范围=" +
                     json.dumps(scenario["constraints"], ensure_ascii=False) +
                     f"；共同整数范围={scenario['joint_integer_range']}（None表示该假设无解）。")
    parts += ["这些仅为条件演算，不是写作配额。无解应改变相关分子，不能只改同一分母；添字会影响其余主轴。",
              "先保留自然的复合词与语法衔接，避免把动作都拆成单字、机械加虚词或重复同一句。",
              "词性标签是自动标注，不是语言学真值；以上只统计全汉字完整词元，代词r不是功能类。",
              "真实修改会改变分词和词性；必须复算全部17目标与完整MATTR窗，条件区间不构成接受证明。"]
    return parts

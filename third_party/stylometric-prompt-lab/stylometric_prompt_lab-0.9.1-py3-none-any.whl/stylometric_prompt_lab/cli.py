"""Research CLI for corpus, profile, prompt and target-only generation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .corpus import load_corpus
from .cat_observable import analyze_cat
from . import dependency_cli, dependency_examples
from .blind_review import (collate as collate_blind_review,
                           prepare as prepare_blind_review,
                           ratings_template as blind_ratings_template,
                           render_packet as render_blind_packet)
from .candidate_selection import render_selection, select as select_candidates
from .experiment import blind_packet, ratings_template, run_experiment
from .experiment_design import PAIRED_ARMS, require_selected_jobs
from .io import ContractError, read_object, write_object, write_text
from .length_audit import audit_length, render_length_audit
from .metrics import build_profile
from .pi import PiWorker
from .pi_feedback import (compare as compare_pi_feedback,
                          prepare_plan as prepare_pi_feedback_plan,
                          reconstruct_revision as reconstruct_pi_feedback,
                          render_comparison as render_pi_feedback_comparison,
                          render_plan as render_pi_feedback_plan,
                          run_plan as run_pi_feedback_plan)
from .prompting import compile_prompt
from .r_detection import run_detection
from .reporting import evaluate, load_ratings, render_markdown
from .sensitivity import (evaluate_plan as evaluate_sensitivity_plan,
                          prepare_plan as prepare_sensitivity_plan,
                          render_plan as render_sensitivity_plan,
                          render_report as render_sensitivity_report,
                          run_plan as run_sensitivity_plan)
from .style_card import build_parameter_card, render_parameter_card
from .style_objective import audit as audit_style_objective, render_audit as render_style_audit
from .stylo_reference import analyze
from .web_experiment import import_web_answers, prepare_web_plan, render_plan
from .web_feedback import (compare_feedback_reports, import_feedback_answers,
                           prepare_feedback_plan, render_feedback_comparison,
                           render_feedback_plan)


def _path(value: str) -> Path:
    return Path(value).expanduser().resolve()


def parser() -> argparse.ArgumentParser:
    main = argparse.ArgumentParser(prog="styloprompt", description="计量文体学驱动的现代中文叙事提示词研究原型")
    commands = main.add_subparsers(dest="command", required=True)
    dependency_cli.add_commands(commands, _path)
    dependency_examples.add_commands(commands, _path)
    inspect = commands.add_parser("inspect", help="校验语料及训练/留出隔离")
    inspect.add_argument("manifest", type=_path)
    profile = commands.add_parser("profile", help="构建可测风格画像与调节模板")
    profile.add_argument("manifest", type=_path)
    profile.add_argument("--out", type=_path, required=True)
    analysis = commands.add_parser("analyze", help="按固定版本 stylo CJK 字特征、MFW、culling 和 Delta 公式分析")
    analysis.add_argument("manifest", type=_path)
    analysis.add_argument("--out", type=_path, required=True)
    analysis.add_argument("--ngram-size", type=int, choices=(1, 2, 3), default=1)
    analysis.add_argument("--sample-size", type=int, help="normal.sampling 的 CJK 词串数；省略时使用整篇")
    analysis.add_argument("--sample-overlap", type=int, default=0)
    analysis.add_argument("--mfw", type=int, default=100)
    analysis.add_argument("--list-cutoff", type=int, default=5000, help="culling 前候选特征上限；stylo 默认 5000")
    analysis.add_argument("--culling", type=float, default=0)
    analysis.add_argument("--require-cross-topic", action="store_true", help="题材及作品不分离则拒绝分析")
    detect = commands.add_parser("detect", help="调用原版 stylo::perform.delta 检测有标签文体及候选文本")
    detect.add_argument("manifest", type=_path)
    detect.add_argument("--out", type=_path, required=True)
    detect.add_argument("--rscript", type=_path, required=True)
    detect.add_argument("--stylo-library", type=_path, required=True)
    detect.add_argument("--dependency-library", type=_path, required=True)
    detect.add_argument("--candidate", type=_path, help="可选 TXT/Markdown 待检测文本")
    detect.add_argument("--ngram-size", type=int, choices=(1, 2, 3), default=1)
    detect.add_argument("--sample-size", type=int, help="等长样本的 CJK 词串数；省略时整篇分析")
    detect.add_argument("--sample-overlap", type=int, default=0)
    detect.add_argument("--mfw", type=int, default=100)
    detect.add_argument("--list-cutoff", type=int, default=5000)
    detect.add_argument("--culling", type=float, default=0)
    compile_cmd = commands.add_parser("compile", help="从画像的主轴、次级与高频语法词目标生成提示词")
    compile_cmd.add_argument("--profile", type=_path, required=True)
    compile_cmd.add_argument("--controls", type=_path, required=True)
    compile_cmd.add_argument("--strategy", choices=["full", "calibrated"], default="calibrated")
    compile_cmd.add_argument("--target-han", type=int, default=750)
    compile_cmd.add_argument("--calibration-version", choices=["0.4.0", "0.5.0", "0.6.0", "0.7.0", "0.8.0", "0.9.0", "0.10.0", "0.11.0", "0.12.0", "0.13.0", "0.14.0"], default="0.11.0",
                             help="0.4.0 结构版；0.5.0 严格计数；0.6.0 联动；0.7.0 对白边界；0.8.0 段落 JSON；0.9.0 全篇持续校准；0.10.0 固定段落预算 JSON；0.11.0 文风优先；0.12.0 对白句式联动；0.13.0 主轴优先；0.14.0 联动分布实验")
    compile_cmd.add_argument("--out", type=_path, required=True)
    compile_cmd.add_argument("--dependency-parse", type=_path, help="可选：单篇真实依存参考JSON，绑定句法目标")
    card = commands.add_parser("card", help="将画像和目标区间整理成可追溯文风参数卡")
    card.add_argument("--profile", type=_path, required=True)
    card.add_argument("--controls", type=_path, required=True)
    card.add_argument("--title", required=True)
    card.add_argument("--intent", default="", help="用户定义的抽象文风意向；仅作未验证假设")
    card.add_argument("--out", type=_path, required=True)
    card.add_argument("--dependency-parse", type=_path, help="可选：单篇真实依存参考JSON")
    studio = commands.add_parser("studio", help="启动本地文风参数卡页面")
    studio.add_argument("--host", default="127.0.0.1")
    studio.add_argument("--port", type=int, default=8765)
    experiment = commands.add_parser("experiment", help="调用本地 ArcVellum Pi Worker；默认只运行参数组并开启思考")
    experiment.add_argument("--profile", type=_path, required=True)
    experiment.add_argument("--prompt", type=_path, required=True)
    experiment.add_argument("--corpus", type=_path, required=True)
    experiment.add_argument("--cases", type=_path, required=True)
    experiment.add_argument("--worker-entrypoint", type=_path, required=True)
    experiment.add_argument("--model", required=True, help="Pi catalog 中的 provider/model")
    experiment.add_argument("--model-version", default="unreported", help="供应商披露的模型修订版本；未知则保留 unreported")
    experiment.add_argument("--node", default="node")
    experiment.add_argument("--auth-path", type=_path)
    experiment.add_argument("--timeout", type=int, default=240)
    experiment.add_argument("--repetitions", type=int, default=2)
    experiment.add_argument("--seed", type=int, default=20260928)
    experiment.add_argument("--arms", choices=["target", "paired"], default="target")
    experiment.add_argument("--baseline-policy", choices=["legacy", "length_matched"], default="legacy")
    experiment.add_argument("--baseline-prompt", type=_path, help="与目标共用画像和目标区间的旧版提示词 JSON")
    experiment.add_argument("--out", type=_path, required=True)
    selection = commands.add_parser("select-candidates", help="从等预算独立候选中按冻结计量顺序选稿")
    selection.add_argument("--experiment", type=_path, required=True)
    selection.add_argument("--prompt", type=_path, required=True)
    selection.add_argument("--per-set", type=int, default=3)
    selection.add_argument("--objective", choices=["style_first", "length_first"], default="style_first",
                           help="文风优先；length_first 仅用于旧轮次复现")
    selection.add_argument("--out", type=_path, required=True)
    sensitivity_plan = commands.add_parser("sensitivity-plan", help="冻结单参数高低扰动的独立生成实验")
    sensitivity_plan.add_argument("--prompt", type=_path, required=True)
    sensitivity_plan.add_argument("--cases", type=_path, required=True)
    sensitivity_plan.add_argument("--metrics", default="all", help="逗号分隔的指标名；all 为全部已设置目标")
    sensitivity_plan.add_argument("--repetitions", type=int, default=1)
    sensitivity_plan.add_argument("--seed", type=int, default=20260929)
    sensitivity_plan.add_argument("--out", type=_path, required=True)
    sensitivity_run = commands.add_parser("sensitivity-run", help="使用 Pi Worker 执行可续跑的单参数扰动")
    sensitivity_run.add_argument("--plan", type=_path, required=True)
    sensitivity_run.add_argument("--corpus", type=_path, required=True)
    sensitivity_run.add_argument("--worker-entrypoint", type=_path, required=True)
    sensitivity_run.add_argument("--model", required=True)
    sensitivity_run.add_argument("--model-version", default="unreported")
    sensitivity_run.add_argument("--node", default="node")
    sensitivity_run.add_argument("--auth-path", type=_path)
    sensitivity_run.add_argument("--timeout", type=int, default=240)
    sensitivity_run.add_argument("--out", type=_path, required=True)
    sensitivity_report = commands.add_parser("sensitivity-report", help="汇总单参数方向响应及连带指标")
    sensitivity_report.add_argument("--plan", type=_path, required=True)
    sensitivity_report.add_argument("--experiment", type=_path, required=True)
    sensitivity_report.add_argument("--out", type=_path, required=True)
    pi_feedback_plan = commands.add_parser("pi-feedback-plan", help="冻结 Pi 初稿的普通编辑与计量反馈修订")
    pi_feedback_plan.add_argument("--experiment", type=_path, required=True)
    pi_feedback_plan.add_argument("--prompt", type=_path, required=True)
    pi_feedback_plan.add_argument("--seed", type=int, default=20261005)
    pi_feedback_plan.add_argument("--policy", choices=["full", "focused", "length_guard", "balanced", "style_first", "coupled_style", "coupled_style_rewrite"], default="full")
    pi_feedback_plan.add_argument("--out", type=_path, required=True)
    pi_feedback_run = commands.add_parser("pi-feedback-run", help="可续跑的 Pi 初稿重放修订")
    pi_feedback_run.add_argument("--plan", type=_path, required=True)
    pi_feedback_run.add_argument("--corpus", type=_path, required=True)
    pi_feedback_run.add_argument("--worker-entrypoint", type=_path, required=True)
    pi_feedback_run.add_argument("--model", required=True)
    pi_feedback_run.add_argument("--model-version", default="unreported")
    pi_feedback_run.add_argument("--node", default="node")
    pi_feedback_run.add_argument("--auth-path", type=_path)
    pi_feedback_run.add_argument("--timeout", type=int, default=240)
    pi_feedback_run.add_argument("--out", type=_path, required=True)
    pi_feedback_report = commands.add_parser("pi-feedback-report", help="比较 Pi 计量反馈与普通编辑的逐篇变化")
    pi_feedback_report.add_argument("--plan", type=_path, required=True)
    pi_feedback_report.add_argument("--run", type=_path, required=True)
    pi_feedback_report.add_argument("--experiment", type=_path, required=True)
    pi_feedback_report.add_argument("--prompt", type=_path, required=True)
    pi_feedback_report.add_argument("--out", type=_path, required=True)
    for inherited in (pi_feedback_plan, pi_feedback_run):
        inherited.add_argument("--arms", choices=["target", "paired"], default="target",
                               help="默认仅参数组；paired显式选择历史双组输入")
    web_plan = commands.add_parser("web-plan", help="生成 DeepSeek 网页逐次输入；默认参数组、思考开启")
    web_plan.add_argument("--profile", type=_path, required=True)
    web_plan.add_argument("--prompt", type=_path, required=True)
    web_plan.add_argument("--corpus", type=_path, required=True)
    web_plan.add_argument("--cases", type=_path, required=True)
    web_plan.add_argument("--repetitions", type=int, default=2)
    web_plan.add_argument("--seed", type=int, default=20260929)
    web_plan.add_argument("--arms", choices=["target", "paired"], default="target")
    web_plan.add_argument("--deep-think", action=argparse.BooleanOptionalAction, default=True,
                          help="默认开启思考；--no-deep-think 仅供历史协议复现")
    web_plan.add_argument("--out", type=_path, required=True)
    web_import = commands.add_parser("web-import", help="导入网页端逐次输出并生成盲评包")
    web_import.add_argument("--plan", type=_path, required=True)
    web_import.add_argument("--prompt", type=_path, required=True)
    web_import.add_argument("--corpus", type=_path, required=True)
    web_import.add_argument("--answers", type=_path, required=True)
    web_import.add_argument("--model", required=True, help="网页实际展示的模型名称")
    web_import.add_argument("--model-version", default="unreported")
    web_import.add_argument("--source-url", default="https://chat.deepseek.com/")
    web_import.add_argument("--require-modes-off", action="store_true",
                            help="要求每篇采集元数据证明深度思考与智能搜索均关闭")
    web_import.add_argument("--out", type=_path, required=True)
    feedback_plan = commands.add_parser("web-feedback-plan", help="按网页首轮实测偏差冻结同会话修订提示")
    feedback_plan.add_argument("--experiment", type=_path, required=True)
    feedback_plan.add_argument("--prompt", type=_path, required=True)
    feedback_plan.add_argument("--answers", type=_path, required=True)
    feedback_plan.add_argument("--out", type=_path, required=True)
    feedback_plan.add_argument("--arms", choices=["target", "paired"], default="target",
                              help="默认仅参数组；paired显式选择历史双组输入")
    feedback_import = commands.add_parser("web-feedback-import", help="导入网页同会话第二条正文")
    feedback_import.add_argument("--plan", type=_path, required=True)
    feedback_import.add_argument("--experiment", type=_path, required=True)
    feedback_import.add_argument("--prompt", type=_path, required=True)
    feedback_import.add_argument("--corpus", type=_path, required=True)
    feedback_import.add_argument("--answers", type=_path, required=True)
    feedback_import.add_argument("--out", type=_path, required=True)
    feedback_report = commands.add_parser("web-feedback-report", help="比较首轮与同会话修订的逐篇指标变化")
    feedback_report.add_argument("--first-experiment", type=_path, required=True)
    feedback_report.add_argument("--revised-experiment", type=_path, required=True)
    feedback_report.add_argument("--first-report", type=_path, required=True)
    feedback_report.add_argument("--revised-report", type=_path, required=True)
    feedback_report.add_argument("--out", type=_path, required=True)
    report = commands.add_parser("report", help="分维评估已有实验 JSON；可全程离线运行")
    report.add_argument("--experiment", type=_path, required=True)
    report.add_argument("--prompt", type=_path, required=True)
    report.add_argument("--ratings", type=_path)
    report.add_argument("--out", type=_path, required=True)
    review_prepare = commands.add_parser("review-prepare", help="打乱回答顺序并分离评审包与揭盲映射")
    review_prepare.add_argument("--experiment", type=_path, required=True)
    review_prepare.add_argument("--prompt", type=_path, required=True)
    review_prepare.add_argument("--seed", type=int, default=20261003)
    review_prepare.add_argument("--out", type=_path, required=True)
    review_import = commands.add_parser("review-import", help="核对人工评分并映射回实验盲号")
    review_import.add_argument("--experiment", type=_path, required=True)
    review_import.add_argument("--prompt", type=_path, required=True)
    review_import.add_argument("--packet", type=_path, required=True)
    review_import.add_argument("--map", type=_path, required=True)
    review_import.add_argument("--ratings", type=_path, required=True)
    review_import.add_argument("--out", type=_path, required=True)
    style_audit = commands.add_parser("style-audit", help="按四主轴、句法代理、词汇和人工审读验收；篇幅仅记录")
    style_audit.add_argument("--report", type=_path, required=True)
    style_audit.add_argument("--prompt", type=_path, required=True)
    style_audit.add_argument("--out", type=_path, required=True)
    length_audit = commands.add_parser("length-audit", help="按完整段落前缀复算近等长的逐篇指标")
    length_audit.add_argument("--experiment", type=_path, required=True)
    length_audit.add_argument("--prompt", type=_path, required=True)
    length_audit.add_argument("--target-han", type=int, default=500)
    length_audit.add_argument("--tolerance-han", type=int, default=70)
    length_audit.add_argument("--out", type=_path, required=True)
    return main


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command in {"dependency-parse", "dependency-analyze"}:
            return dependency_cli.run_command(args)
        if args.command == "compile-examples":
            return dependency_examples.run_command(args)
        if args.command == "inspect":
            corpus = load_corpus(args.manifest)
            print(json.dumps(corpus.public(), ensure_ascii=False, indent=2))
            return 0
        if args.command == "profile":
            corpus = load_corpus(args.manifest)
            profile, controls = build_profile(corpus)
            write_object(args.out / "inspection.json", corpus.public())
            write_object(args.out / "profile.json", profile)
            write_object(args.out / "controls.json", controls)
            print(f"画像：{args.out / 'profile.json'}\n可调目标：{args.out / 'controls.json'}")
            return 0
        if args.command == "analyze":
            corpus = load_corpus(args.manifest)
            result = analyze(corpus, ngram_size=args.ngram_size, sample_size=args.sample_size,
                             sample_overlap=args.sample_overlap, mfw=args.mfw,
                             list_cutoff=args.list_cutoff,
                             culling=args.culling, require_cross_topic=args.require_cross_topic)
            write_object(args.out / "stylo-analysis.json", result)
            write_object(args.out / "cat-observable.json", analyze_cat(corpus))
            print(f"方法分析：{args.out / 'stylo-analysis.json'}；{args.out / 'cat-observable.json'}")
            return 0
        if args.command == "detect":
            corpus = load_corpus(args.manifest)
            result = run_detection(corpus, rscript=args.rscript,
                                   stylo_library=args.stylo_library,
                                   dependency_library=args.dependency_library,
                                   candidate=args.candidate, ngram_size=args.ngram_size,
                                   sample_size=args.sample_size, sample_overlap=args.sample_overlap,
                                   mfw=args.mfw, list_cutoff=args.list_cutoff,
                                   culling=args.culling)
            write_object(args.out / "detection.json", result)
            print(f"计量检测：{args.out / 'detection.json'}；状态：{result['status']}")
            return 0
        if args.command == "compile":
            profile = read_object(args.profile, "stylometric-profile/v1")
            controls = read_object(args.controls, "style-controls/v1")
            prompt = compile_prompt(profile, controls, strategy=args.strategy, target_han=args.target_han,
                                    calibration_version=args.calibration_version,
                                    dependency_parse=read_object(args.dependency_parse, "style-dependency-parse/v1")
                                    if args.dependency_parse else None)
            write_object(args.out / "prompt.json", prompt)
            write_text(args.out / "prompt.md", prompt["prompt_markdown"])
            print(f"提示词：{args.out / 'prompt.md'}")
            return 0
        if args.command == "card":
            profile = read_object(args.profile, "stylometric-profile/v1")
            controls = read_object(args.controls, "style-controls/v1")
            result = build_parameter_card(profile, controls, title=args.title, intent=args.intent,
                                          dependency_parse=read_object(args.dependency_parse, "style-dependency-parse/v1")
                                          if args.dependency_parse else None)
            write_object(args.out / "card.json", result)
            write_text(args.out / "card.md", render_parameter_card(result))
            print(f"参数卡：{args.out / 'card.md'}")
            return 0
        if args.command == "studio":
            from .web_server import serve
            serve(args.host, args.port)
            return 0
        if args.command == "experiment":
            profile = read_object(args.profile, "stylometric-profile/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            corpus = load_corpus(args.corpus)
            cases = read_object(args.cases, "style-cases/v1")
            worker = PiWorker(args.worker_entrypoint, args.model, executable=args.node,
                              auth_path=args.auth_path, timeout=args.timeout, model_version=args.model_version)
            result = run_experiment(profile, prompt, corpus, cases, worker,
                                    repetitions=args.repetitions, seed=args.seed,
                                    arms=PAIRED_ARMS if args.arms == "paired" else ("target",),
                                    baseline_policy=args.baseline_policy,
                                    baseline_prompt=(read_object(args.baseline_prompt, "literary-style-prompt/v1")
                                                     if args.baseline_prompt else None))
            write_object(args.out / "experiment.json", result)
            write_text(args.out / "blind-packet.md", blind_packet(result, prompt))
            write_text(args.out / "ratings.csv", ratings_template(result))
            print(f"完成 {result['completed_run_count']}/{result['planned_run_count']} 次生成；实验：{args.out / 'experiment.json'}")
            return 0 if result["completed_run_count"] == result["planned_run_count"] else 1
        if args.command == "select-candidates":
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            record, selected = select_candidates(experiment, prompt, candidates_per_set=args.per_set,
                                                 objective=args.objective)
            write_object(args.out / "selection.json", record)
            write_text(args.out / "selection.md", render_selection(record))
            write_object(args.out / "selected-experiment.json", selected)
            write_text(args.out / "blind-packet.md", blind_packet(selected, prompt))
            write_text(args.out / "ratings.csv", ratings_template(selected))
            print(f"等预算候选：{len(selected['runs'])} 篇；记录：{args.out / 'selection.md'}")
            return 0
        if args.command == "review-prepare":
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            packet, mapping = prepare_blind_review(experiment, prompt, seed=args.seed)
            write_object(args.out / "public" / "review-packet.json", packet)
            write_text(args.out / "public" / "review-packet.md", render_blind_packet(packet))
            write_text(args.out / "public" / "review-ratings.csv", blind_ratings_template(packet))
            write_object(args.out / "private" / "review-map.json", mapping)
            print(f"评审材料：{args.out / 'public'}；揭盲映射单独保存：{args.out / 'private'}")
            return 0
        if args.command == "review-import":
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            packet = read_object(args.packet, "style-blind-review-packet/v1")
            mapping = read_object(args.map, "style-blind-review-map/v1")
            ratings, provenance = collate_blind_review(experiment, prompt, packet, mapping, args.ratings)
            write_text(args.out / "ratings.csv", ratings)
            write_object(args.out / "review-provenance.json", provenance)
            print(f"已核对评分：{args.out / 'ratings.csv'}；可传给 report --ratings")
            return 0
        if args.command == "style-audit":
            report = read_object(args.report, "style-report/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            result = audit_style_objective(report, prompt)
            write_object(args.out / "style-audit.json", result)
            write_text(args.out / "style-audit.md", render_style_audit(result))
            print(f"文风优先审计：{args.out / 'style-audit.md'}")
            return 0
        if args.command == "sensitivity-plan":
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            cases = read_object(args.cases, "style-cases/v1")
            metrics = ([*prompt["targets"], *(prompt.get("secondary_targets") or {}),
                        *(f"lexical:{row['word']}" for row in prompt.get("lexical_targets") or [])]
                       if args.metrics == "all" else [item.strip() for item in args.metrics.split(",")])
            result = prepare_sensitivity_plan(prompt, cases, metrics,
                                              repetitions=args.repetitions, seed=args.seed)
            write_object(args.out / "sensitivity-plan.json", result)
            write_text(args.out / "sensitivity-plan.md", render_sensitivity_plan(result))
            print(f"单参数执行单：{args.out / 'sensitivity-plan.md'}")
            return 0
        if args.command == "sensitivity-run":
            plan = read_object(args.plan, "style-sensitivity-plan/v1")
            corpus = load_corpus(args.corpus)
            worker = PiWorker(args.worker_entrypoint, args.model, executable=args.node,
                              auth_path=args.auth_path, timeout=args.timeout, model_version=args.model_version)
            output_path = args.out / "experiment.json"
            existing = read_object(output_path, "style-sensitivity-experiment/v1") if output_path.is_file() else None
            result = run_sensitivity_plan(plan, worker, corpus, existing=existing,
                                          on_progress=lambda value: write_object(output_path, value))
            write_object(output_path, result)
            print(f"单参数实验：{result['completed_run_count']}/{result['planned_run_count']}")
            return 0 if result["completed_run_count"] == result["planned_run_count"] else 1
        if args.command == "sensitivity-report":
            plan = read_object(args.plan, "style-sensitivity-plan/v1")
            experiment = read_object(args.experiment, "style-sensitivity-experiment/v1")
            result = evaluate_sensitivity_plan(plan, experiment)
            write_object(args.out / "sensitivity-report.json", result)
            write_text(args.out / "sensitivity-report.md", render_sensitivity_report(result))
            print(f"单参数报告：{args.out / 'sensitivity-report.md'}")
            return 0
        if args.command == "pi-feedback-plan":
            experiment = read_object(args.experiment, "style-experiment/v1")
            require_selected_jobs(experiment, paired=args.arms == "paired")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            result = prepare_pi_feedback_plan(experiment, prompt, seed=args.seed, policy=args.policy)
            write_object(args.out / "feedback-plan.json", result)
            write_text(args.out / "feedback-plan.md", render_pi_feedback_plan(result))
            print(f"Pi 反馈计划：{args.out / 'feedback-plan.md'}")
            return 0
        if args.command == "pi-feedback-run":
            plan = read_object(args.plan, "style-pi-feedback-plan/v1")
            require_selected_jobs(plan, paired=args.arms == "paired")
            corpus = load_corpus(args.corpus)
            worker = PiWorker(args.worker_entrypoint, args.model, executable=args.node,
                              auth_path=args.auth_path, timeout=args.timeout, model_version=args.model_version)
            path = args.out / "feedback-run.json"
            existing = read_object(path, "style-pi-feedback-run/v1") if path.is_file() else None
            result = run_pi_feedback_plan(plan, worker, corpus, existing=existing,
                                          on_progress=lambda value: write_object(path, value))
            write_object(path, result)
            print(f"Pi 反馈修订：{result['completed_run_count']}/{result['planned_run_count']}")
            return 0 if result["completed_run_count"] == result["planned_run_count"] else 1
        if args.command == "pi-feedback-report":
            plan = read_object(args.plan, "style-pi-feedback-plan/v1")
            run = read_object(args.run, "style-pi-feedback-run/v1")
            original = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            revised = reconstruct_pi_feedback(plan, run, original)
            write_object(args.out / "revised-experiment.json", revised)
            write_text(args.out / "blind-packet.md", blind_packet(revised, prompt))
            write_text(args.out / "ratings.csv", ratings_template(revised))
            first_report = evaluate(original, prompt, {})
            revised_report = evaluate(revised, prompt, {})
            write_object(args.out / "revised-report.json", revised_report)
            write_text(args.out / "revised-report.md", render_markdown(revised_report))
            if revised["completed_run_count"] != revised["planned_run_count"]:
                print(f"Pi 反馈仅完成 {revised['completed_run_count']}/{revised['planned_run_count']}；逐篇报告已保存")
                return 1
            comparison = compare_pi_feedback(first_report, revised_report, original, revised)
            write_object(args.out / "feedback-comparison.json", comparison)
            write_text(args.out / "feedback-comparison.md", render_pi_feedback_comparison(comparison))
            print(f"Pi 反馈比较：{args.out / 'feedback-comparison.md'}")
            return 0
        if args.command == "web-plan":
            profile = read_object(args.profile, "stylometric-profile/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            corpus = load_corpus(args.corpus)
            cases = read_object(args.cases, "style-cases/v1")
            result = prepare_web_plan(profile, prompt, corpus, cases,
                                      repetitions=args.repetitions, seed=args.seed,
                                      arms=PAIRED_ARMS if args.arms == "paired" else ("target",),
                                      deep_think=args.deep_think)
            write_object(args.out / "web-plan.json", result)
            write_text(args.out / "web-plan.md", render_plan(result))
            print(f"网页实验计划：{args.out / 'web-plan.md'}")
            return 0
        if args.command == "web-import":
            plan = read_object(args.plan, "style-web-plan/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            corpus = load_corpus(args.corpus)
            result = import_web_answers(plan, prompt, corpus, args.answers,
                                        model=args.model, model_version=args.model_version,
                                        source_url=args.source_url,
                                        require_modes_off=args.require_modes_off)
            write_object(args.out / "experiment.json", result)
            write_text(args.out / "blind-packet.md", blind_packet(result, prompt))
            write_text(args.out / "ratings.csv", ratings_template(result))
            print(f"导入 {result['completed_run_count']}/{result['planned_run_count']} 篇；实验：{args.out / 'experiment.json'}")
            return 0 if result["completed_run_count"] == result["planned_run_count"] else 1
        if args.command == "web-feedback-plan":
            experiment = read_object(args.experiment, "style-experiment/v1")
            require_selected_jobs(experiment, paired=args.arms == "paired")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            result = prepare_feedback_plan(experiment, prompt, args.answers)
            write_object(args.out / "feedback-plan.json", result)
            write_text(args.out / "feedback-plan.md", render_feedback_plan(result))
            print(f"网页修订计划：{args.out / 'feedback-plan.md'}")
            return 0
        if args.command == "web-feedback-import":
            plan = read_object(args.plan, "style-web-feedback-plan/v1")
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            corpus = load_corpus(args.corpus)
            result = import_feedback_answers(plan, experiment, prompt, corpus, args.answers)
            write_object(args.out / "experiment.json", result)
            write_text(args.out / "blind-packet.md", blind_packet(result, prompt))
            write_text(args.out / "ratings.csv", ratings_template(result))
            print(f"导入修订 {result['completed_run_count']}/{result['planned_run_count']} 篇")
            return 0 if result["completed_run_count"] == result["planned_run_count"] else 1
        if args.command == "web-feedback-report":
            first_experiment = read_object(args.first_experiment, "style-experiment/v1")
            revised_experiment = read_object(args.revised_experiment, "style-experiment/v1")
            first_report = read_object(args.first_report, "style-report/v1")
            revised_report = read_object(args.revised_report, "style-report/v1")
            result = compare_feedback_reports(first_report, revised_report,
                                              first_experiment, revised_experiment)
            write_object(args.out / "feedback-comparison.json", result)
            write_text(args.out / "feedback-comparison.md", render_feedback_comparison(result))
            print(f"修订比较：{args.out / 'feedback-comparison.md'}")
            return 0
        if args.command == "report":
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            valid_ids = {str(row["blind_id"]) for row in experiment.get("runs", []) if row.get("status") == "completed"}
            ratings = load_ratings(args.ratings, valid_ids)
            result = evaluate(experiment, prompt, ratings)
            write_object(args.out / "report.json", result)
            write_text(args.out / "report.md", render_markdown(result))
            print(f"报告：{args.out / 'report.md'}；状态：{result['status']}")
            return 0
        if args.command == "length-audit":
            experiment = read_object(args.experiment, "style-experiment/v1")
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            result = audit_length(experiment, prompt, target_han=args.target_han,
                                  tolerance_han=args.tolerance_han)
            write_object(args.out / "length-audit.json", result)
            write_text(args.out / "length-audit.md", render_length_audit(result))
            print(f"近等长复算：{args.out / 'length-audit.md'}；有效配对：{result['included_pair_count']}")
            return 0
    except (ContractError, ValueError, FileNotFoundError, OSError, RuntimeError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

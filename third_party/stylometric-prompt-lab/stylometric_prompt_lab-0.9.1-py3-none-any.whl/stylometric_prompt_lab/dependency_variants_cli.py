"""Independent variant guidance, finite-pool selection and fresh-tree evaluation."""
import argparse
from pathlib import Path

from .corpus import load_corpus
from .dependency_feedback import render_result
from .dependency_variants import LIBRARY_SCHEMA, prepare_variants
from .io import ContractError, read_object, write_object, write_text
from .tree_candidate_evaluation import evaluate_selection
from .tree_candidate_selection import SCHEMA, select_candidates


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase',choices=['plan','select','evaluate'])
    for name in ('scope','library','selection','parse'):
        p.add_argument('--'+name,type=Path)
    p.add_argument('--batches',nargs='+')
    p.add_argument('--mode',choices=['all_targets','all_nonworse'],default='all_targets')
    p.add_argument('--node-budget',type=int,default=500000)
    p.add_argument('--corpus',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a = p.parse_args(argv)
    if a.out.exists():
        raise ContractError('variant output already exists')
    corpus = load_corpus(a.corpus)
    if a.phase == 'plan':
        if not a.scope:
            p.error('plan requires --scope')
        result = prepare_variants(read_object(a.scope,'style-tree-edit-scope/v1'),corpus)
        write_object(a.out/'variant-plan.json',result)
        write_text(a.out/'input.txt',result['input_text'])
        return
    if not a.library:
        p.error('select/evaluate require --library')
    library = read_object(a.library,LIBRARY_SCHEMA)
    if a.phase == 'select':
        if not a.batches:
            p.error('select requires --batches')
        result = select_candidates(library,a.batches,corpus,a.mode,a.node_budget)
        write_object(a.out/'selection.json',result)
        if result['candidate']:
            write_text(a.out/'candidate.txt',result['candidate']['text'])
        print(result['status'])
    else:
        if not a.selection or not a.parse:
            p.error('evaluate requires --selection and --parse')
        result = evaluate_selection(library,read_object(a.selection,SCHEMA),
                                    read_object(a.parse,'style-dependency-parse/v1'),corpus)
        write_object(a.out/'evaluation.json',result)
        write_text(a.out/'result.md',render_result(result['result']))
        print('统计接受：',result['result']['decision']['accepted'])


if __name__ == '__main__':
    main()

"""Offline CPU LTP adapter with strict model loading and complete source coverage."""

from __future__ import annotations

import importlib.metadata
import hashlib
import json
from numbers import Integral
import os
from pathlib import Path
import platform
import re

from .dependency_metrics import analyze_dependencies, compact, seal_parse
from .dependency_model import verify_model
from .io import ContractError

SEGMENTATION = "cn_terminal_or_newline/v1"
BOUNDARY = re.compile(r'''[。！？!?]+[”’」』"']*|[\r\n]+''')
SCHEME = {"name": "LTP_dependency", "punctuation_pos": ["wp"], "punctuation_relations": ["WP"]}
PACKAGE_PINS = {"ltp": "4.2.14", "ltp-core": "0.1.4", "ltp-extension": "0.1.13",
                "torch": "2.2.2+cpu", "transformers": "4.38.2",
                "huggingface-hub": "0.23.5", "numpy": "1.26.4", "tokenizers": "0.15.2"}


def split_sentences(text: str) -> list[dict]:
    if not isinstance(text, str) or not compact(text):
        raise ContractError("dependency analysis requires nonempty source text")
    spans, start = [], 0
    for match in BOUNDARY.finditer(text):
        spans.append((start, match.end()))
        start = match.end()
    if start < len(text):
        spans.append((start, len(text)))
    rows = []
    for start, end in spans:
        while start < end and text[start].isspace():
            start += 1
        while start < end and text[end - 1].isspace():
            end -= 1
        if start < end:
            rows.append({"id": len(rows) + 1, "start": start, "end": end, "text": text[start:end]})
    return rows


def runtime_versions() -> dict:
    try:
        versions = {name: importlib.metadata.version(name) for name in PACKAGE_PINS}
    except importlib.metadata.PackageNotFoundError as exc:
        raise ContractError("missing optional LTP environment; use .venv-ltp per dependency-syntax.md") from exc
    if versions != PACKAGE_PINS:
        raise ContractError(f"LTP adapter requires pinned isolated environment: {versions}")
    return {"python": platform.python_version(), "packages": versions,
            "installed_distributions": dict(sorted((item.metadata['Name'], item.version)
                                                    for item in importlib.metadata.distributions()))}


def _tokens(words: list, positions: list, dependency: dict) -> list[dict]:
    heads, labels = dependency.get("head"), dependency.get("label")
    if not isinstance(heads, list) or not isinstance(labels, list):
        raise ContractError("LTP returned an unsupported dependency format")
    if not len(words) == len(positions) == len(heads) == len(labels):
        raise ContractError("LTP word/POS/dependency output lengths differ")
    if any(isinstance(head, bool) or not isinstance(head, Integral) for head in heads):
        raise ContractError("LTP returned a noninteger dependency head")
    return [{"id": index, "form": word, "pos": pos, "head": int(head), "relation": relation}
            for index, (word, pos, head, relation) in enumerate(zip(words, positions, heads, labels), 1)]


def _load_official_model(directory: Path, torch):
    from ltp.nerual import LTP as OfficialNeuralLTP
    from transformers import ElectraTokenizerFast
    config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
    backbone = config["model"]["backbone"]["config"]
    if backbone["model_type"] != "electra" or backbone["max_position_embeddings"] != 512:
        raise ContractError("unexpected official Base2 backbone configuration")
    model = OfficialNeuralLTP(config=config).to("cpu")
    state = torch.load(directory / "pytorch_model.bin", map_location="cpu", weights_only=True)
    saved = state.get("backbone.embeddings.position_ids")
    expected = torch.arange(512, dtype=torch.int64).reshape(1, -1)
    if saved is None or saved.dtype != expected.dtype or saved.shape != expected.shape or not torch.equal(saved, expected):
        raise ContractError("legacy position_ids buffer differs from verified Electra index tensor")
    model.model.backbone.embeddings.register_buffer("position_ids", expected, persistent=True)
    model.load_state_dict(state, strict=True)
    model.tokenizer = ElectraTokenizerFast(vocab_file=str(directory / "vocab.txt"),
                                           tokenizer_file=str(directory / "tokenizer.json"))
    model.eval()
    compatibility = {"position_ids_buffer": "verified_arange_512_registered_persistent",
                     "position_ids_sha256": hashlib.sha256(expected.numpy().tobytes()).hexdigest(),
                     "learned_weights_modified": False, "loaded_state_key_count": len(state),
                     "loader": "official_ltp_neural_constructor_then_strict_state_dict",
                     "tokenizer_class": "ElectraTokenizerFast", "weights_only_deserialization": True}
    return model, compatibility


class DependencyParser:
    """Load once, parse independent documents with the same pinned CPU model."""

    def __init__(self, model_directory: Path):
        self.manifest = verify_model(model_directory)
        self.runtime = runtime_versions()
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
        try:
            import ltp
            import torch
        except ImportError as exc:
            raise ContractError("use .venv-ltp with the pinned CPU LTP environment") from exc
        torch.manual_seed(0)
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
        self.model, self.compatibility = _load_official_model(model_directory.resolve(), torch)
        self.runtime["ltp_module_version"] = ltp.__version__
        self.runtime["torch_module_version"] = torch.__version__
        if not self.model.supported_tasks.issuperset({"cws", "pos", "dep"}):
            raise ContractError("official model lacks requested CWS/POS/DEP tasks")

    def parse(self, text: str) -> dict:
        rows = split_sentences(text)
        for row in rows:
            length = len(self.model.tokenizer(row["text"], truncation=False)["input_ids"])
            row["model_token_count_with_specials"] = length
            if length > 512:
                raise ContractError(f"sentence {row['id']} has {length} model tokens (>512); no silent truncation")
        for row in rows:
            output = self.model.pipeline([row["text"]], tasks=["cws", "pos", "dep"])
            if len(output.cws) != 1 or len(output.pos) != 1 or len(output.dep) != 1:
                raise ContractError("LTP returned incomplete sentence output")
            row["tokens"] = _tokens(output.cws[0], output.pos[0], output.dep[0])
        source_hashes = {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                         for name in ("dependency_parser.py", "dependency_model.py", "dependency_metrics.py")}
        parsed = seal_parse({"text": text, "sentence_segmentation": SEGMENTATION,
                             "annotation_scheme": SCHEME, "sentences": rows,
                             "annotator": {"name": "LTP", "runtime": self.runtime,
                                           "model_manifest": self.manifest,
                                           "model_manifest_hash": self.manifest["model_manifest_hash"],
                                           "compatibility": self.compatibility,
                                           "tasks": ["cws", "pos", "dep"], "device": "cpu",
                                           "strict_state_dict": True, "seed": 0, "threads": 1,
                                           "deterministic_algorithms": True,
                                           "source_hashes": source_hashes}})
        analyze_dependencies(parsed)
        return parsed

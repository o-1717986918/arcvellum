"""Reproducible paired experiments captured from a model's browser UI.

The browser is operated outside this module.  This module never claims that a
missing answer was generated, and it records the exact prompt shown in the UI.
"""

from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any

from .corpus import Corpus
from .experiment import BASELINE_SYSTEM, DEFAULT_ACCEPTANCE, _validate_inputs, copy_risk, validate_cases
from .io import ContractError, digest
from .experiment_design import PAIRED_ARMS, TARGET_ONLY, mark_design, selected_arms, validate_design


PLAN_SCHEMA = "style-web-plan/v1"


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _user_task(brief: str, *, length_free: bool) -> str:
    return (brief + "\n写一个完整的现代中文叙事场景；篇幅由事件需要决定。" if length_free else
            brief + "\n写约 600–900 汉字的现代中文叙事场景。")


def prepare_web_plan(profile: dict[str, Any], prompt: dict[str, Any], corpus: Corpus,
                     cases_value: dict[str, Any], *, repetitions: int = 2,
                     seed: int = 20260929, arms: tuple[str, ...] = ("target",),
                     deep_think: bool | None = True) -> dict[str, Any]:
    _validate_inputs(profile, prompt, corpus, repetitions)
    arms = selected_arms(arms)
    if deep_think is None and arms != PAIRED_ARMS:
        raise ContractError("unrecorded modes are only allowed for historical paired plans")
    cases = validate_cases(cases_value)
    jobs = [(case, repetition, arm) for case in cases
            for repetition in range(1, repetitions + 1)
            for arm in arms]
    random.Random(seed).shuffle(jobs)
    length_free = (prompt.get("derived_structure") or {}).get("length_policy") == "descriptive_only"
    rows = []
    for number, (case, repetition, arm) in enumerate(jobs, 1):
        system = BASELINE_SYSTEM if arm == "baseline" else str(prompt["prompt_markdown"])
        user = _user_task(case["brief"], length_free=length_free)
        combined = f"【写作约束】\n{system}\n\n【场景任务】\n{user}"
        rows.append({
            "blind_id": f"B{number:03d}", "case_id": case["case_id"],
            "topic": case["topic"], "repetition": repetition, "arm": arm,
            "system_prompt_sha256": _sha(system), "user_prompt_sha256": _sha(user),
            "web_prompt": combined, "web_prompt_sha256": _sha(combined),
            "answer_file": f"answers/B{number:03d}.txt",
        })
    plan = {
        "schema": PLAN_SCHEMA, "profile_sha256": profile["profile_sha256"],
        "prompt_sha256": prompt["prompt_sha256"], "cases_sha256": digest(cases_value),
        "source_digest": digest([item.public() for item in corpus.sources]),
        "seed": seed, "repetitions": repetitions, "cases": cases,
        "planned_run_count": len(rows), "jobs": rows,
        "acceptance": None if length_free else dict(DEFAULT_ACCEPTANCE),
        "browser_surface": "DeepSeek web UI; one fresh chat per job; model label copied from UI",
        "warnings": list(dict.fromkeys([*corpus.warnings, *(profile.get("warnings") or [])])),
    }
    if length_free:
        plan.update({"plan_version": "0.2.0", "length_policy": "descriptive_only",
                     "objective": "style_first"})
    mark_design(plan, arms)
    if arms == ("target",):
        plan["acceptance"] = None
    if deep_think is not None:
        plan.update(plan_version="0.3.0", web_modes={"deep_think_pressed": "true" if deep_think else "false",
                                                    "web_search_pressed": "false"})
    plan["plan_sha256"] = digest(plan)
    return plan


def render_plan(plan: dict[str, Any]) -> str:
    title = "# 网页端参数组实验执行单" if plan.get("experiment_design") == TARGET_ONLY else "# 网页端配对实验执行单"
    lines = [title, "",
             "每个盲号在一个新会话中运行。将 `web_prompt` 原样提交，"
             "把最终正文以 UTF-8 保存到指定 TXT 文件。不要用上一轮输出继续提问。",
             "记录页面展示的模型名称；网页端不暴露的修订号写 `unreported`。",
             ("篇幅只记录，不参加验收；完成后运行 style-audit。" if
              plan.get("length_policy") == "descriptive_only" else
              "历史计划按原篇幅口径复算。"), "",
             f"计划哈希：`{plan['plan_sha256']}`", ""]
    if plan.get("web_modes"):
        lines += [f"提交前核验：深度思考 {'开启' if plan['web_modes']['deep_think_pressed'] == 'true' else '关闭'}、"
                  "智能搜索关闭。保存逐篇模式元数据；只采集最终正文，不将思考过程计入分析。", ""]
    for row in plan["jobs"]:
        lines.extend([f"## {row['blind_id']} · {row['case_id']} · 第 {row['repetition']} 次",
                      "", f"答案文件：`{row['answer_file']}`", "",
                      "```text", row["web_prompt"], "```", ""])
    return "\n".join(lines)


def import_web_answers(plan: dict[str, Any], prompt: dict[str, Any], corpus: Corpus,
                       answer_root: Path, *, model: str, model_version: str = "unreported",
                       source_url: str = "https://chat.deepseek.com/",
                       require_modes_off: bool = False) -> dict[str, Any]:
    by_case, length_free = _validate_web_import(plan, prompt, corpus, model, source_url, require_modes_off)
    root = answer_root.resolve()
    runs = []
    seen = set()
    for row in plan["jobs"]:
        blind_id = str(row.get("blind_id") or "")
        if blind_id in seen or not blind_id:
            raise ContractError("web plan contains repeated or blank blind IDs")
        seen.add(blind_id)
        if _sha(str(row.get("web_prompt") or "")) != row.get("web_prompt_sha256"):
            raise ContractError(f"web prompt has changed for {blind_id}")
        case = by_case[row["case_id"]]
        system = BASELINE_SYSTEM if row["arm"] == "baseline" else str(prompt["prompt_markdown"])
        user = _user_task(case["brief"], length_free=length_free)
        expected_web = f"【写作约束】\n{system}\n\n【场景任务】\n{user}"
        if (row.get("topic") != case["topic"] or row["web_prompt"] != expected_web
                or row.get("system_prompt_sha256") != _sha(system)
                or row.get("user_prompt_sha256") != _sha(user)):
            raise ContractError(f"web plan job content differs from the registered task: {blind_id}")
        answer_file = row.get("answer_file")
        if answer_file != f"answers/{blind_id}.txt":
            raise ContractError(f"invalid answer path for {blind_id}")
        path = (root / answer_file).resolve()
        if root not in path.parents:
            raise ContractError("answer path escapes the answer directory")
        answer, answer_source_url, browser_modes = _captured_answer(path, blind_id, plan, source_url, require_modes_off)
        status = "completed" if answer else "failed"
        runs.append({
            "blind_id": blind_id, "case_id": row["case_id"], "topic": row["topic"],
            "repetition": row["repetition"], "arm": row["arm"], "status": status,
            "answer": answer, "failure": "" if answer else f"missing or empty {answer_file}",
            "system_prompt_sha256": row["system_prompt_sha256"],
            "user_prompt_sha256": row["user_prompt_sha256"],
            "web_prompt_sha256": row["web_prompt_sha256"],
            "answer_sha256": _sha(answer) if answer else None,
            "browser_source_url": answer_source_url, "worker_version": "web-ui",
            "browser_modes": browser_modes,
            "model": model.strip(), "model_version": model_version,
            "events": [], "copy_risk": copy_risk(answer, corpus) if answer else None,
        })
    return _imported_experiment(plan, model, model_version, runs)


def _validate_web_import(plan, prompt, corpus, model, source_url, require_modes_off):
    if plan.get("schema") != PLAN_SCHEMA or plan.get("plan_sha256") != digest(
            {key: value for key, value in plan.items() if key != "plan_sha256"}):
        raise ContractError("web plan schema or hash is invalid")
    validate_design(plan)
    if plan.get("plan_version") == "0.3.0" and (plan.get("web_modes") not in (
            {"deep_think_pressed": "true", "web_search_pressed": "false"},
            {"deep_think_pressed": "false", "web_search_pressed": "false"})):
        raise ContractError("new web plan needs explicit thinking/search modes")
    if require_modes_off and (plan.get("web_modes") or {}).get("deep_think_pressed") == "true":
        raise ContractError("legacy modes-off requirement conflicts with thinking plan")
    if plan.get("prompt_sha256") != prompt.get("prompt_sha256") or plan.get("profile_sha256") != prompt.get("profile_sha256"):
        raise ContractError("web plan and prompt do not match")
    if _sha(str(prompt.get("prompt_markdown") or "")) != prompt.get("prompt_sha256"):
        raise ContractError("prompt text hash is invalid")
    if digest({key: value for key, value in prompt.items()
               if key != "prompt_artifact_sha256"}) != prompt.get("prompt_artifact_sha256"):
        raise ContractError("prompt artifact hash is invalid")
    if plan.get("source_digest") != digest([item.public() for item in corpus.sources]):
        raise ContractError("web plan and corpus do not match")
    if plan.get("planned_run_count") != len(plan.get("jobs") or []):
        raise ContractError("web plan run count is invalid")
    length_free = (prompt.get("derived_structure") or {}).get("length_policy") == "descriptive_only"
    if length_free != (plan.get("length_policy") == "descriptive_only"):
        raise ContractError("web plan length policy differs from prompt")
    if length_free and (plan.get("objective") != "style_first" or plan.get("plan_version") not in ("0.2.0", "0.3.0")
                        or plan.get("acceptance") is not None):
        raise ContractError("style-first web plan contract is invalid")
    cases = validate_cases({"schema": "style-cases/v1", "cases": plan.get("cases")})
    by_case = {row["case_id"]: row for row in cases}
    repetitions = int(plan.get("repetitions") or 0)
    expected = {(case["case_id"], repetition, arm) for case in cases
                for repetition in range(1, repetitions + 1)
                for arm in (("target",) if plan.get("experiment_design") == TARGET_ONLY else PAIRED_ARMS)}
    observed = [(row.get("case_id"), row.get("repetition"), row.get("arm"))
                for row in plan["jobs"]]
    if len(observed) != len(expected) or set(observed) != expected:
        raise ContractError("web plan does not contain exactly one of every registered job")
    if not model.strip():
        raise ContractError("model label must be supplied from the browser UI")
    if not source_url.startswith("https://chat.deepseek.com/"):
        raise ContractError("source URL must be a DeepSeek chat URL")
    return by_case, length_free


def _captured_answer(path, blind_id, plan, source_url, require_modes_off):
    answer = path.read_text(encoding="utf-8-sig").strip() if path.is_file() else ""
    answer_source_url = source_url
    browser_modes = {"deep_think_pressed": "unrecorded", "web_search_pressed": "unrecorded"}
    metadata_path = path.with_suffix(".meta.json")
    if answer and (require_modes_off or plan.get("web_modes")) and not metadata_path.is_file():
        raise ContractError(f"browser mode evidence is missing for {blind_id}")
    if answer and metadata_path.is_file():
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ContractError(f"invalid browser capture metadata for {blind_id}") from exc
        answer_source_url = str(metadata.get("source_url") or "")
        browser_modes = {key: str(metadata.get(key) or "unrecorded")
                         for key in browser_modes}
        if (metadata.get("blind_id") != blind_id
                or metadata.get("plan_sha256") != plan["plan_sha256"]
                or metadata.get("answer_sha256") != _sha(answer)
                or metadata.get("character_count") != len(answer)
                or not answer_source_url.startswith("https://chat.deepseek.com/a/chat/")):
            raise ContractError(f"browser capture metadata does not match {blind_id}")
        if require_modes_off and any(value != "false" for value in browser_modes.values()):
            raise ContractError(f"browser modes were not verified off for {blind_id}")
        if plan.get("web_modes") and browser_modes != plan["web_modes"]:
            raise ContractError(f"browser modes differ from frozen plan for {blind_id}")
    return answer, answer_source_url, browser_modes


def _imported_experiment(plan, model, model_version, runs):
    completed = sum(row["status"] == "completed" for row in runs)
    result = {
        "schema": "style-experiment/v1", "profile_sha256": plan["profile_sha256"],
        "prompt_sha256": plan["prompt_sha256"], "cases_sha256": plan["cases_sha256"],
        "web_plan_sha256": plan["plan_sha256"], "worker_version": "web-ui",
        "model": model.strip(), "model_version": model_version,
        "seed": plan["seed"], "repetitions": plan["repetitions"],
        "planned_run_count": len(runs), "completed_run_count": completed,
        "stopped_reason": "" if completed == len(runs) else "some browser answers are missing",
        "cases": plan["cases"], "runs": runs,
        "acceptance": plan.get("acceptance"),
        "warnings": [*plan["warnings"],
                     "网页单输入框按写作约束/场景任务顺序提交，与 Pi system/user 角色实验不可直接合并。",
                     "网页模型标签由导入时声明；每篇会话 URL、正文哈希和模式状态取自采集元数据，"
                     "导入器不能独立证明网页生成真实性，需保留会话记录。"],
    }
    if plan.get("experiment_design"):
        result["experiment_design"] = plan["experiment_design"]
    if plan.get("web_modes"):
        result["web_modes"] = plan["web_modes"]
    return result

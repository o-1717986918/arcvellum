"""Export compact whole-text guidance, preserve response and require a new tree."""
import argparse
from pathlib import Path

from .corpus import load_corpus
from .dependency_compact_revision import SCHEMA,evaluate_revision,import_revision,prepare_revision
from .dependency_feedback import render_result
from .io import ContractError,read_object,write_object,write_text


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('phase',choices=['plan','import','evaluate'])
    for name in ('joint','plan','response','parse'):p.add_argument('--'+name,type=Path)
    p.add_argument('--corpus',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(argv)
    if a.out.exists():raise ContractError('compact revision output already exists')
    corpus=load_corpus(a.corpus)
    if a.phase=='plan':
        if not a.joint:p.error('plan requires --joint')
        plan=prepare_revision(read_object(a.joint,'style-joint-guidance/v1'),corpus)
        write_object(a.out/'revision-plan.json',plan);write_text(a.out/'input.txt',plan['input_text']);return
    if not a.plan or not a.response:p.error('import/evaluate require --plan and --response')
    plan=read_object(a.plan,SCHEMA);raw=a.response.read_text(encoding='utf-8')
    if a.phase=='import':
        candidate,record=import_revision(plan,raw,corpus)
        write_text(a.out/'raw-response.txt',raw);write_text(a.out/'candidate.txt',candidate);write_object(a.out/'import.json',record)
    else:
        if not a.parse:p.error('evaluate requires --parse')
        result=evaluate_revision(plan,raw,read_object(a.parse,'style-dependency-parse/v1'),corpus)
        write_object(a.out/'result.json',result);write_text(a.out/'result.md',render_result(result['result']))
        print('统计接受：',result['result']['decision']['accepted'])


if __name__=='__main__':main()

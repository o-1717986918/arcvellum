"""Compile observed ranges into an actionable literary prompt."""

from __future__ import annotations

import hashlib
import math
from typing import Any

from .io import ContractError, digest
from .dependency_targets import attach_prompt
from .extended_metrics import SECONDARY_AXES, secondary_summary_key
from .metrics import AXES


COMPILER_VERSION = "0.3.0"
CALIBRATED_COMPILER_VERSION = "0.4.0"
STRICT_COMPILER_VERSION = "0.5.0"
REBALANCED_COMPILER_VERSION = "0.6.0"
BOUNDED_DIALOGUE_COMPILER_VERSION = "0.7.0"
PARAGRAPH_JSON_COMPILER_VERSION = "0.8.0"
SUSTAINED_COMPILER_VERSION = "0.9.0"
BUDGETED_JSON_COMPILER_VERSION = "0.10.0"
STYLE_FIRST_COMPILER_VERSION = "0.11.0"
LINKED_STYLE_COMPILER_VERSION = "0.12.0"
PRIMARY_GUARDED_COMPILER_VERSION = "0.13.0"
COUPLED_DISTRIBUTION_COMPILER_VERSION = "0.14.0"


def validate_controls(profile: dict[str, Any], controls: dict[str, Any]) -> dict[str, dict[str, float | str]]:
    if controls.get("schema") != "style-controls/v1":
        raise ContractError("controls must have schema style-controls/v1")
    if controls.get("profile_sha256") != profile.get("profile_sha256"):
        raise ContractError("controls belong to a different profile")
    rows = controls.get("axes")
    if not isinstance(rows, dict) or set(rows) != set(AXES):
        raise ContractError("controls must provide exactly the four supported axes")
    clean: dict[str, dict[str, float | str]] = {}
    for key, unit in AXES.items():
        row = rows[key]
        if not isinstance(row, dict) or row.get("unit") != unit:
            raise ContractError(f"{key} needs unit {unit}")
        try:
            lower, upper = float(row["min"]), float(row["max"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ContractError(f"{key} needs numeric min and max") from exc
        if not math.isfinite(lower) or not math.isfinite(upper) or lower < 0 or lower > upper:
            raise ContractError(f"{key} has invalid target range")
        if key == "dialogue_share" and upper > 1:
            raise ContractError("dialogue_share must be within 0..1")
        if key in {"sentence_length_han", "paragraph_length_han"} and lower < 1:
            raise ContractError(f"{key} lower bound must be at least 1")
        clean[key] = {"min": lower, "max": upper, "unit": unit}
    return clean


def validate_secondary_controls(profile: dict[str, Any], controls: dict[str, Any]) -> dict[str, dict[str, float | str]]:
    rows = controls.get("secondary_axes") or {}
    if not isinstance(rows, dict) or (rows and set(rows) != set(SECONDARY_AXES)):
        raise ContractError("secondary_axes must provide all supported indicators or be absent")
    if not rows:
        return {}
    summaries = profile.get("extended_window_summary") or {}
    clean = {}
    for key, unit in SECONDARY_AXES.items():
        source_key = secondary_summary_key(key)
        if not isinstance(summaries.get(source_key), dict) or not summaries[source_key].get("window_count"):
            raise ContractError(f"{key} is not measured in this profile")
        row = rows[key]
        if not isinstance(row, dict) or row.get("unit") != unit:
            raise ContractError(f"{key} needs unit {unit}")
        try:
            lower, upper = float(row["min"]), float(row["max"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ContractError(f"{key} needs numeric min and max") from exc
        floor = 1 if key in {"clause_segments_per_sentence_proxy", "word_length_mean_han"} else 0
        if not math.isfinite(lower) or not math.isfinite(upper) or lower < floor or lower > upper:
            raise ContractError(f"{key} has invalid target range")
        if key in {"short_sentence_share_le20_han", "long_sentence_share_gt30_han",
                   "word_mattr_50", "activity_v_over_v_plus_a",
                   "nominality_n_over_n_plus_v", "function_pos_share_proxy"} and upper > 1:
            raise ContractError(f"{key} must be within 0..1")
        clean[key] = {"min": lower, "max": upper, "unit": unit}
    if (clean["short_sentence_share_le20_han"]["min"] +
            clean["long_sentence_share_gt30_han"]["min"] > 1):
        raise ContractError("short and long sentence minimum shares cannot exceed 1 together")
    return clean


def validate_lexical_targets(profile: dict[str, Any], controls: dict[str, Any]) -> list[dict[str, float | str]]:
    rows = controls.get("lexical_targets") or []
    if not isinstance(rows, list) or len(rows) > 6:
        raise ContractError("lexical_targets must be a list of at most six measured function words")
    source = {row["word"]: row for row in
              (profile.get("extended_diagnostics") or {}).get("grammar", {}).get("function_word_top", [])}
    clean = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ContractError("lexical target must be an object")
        word = str(row.get("word") or "")
        if word in seen or word not in source or row.get("unit") != "次/千词元":
            raise ContractError("lexical target must name a unique measured function word")
        try:
            lower, upper = float(row["min"]), float(row["max"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ContractError("lexical target needs numeric min and max") from exc
        if not math.isfinite(lower) or not math.isfinite(upper) or lower < 0 or lower > upper or upper > 1000:
            raise ContractError("lexical target has invalid range")
        clean.append({"word": word, "min": lower, "max": upper, "unit": "次/千词元"})
        seen.add(word)
    return clean


def _instruction(key: str, target: dict[str, float | str], observed: float) -> str:
    lower, upper = float(target["min"]), float(target["max"])
    middle = (lower + upper) / 2
    tendency = "保持原语料附近" if abs(middle - observed) <= max(0.01, observed * 0.05) else (
        "比原语料更低" if middle < observed else "比原语料更高"
    )
    if key == "sentence_length_han":
        return f"句群节奏：平均句长目标约 {lower:g}–{upper:g} 汉字/句（{tendency}）。多数句子保留完整动作或判断，避免连续碎句；长短句自然交替。"
    if key == "paragraph_length_han":
        return f"段落呼吸：平均段长目标约 {lower:g}–{upper:g} 汉字/段（{tendency}）。通常让一个段落容纳相连的两三句，在动作、对白或认知转折处换段。"
    if key == "dialogue_share":
        return f"对白占比：对白正文约占 {lower * 100:g}%–{upper * 100:g}%（{tendency}）。让每次发言包含完整判断或反应，以较少轮次推动关系和选择。"
    return f"标点总密度：约 {lower:g}–{upper:g} 处/千汉字（{tendency}）。此数包含引号；用逗号与句号组织停顿，避免碎句和密集引号一起抬高总数。"


def _secondary_instruction(key: str, target: dict[str, float | str], observed: float) -> str:
    lower, upper = float(target["min"]), float(target["max"])
    if key == "short_sentence_share_le20_han":
        return (f"短句（≤20 汉字）占比：来源窗口中位数 {observed:.1%}，目标 {lower:.0%}–{upper:.0%}。"
                "只在动作、发现与判断需要时用短句，避免一两个词构成独立句。")
    if key == "long_sentence_share_gt30_han":
        return (f"长句（>30 汉字）占比：来源 {observed:.1%}，目标 {lower:.0%}–{upper:.0%}。"
                "只在交代必要的因果或感官层次时保留较长句。")
    if key == "clause_segments_per_sentence_proxy":
        return (f"逗号、分号、冒号切出的片段：来源 {observed:.2f}、目标 {lower:g}–{upper:g} 片段/句。"
                "减少多层逗号串接，在信息转折处用句号；这是标点代理，不是句法深度。")
    if key == "quote_spans_per_1000_han":
        return (f"成对引号片段：来源 {observed:.1f}、目标 {lower:g}–{upper:g} 段/千汉字。"
                "把对白集中为较完整的发言，不将一两字应答单独套引号；引号本身计入标点密度。")
    if key == "word_length_mean_han":
        return (f"平均词长：来源 {observed:.2f}、目标 {lower:g}–{upper:g} 汉字/词（jieba 分词口径）。"
                "以常用、具体的动词和名词推进叙述，避免堆叠冗长抽象词。")
    if key == "word_mattr_50":
        return (f"50 词滑窗词汇多样性 MATTR：来源 {observed:.2f}、目标 {lower:g}–{upper:g}。"
                "减少近距离原词复用，换用符合场景的具体表达；不要为追求新词牺牲清楚表达。")
    if key == "activity_v_over_v_plus_a":
        return (f"动词比 V/(V+A)：来源 {observed:.1%}、目标 {lower:.0%}–{upper:.0%}。"
                "以动作和选择推动场景，同时保留必要描写；这是自动词性比率。")
    if key == "nominality_n_over_n_plus_v":
        return (f"名词比 N/(N+V)：来源 {observed:.1%}、目标 {lower:.0%}–{upper:.0%}。"
                "让具体人物和事物与动作相配，不堆砌抽象名词。")
    return (f"功能类词性占比：来源 {observed:.1%}、目标 {lower:.0%}–{upper:.0%}。"
            "用自然的连接和修饰维持句子关系，不重复虚词凑数；此口径不含人称代词。")


def _calibrated_lines(targets: dict[str, dict[str, float | str]],
                      secondary: dict[str, dict[str, float | str]],
                      lexical: list[dict[str, float | str]], target_han: int,
                      *, strict: bool = False) -> tuple[list[str], dict[str, Any]]:
    def center(band: dict[str, float | str]) -> float:
        return (float(band["min"]) + float(band["max"])) / 2

    sentence_count = max(1, round(target_han / center(targets["sentence_length_han"])))
    paragraph_count = max(1, round(target_han / center(targets["paragraph_length_han"])))
    sentences_per_paragraph = sentence_count / paragraph_count
    quote_band = secondary.get("quote_spans_per_1000_han")
    quote_count = round(target_han * center(quote_band) / 1000) if quote_band else 0
    dialogue_han = round(target_han * center(targets["dialogue_share"]))
    quote_length = round(dialogue_han / quote_count) if quote_count else 0
    paragraph_floor = max(1, math.ceil(target_han / float(targets["paragraph_length_han"]["max"])))
    paragraph_ceiling = max(paragraph_floor, math.floor(target_han / float(targets["paragraph_length_han"]["min"])))
    quote_floor = max(1, math.ceil(target_han * float(quote_band["min"]) / 1000)) if quote_band else 0
    quote_ceiling = max(quote_floor, math.floor(target_han * float(quote_band["max"]) / 1000)) if quote_band else 0
    lower_han, upper_han = round(target_han * .8), round(target_han * 1.2)
    derived: dict[str, Any] = {"target_han": target_han, "min_han": lower_han,
                                       "max_han": upper_han, "sentence_count_approx": sentence_count,
                                       "paragraph_count_approx": paragraph_count,
                                       "sentences_per_paragraph_approx": round(sentences_per_paragraph, 1),
                                       "quote_count_approx": quote_count,
                                       "quote_length_han_approx": quote_length}
    if strict:
        derived.update({"paragraph_count_range": [paragraph_floor, paragraph_ceiling],
                        "quote_count_range": [quote_floor, quote_ceiling]})
    lines = ["# 文学风格执行提示词 · 结构校准版", "",
             "你是现代中文叙事写作者。依据场景任务写原创、完整、自然的正文。先确定人物的选择、障碍和后果，保证事实与因果清楚。",
             f"正文以约 {target_han} 汉字为中心，严格落在 {lower_han}–{upper_han} 汉字内；输出前检查并删去重复解释。", "",
             "## 先组织句段", "",
             f"目标句长 {float(targets['sentence_length_han']['min']):g}–{float(targets['sentence_length_han']['max']):g} 汉字/句，"
             f"段长 {float(targets['paragraph_length_han']['min']):g}–{float(targets['paragraph_length_han']['max']):g} 汉字/段。"]
    if strict:
        lines[-1] += (f"在 {target_han} 汉字附近，正文应实际排成 {paragraph_floor}–{paragraph_ceiling} 个非空段落，"
                      f"以约 {paragraph_count} 段为中心。每段独占一行，段末换行；每段通常 2–4 个完整句。"
                      "输出前数非空行，过少就按动作和认识的转折拆开长段，过多就合并相连短段。")
    else:
        lines[-1] += (f"在 {target_han} 汉字附近，可先按约 {paragraph_count} 段、每段通常 2–4 个完整句构思；"
                      "用真正的换行分段，连续动作不要拆成一字一句。")
    if "short_sentence_share_le20_han" in secondary and "long_sentence_share_gt30_han" in secondary:
        short = secondary["short_sentence_share_le20_han"]
        long = secondary["long_sentence_share_gt30_han"]
        lines.append(f"短句（≤20 汉字）约 {float(short['min']):.0%}–{float(short['max']):.0%}，"
                     f"长句（>30 汉字）约 {float(long['min']):.0%}–{float(long['max']):.0%}；"
                     "短句仍要有完整动作或判断，长句只承担必要的因果层次。")
    if "clause_segments_per_sentence_proxy" in secondary:
        band = secondary["clause_segments_per_sentence_proxy"]
        lines.append(f"逗号、分号、冒号切出的片段约 {float(band['min']):g}–{float(band['max']):g} 个/句；"
                     "用句号结束一个完整判断，避免逗号串接。")
    lines.extend(["", "## 再安排对白与停顿", "",
                  f"对白正文占比目标 {float(targets['dialogue_share']['min']):.0%}–{float(targets['dialogue_share']['max']):.0%}。"
                  "让每次发言改变人物的理解或选择，并用动作承接；不要靠一两字应答增加轮次。"])
    if quote_count and quote_length >= 10:
        if strict:
            lines.append(f"在约 {target_han} 汉字的场景中，全篇使用 {quote_floor}–{quote_ceiling} 组成对引号，"
                         f"以约 {quote_count} 组为中心。每组正文通常包含约 {quote_length} 汉字的完整话意；"
                         "把同一人的连续发言放在一组引号中，避免拆成零碎轮次。输出前核对引号组数。")
        else:
            lines.append(f"在约 {target_han} 汉字的场景中，可构思约 {quote_count} 段有内容的引号发言，"
                         f"每段通常能承载约 {quote_length} 汉字的完整话意。"
                         "这是对白占比与引号密度相容时的结构参考，不强迫每段等长。")
    if quote_band:
        lines.append(f"引号片段目标 {float(quote_band['min']):g}–{float(quote_band['max']):g} 段/千汉字。")
    punctuation = targets["punctuation_per_1000_han"]
    lines.append(f"标点总密度目标 {float(punctuation['min']):g}–{float(punctuation['max']):g} 处/千汉字，"
                 "含引号。优先用逗号与句号组织停顿，不以感叹号、破折号或密集引号凑数。")
    lines.extend(["", "## 词汇与语法", ""])
    if strict:
        lines.append("用具体人物、物件、地点和动作构成叙事；在动作间保留必要的具体状态描写。"
                     "每段自然交代时间、方位或因果关系，可使用『在……时』『因为……』『把……』『……的……』『……了』等合适句式；"
                     "这些词要服务句义，不逐字凑频率。")
    else:
        lines.append("用具体人物、物件、地点和动作构成叙事；在动作间保留必要的具体状态描写。"
                     "助词与连接词只用于讲清时间、地点、完成与句间关系，不逐字凑频率。")
    if secondary:
        for key, label in (("word_length_mean_han", "平均词长"), ("word_mattr_50", "MATTR50"),
                           ("activity_v_over_v_plus_a", "动词比 V/(V+A)"),
                           ("nominality_n_over_n_plus_v", "名词比 N/(N+V)"),
                           ("function_pos_share_proxy", "功能类词性占比")):
            if key in secondary:
                band = secondary[key]
                lines.append(f"- {label}：{float(band['min']):g}–{float(band['max']):g} {band['unit']}。")
    if lexical:
        lines.append("- 高频语法词参考：" + "；".join(
            f"「{row['word']}」{float(row['min']):g}–{float(row['max']):g} 次/千词元" for row in lexical) +
            "。只在语义自然时使用，不重复一个句式凑数。")
    lines.extend(["", "## 输出前自查", "",
                  "核对事件因果、人物动机、篇幅与换段；再检查对白是否由完整发言组成。"
                  "若某个统计目标与清楚表达冲突，保留清楚表达，让评测记录偏差。",
                  "不要照搬参考语料的人物、专名、事件或连续原句。只输出正文，不附指标、计划或自评。", ""])
    return lines, derived


def _rebalanced_lines(targets: dict[str, dict[str, float | str]],
                      secondary: dict[str, dict[str, float | str]],
                      lexical: list[dict[str, float | str]], target_han: int,
                      *, bounded_dialogue: bool = False) -> tuple[list[str], dict[str, Any]]:
    """Keep all measured targets visible while prioritizing coupled writing actions."""
    _, derived = _calibrated_lines(targets, secondary, lexical, target_han)
    lo, hi = derived["min_han"], derived["max_han"]
    sentence = targets["sentence_length_han"]
    paragraph = targets["paragraph_length_han"]
    dialogue = targets["dialogue_share"]
    punctuation = targets["punctuation_per_1000_han"]
    paragraph_min = math.ceil(target_han / float(paragraph["max"]))
    paragraph_max = max(paragraph_min, math.floor(target_han / float(paragraph["min"])))
    lines = ["# 文学风格执行提示词 · 对白边界实验版" if bounded_dialogue else
             "# 文学风格执行提示词 · 联动校准实验版", "",
             "你是现代中文叙事写作者。先在心中确认人物的目的、阻碍、决定与后果，然后只输出原创、完整、自然的正文。",
             f"全文以约 {target_han} 汉字为中心，严格在 {lo}–{hi} 汉字内。不要用重复解释充篇幅。", "",
             "## 句段与节奏", "",
             f"平均句长目标 {float(sentence['min']):g}–{float(sentence['max']):g} 汉字/句，"
             f"平均段长 {float(paragraph['min']):g}–{float(paragraph['max']):g} 汉字/段。"
             f"在 {target_han} 汉字附近约分 {paragraph_min}–{paragraph_max} 个自然段；"
             "让每段承载一个相连的动作或认识，不把每句单独换行。"]
    short = secondary.get("short_sentence_share_le20_han")
    long = secondary.get("long_sentence_share_gt30_han")
    if short and long:
        long_min = max(1, round(derived["sentence_count_approx"] * float(long["min"])))
        long_max = max(long_min, round(derived["sentence_count_approx"] * float(long["max"])))
        lines.append(f"≤20 汉字短句目标 {float(short['min']):.0%}–{float(short['max']):.0%}；"
                     f">30 汉字长句目标 {float(long['min']):.0%}–{float(long['max']):.0%}。"
                     f"整篇可保留约 {long_min}–{long_max} 个承担因果或复杂行动的长句；"
                     "不要把同一判断拆成连续的碎短句。")
    clause = secondary.get("clause_segments_per_sentence_proxy")
    if clause:
        lines.append(f"逗号、分号、冒号形成的片段约 {float(clause['min']):g}–{float(clause['max']):g} 个/句；"
                     "让逗号承接动作，让句号结束判断。")
    lines.extend(["", "## 对白与标点要一起安排", "",
                  f"直接引号中的对白正文占全部汉字 {float(dialogue['min']):.0%}–{float(dialogue['max']):.0%}；"
                  f"在约 {target_han} 汉字时约为 {round(target_han * float(dialogue['min']))}–"
                  f"{round(target_han * float(dialogue['max']))} 个汉字。"
                  + ("让直接发言只出现在发现事实、交涉和决定的关键节点；其余用动作、感知和后果推进。"
                     "把短问短答融入叙述，保留有信息的直接对白。" if bounded_dialogue else
                     "保留揭示事实、回应和决定的直接发言；把无新信息的短问短答融入叙述，"
                     "但不要把所有发言都改成间接转述。")])
    quotes = secondary.get("quote_spans_per_1000_han")
    if quotes:
        count_min = math.ceil(target_han * float(quotes["min"]) / 1000)
        count_max = max(count_min, math.floor(target_han * float(quotes["max"]) / 1000))
        if bounded_dialogue:
            planned_max = min(count_max, max(count_min, target_han // 105))
            per_min = math.ceil(target_han * float(dialogue["min"]) / planned_max)
            per_max = math.ceil(target_han * float(dialogue["max"]) / count_min)
            lines.append(f"成对引号片段目标 {float(quotes['min']):g}–{float(quotes['max']):g} 段/千汉字；"
                         f"在约 {target_han} 汉字的草稿中，优先安排 {count_min}–{planned_max} 段完整直接发言，"
                         f"每段大致 {per_min}–{per_max} 汉字。"
                         "把同一人的连续话意并成一段；直接发言与相应动作可以写在同一自然段。"
                         "草稿若出现一问一答的短回合，先合并回合，再检查对白正文占比。")
        else:
            lines.append(f"成对引号片段目标 {float(quotes['min']):g}–{float(quotes['max']):g} 段/千汉字；"
                         f"在约 {target_han} 汉字时可安排 {count_min}–{count_max} 段有内容的发言。"
                         "同一人的连续话意放在同一段引号内，不以独立短应答增加引号对数。")
    lines.append(f"标点总密度目标 {float(punctuation['min']):g}–{float(punctuation['max']):g} 处/千汉字，"
                 "包括引号。对白多时相应减少短句和多余停顿，不靠感叹号、破折号凑数。")
    lines.extend(["", "## 词汇和语法的可测轮廓", "",
                  "用具体人物、物件与动作维持叙事，保留必要的时间、方位、因果和完成关系。"
                  "不要为了缩短句子删去自然的助词与连接词。"])
    for key, label, advice in (
        ("word_length_mean_han", "平均词长", "优先常用的具体词，少堆抽象长词"),
        ("word_mattr_50", "MATTR50", "减少近距离原词重复，但不为换词牺牲清楚表达"),
        ("activity_v_over_v_plus_a", "动词比 V/(V+A)", "以动作和选择推进，同时保留必要的状态描写"),
        ("nominality_n_over_n_plus_v", "名词比 N/(N+V)", "让人物和物件与动作相配，不列名词清单"),
        ("function_pos_share_proxy", "功能类词性占比", "用自然连接说明时间与因果，不重复虚词凑数"),
    ):
        band = secondary.get(key)
        if band:
            lines.append(f"- {label} {float(band['min']):g}–{float(band['max']):g} {band['unit']}：{advice}。")
    if lexical:
        lines.append("高频语法词目标（自动分词，每千词元）：" + "；".join(
            f"「{row['word']}」{float(row['min']):g}–{float(row['max']):g}"
            for row in lexical) + "。让它们各自服务修饰、处置、完成、时间或位置关系；不逐词凑数。")
        if bounded_dialogue and any(row["word"] == "在" for row in lexical):
            lines.append("场景转换和人物位置发生变化时，用自然的“在”短语交代方位或时间；"
                         "勿凭空添地点，也勿连续重复同一介词结构。")
    lines.extend(["", "输出前检查人物因果、篇幅、段落、直接引语是否过密，"
                  "并读一遍句子是否流畅。数字是全文目标，不是单句配额；若与清楚表达冲突，以完整叙事为先。",
                  "不要照搬来源作品的人物、事件或连续原句。只输出正文，不附计划、计数或自评。", ""])
    derived["calibration_focus"] = ("bounded dialogue turns with lexical placement" if bounded_dialogue else
                                    "coupled sentence-paragraph-dialogue-punctuation and lexical-grammar balance")
    return lines, derived


def _sustained_lines(targets: dict[str, dict[str, float | str]],
                     secondary: dict[str, dict[str, float | str]],
                     lexical: list[dict[str, float | str]],
                     target_han: int) -> tuple[list[str], dict[str, Any]]:
    """Repeat the same measurable goals across narrative position without visible scaffolding."""
    _, derived = _calibrated_lines(targets, secondary, lexical, target_han)
    sentence = targets["sentence_length_han"]
    paragraph = targets["paragraph_length_han"]
    dialogue = targets["dialogue_share"]
    punctuation = targets["punctuation_per_1000_han"]
    group_count = 3 if derived["paragraph_count_approx"] >= 9 else 2
    group_han = round(target_han / group_count)
    group_paragraphs = round(derived["paragraph_count_approx"] / group_count)
    quotes = secondary.get("quote_spans_per_1000_han")
    quote_count = derived["quote_count_approx"]
    lines = ["# 文学风格执行提示词 · 全篇持续校准实验版", "",
             "依据场景任务写一篇原创、完整、自然的现代中文叙事正文。先确定人物目标、阻碍、决定和可见后果；不遗漏任务事实。",
             f"全文以约 {target_han} 汉字为中心，落在 {derived['min_han']}–{derived['max_han']} 汉字内。"
             "让情节在这个篇幅内完结，不靠重复解释或附加尾声凑字。", "",
             "## 从开端持续到结局的句段节奏", "",
             f"把正文在心中分成 {group_count} 个连续的叙事段群，每群约 {group_han} 汉字、"
             f"约 {group_paragraphs} 个自然段；不要写段群标题或分隔符。"
             "每组都要有推进事件的动作，结局组也按自然段展开，不压成一个长段。",
             f"全篇平均句长 {float(sentence['min']):g}–{float(sentence['max']):g} 汉字/句，"
             f"平均段长 {float(paragraph['min']):g}–{float(paragraph['max']):g} 汉字/段。"
             "一个自然段通常承载相连的两三句；在行动、回应或认识变化处换段。"]
    short = secondary.get("short_sentence_share_le20_han")
    long = secondary.get("long_sentence_share_gt30_han")
    if short and long:
        lines.append(f"≤20 汉字的句子约占 {float(short['min']):.0%}–{float(short['max']):.0%}，"
                     f">30 汉字的句子约占 {float(long['min']):.0%}–{float(long['max']):.0%}。"
                     "短句承担动作或判断；保留少量完整的因果长句，不把后半篇都写成碎句。")
    clause = secondary.get("clause_segments_per_sentence_proxy")
    if clause:
        lines.append(f"逗号、分号、冒号形成的片段约 {float(clause['min']):g}–"
                     f"{float(clause['max']):g} 个/句；用逗号连接相关动作，用句号结束判断。")
    lines.extend(["", "## 对白与标点的联动", "",
                  f"直接引号中的对白正文占全文汉字 {float(dialogue['min']):.0%}–"
                  f"{float(dialogue['max']):.0%}。把发言放在发现、交涉和决定处；"
                  "同一人的连续话意尽量放在一组引号中，避免短问短答堆出密集引号。"])
    if quotes:
        lines.append(f"成对引号片段目标 {float(quotes['min']):g}–"
                     f"{float(quotes['max']):g} 段/千汉字；在约 {target_han} 汉字中，"
                     f"可先安排约 {quote_count} 段有内容的直接发言，并分散到全篇。"
                     "对白可与动作写在同一自然段，不能靠一字应答增加轮次。")
    lines.append(f"标点总密度 {float(punctuation['min']):g}–"
                 f"{float(punctuation['max']):g} 处/千汉字，包含引号。"
                 "对白增加时相应减少不必要的停顿和碎句；不靠感叹号、破折号凑密度。")
    lines.extend(["", "## 词汇、词性与语法关系", "",
                  "以具体人物、物件、地点和动作组织叙事。不要把动作压缩成省略连接的电报式短句；"
                  "自然保留时间、方位、修饰、完成、处置和因果关系。"
                  "在语义合适时使用『的』『了』『在』『把』等语法成分，不逐词凑数。"])
    for key, label, advice in (
        ("word_length_mean_han", "平均词长", "用常见的具体词，不堆抽象长词"),
        ("word_mattr_50", "MATTR50", "避免相邻句反复使用同一个称谓或动作词，不强行换同义词"),
        ("activity_v_over_v_plus_a", "动词比 V/(V+A)", "让行动与必要的状态描写并存"),
        ("nominality_n_over_n_plus_v", "名词比 N/(N+V)", "让人物和物件参与动作，不列名词清单"),
        ("function_pos_share_proxy", "功能类词性占比", "保留自然的助词、介词与连词以交代关系"),
    ):
        band = secondary.get(key)
        if band:
            lines.append(f"- {label} {float(band['min']):g}–{float(band['max']):g} "
                         f"{band['unit']}：{advice}。")
    if lexical:
        lines.append("高频语法词目标（自动分词，每千词元）：" + "；".join(
            f"「{row['word']}」{float(row['min']):g}–{float(row['max']):g}"
            for row in lexical) + "。在语义自然时实现，勿反复使用同一种句式。")
    lines.extend(["", "输出前自查全文，尤其结局段群：是否仍有自然换段、完整句、必要的语法连接和有内容的对白；"
                  "检查篇幅与任务因果。指标是全文范围，不是每句配额；冲突时保留清楚、可信的叙事。",
                  "不要照搬来源作品的人物、事件或连续原句。只输出正文，不附计划、标题、计数或自评。", ""])
    derived["calibration_focus"] = "sustained paragraph groups and natural grammatical relations"
    derived["group_count"] = group_count
    derived["group_han_approx"] = group_han
    derived["paragraphs_per_group_approx"] = group_paragraphs
    return lines, derived


def _style_first_lines(targets: dict[str, dict[str, float | str]],
                       secondary: dict[str, dict[str, float | str]],
                       lexical: list[dict[str, float | str]]) -> tuple[list[str], dict[str, Any]]:
    """Keep every active target measurable while removing total-length pressure."""
    def band(row: dict[str, float | str]) -> str:
        return f"{float(row['min']):g}–{float(row['max']):g}"

    lines = ["# 文学风格执行提示词 · 文风优先实验版", "",
             "根据场景写完整、原创、因果清楚的现代中文叙事正文。自然展开冲突、核对事实、作出选择并写出可见后果。",
             "不规定全文汉字数；不要为凑篇幅重复事件，也不要为了缩短文本省掉必要的交涉和结果。", "",
             "## 句段与对白主轴", "",
             f"平均句长 {band(targets['sentence_length_han'])} 汉字/句；多数句子写完整动作或判断，长短交替。",
             f"平均段长 {band(targets['paragraph_length_han'])} 汉字/段；在动作、认识或发言转折处自然换段，勿把每句单独成段。",
             f"直接引号中的对白正文占比 {float(targets['dialogue_share']['min']):.0%}–"
             f"{float(targets['dialogue_share']['max']):.0%}；每次发言提供新事实、回应或决定。",
             f"含引号的标点总密度 {band(targets['punctuation_per_1000_han'])} 处/千汉字；"
             "用逗号和句号组织停顿，勿以感叹号或密集引号凑数。", "",
             "## 句法代理与词汇轮廓", "",
             "以下是固定分词与标点口径的全篇目标，并非真正的句法树或逐句配额。"
             "用自然句式实现，先保证人物和事件说得通。"]
    instructions = {
        "short_sentence_share_le20_han": "短句要承载完整动作或判断",
        "long_sentence_share_gt30_han": "长句只承担必要的因果层次",
        "clause_segments_per_sentence_proxy": "避免逗号串接多个不相关判断",
        "quote_spans_per_1000_han": "将同一人的连续话意放入一组完整引语，避免短问短答碎片",
        "word_length_mean_han": "优先具体、常用词，少堆抽象长词",
        "word_mattr_50": "减少近距离实词复用，人物与关键物件的称呼保持清楚",
        "activity_v_over_v_plus_a": "用动作推进，也写出必要的状态与性质",
        "nominality_n_over_n_plus_v": "人物、物件与动作相配，不列名词清单",
        "function_pos_share_proxy": "自然交代时间、方位、修饰与因果关系，不重复虚词凑数",
    }
    labels = {
        "short_sentence_share_le20_han": "短句占比（≤20 汉字）",
        "long_sentence_share_gt30_han": "长句占比（>30 汉字）",
        "clause_segments_per_sentence_proxy": "标点片段数/句",
        "quote_spans_per_1000_han": "成对引号片段密度",
        "word_length_mean_han": "平均词长",
        "word_mattr_50": "MATTR50 词汇多样性",
        "activity_v_over_v_plus_a": "动词比 V/(V+A)",
        "nominality_n_over_n_plus_v": "名词比 N/(N+V)",
        "function_pos_share_proxy": "功能类词性占比",
    }
    for key, row in secondary.items():
        lines.append(f"- {labels[key]}：{band(row)} {row['unit']}；{instructions[key]}。")
    if lexical:
        lines.extend(["", "## 高频语法词", "",
                      "频率按自动词性标注后的每千词元计算。词只在句义需要时使用；不要机械插入。"])
        lexical_advice = {"的": "用于必要的定中修饰", "在": "用于真实的地点或时间关系",
                          "把": "用于自然的处置句", "了": "用于动作完成或状态变化"}
        for row in lexical:
            lines.append(f"- 「{row['word']}」{band(row)} 次/千词元；"
                         f"{lexical_advice.get(str(row['word']), '保持符合上下文的自然用法')}。")
    lines.extend(["", "## 完稿检查", "",
                  "检查事件因果、人物动机和结局；检查句段、对白、词汇与语法关系是否自然。"
                  "若数值与清楚表达冲突，保留清楚表达，并由外部评测记录偏差。",
                  "不要照搬来源作品的人物、事件或连续原句。只输出正文，不附指标或自评。", ""])
    return lines, {"length_policy": "descriptive_only",
                   "calibration_focus": "primary_axes_syntax_proxies_and_lexical_style"}


def _linked_style_lines(targets: dict[str, dict[str, float | str]],
                        secondary: dict[str, dict[str, float | str]],
                        lexical: list[dict[str, float | str]]) -> tuple[list[str], dict[str, Any]]:
    """Translate coupled dialogue and grammar targets into local writing guidance."""
    lines, derived = _style_first_lines(targets, secondary, lexical)
    lines[0] = "# 文学风格执行提示词 · 联动句式实验版"
    dialogue = targets["dialogue_share"]
    quotes = secondary.get("quote_spans_per_1000_han")
    guidance = ["## 对白与句式联动", "",
                "让少数有内容的直接发言承载证据、回应和决定；避免一问一答只说几个字。"
                "发言之间用叙述交代动作和核对过程，不以连续引号或感叹号制造密度。"]
    if quotes and float(quotes["min"]) > 0:
        dialogue_mid = (float(dialogue["min"]) + float(dialogue["max"])) / 2
        quotes_mid = (float(quotes["min"]) + float(quotes["max"])) / 2
        center = dialogue_mid * 1000 / quotes_mid
        low = max(5, math.floor(center * .75 / 5) * 5)
        high = max(low + 5, math.ceil(center * 1.25 / 5) * 5)
        guidance.append(f"按对白占比和引号密度的中心值推算，一次直接发言平均约 {center:.0f} 汉字；"
                        f"多数关键发言可自然写成约 {low}–{high} 汉字，通常包含相连的事实与判断。"
                        "这是局部节奏参考，不固定发言次数，也不规定全文篇幅。")
        derived["dialogue_han_per_quote_center"] = round(center, 2)
        derived["dialogue_han_per_quote_guidance"] = [low, high]
    if "function_pos_share_proxy" in secondary:
        guidance.append("叙述证据时用必要的定语说明人物与物件，用时间、方位和因果关系连接核对与决定；"
                        "避免连续动作句只罗列动词，也不要为提高虚词比例生硬添加连接词。")
    index = lines.index("## 句法代理与词汇轮廓")
    lines[index:index] = guidance + [""]
    derived["calibration_focus"] = "linked_dialogue_turns_and_grammatical_relations"
    return lines, derived


def _primary_guarded_lines(targets: dict[str, dict[str, float | str]],
                           secondary: dict[str, dict[str, float | str]],
                           lexical: list[dict[str, float | str]]) -> tuple[list[str], dict[str, Any]]:
    """Prioritize relative paragraph and dialogue structure without a total budget."""
    lines, derived = _style_first_lines(targets, secondary, lexical)
    lines[0] = "# 文学风格执行提示词 · 主轴优先实验版"
    sentence_mid = (float(targets["sentence_length_han"]["min"]) +
                    float(targets["sentence_length_han"]["max"])) / 2
    paragraph_mid = (float(targets["paragraph_length_han"]["min"]) +
                     float(targets["paragraph_length_han"]["max"])) / 2
    sentence_count = max(2, round(paragraph_mid / sentence_mid))
    dialogue_mid = (float(targets["dialogue_share"]["min"]) +
                    float(targets["dialogue_share"]["max"])) / 2
    guidance = ["## 先安排句段和交涉", "",
                f"每个自然段通常写约 {sentence_count} 个完整句，围绕一个动作、发现或决定；"
                "叙述继续推进时及时换段，勿把多步核对挤成长段。"
                "长句只用于必要的因果，过长时拆成清楚的两个句子。",
                f"关键交涉直接写在引号内，让引号内的说话内容约占正文 {dialogue_mid:.0%}。"
                "不要把主要问答改写成‘他说/她解释’的转述。"
                "若对白偏少，补足现有发言中的事实、回应和选择，不靠添加只有几个字的问答凑引号。",
                "用完整句与自然逗号形成停顿；保留必要的定语、时间、方位和因果连接，"
                "不要因此把句子拉成多层套接。", ""]
    index = lines.index("## 句法代理与词汇轮廓")
    lines[index:index] = guidance
    check = lines.index("## 完稿检查")
    lines[check:check] = ["## 自检顺序", "",
                          "先看平均句长、段长、直接对白占比与标点密度是否朝目标靠近；"
                          "再看长短句、分句、词性、MATTR 与高频词。"
                          "调整时保护人物事实、事件因果和语言自然度，不规定全文字数。", ""]
    derived.update({"calibration_focus": "primary_axes_before_syntax_and_lexical_targets",
                    "paragraph_sentences_guidance": sentence_count,
                    "dialogue_share_center": round(dialogue_mid, 4)})
    return lines, derived


def _coupled_distribution_lines(targets: dict[str, dict[str, float | str]],
                                secondary: dict[str, dict[str, float | str]],
                                lexical: list[dict[str, float | str]]) -> tuple[list[str], dict[str, Any]]:
    """Give the model a feasible local rhythm derived from the full target set."""
    lines, derived = _style_first_lines(targets, secondary, lexical)
    lines[0] = "# 文学风格执行提示词 · 联动分布实验版"
    midpoint = lambda row: (float(row["min"]) + float(row["max"])) / 2
    sentence_mid = midpoint(targets["sentence_length_han"])
    paragraph_mid = midpoint(targets["paragraph_length_han"])
    dialogue_mid = midpoint(targets["dialogue_share"])
    quote = secondary.get("quote_spans_per_1000_han")
    short = secondary.get("short_sentence_share_le20_han")
    long = secondary.get("long_sentence_share_gt30_han")
    guidance = ["## 把目标落在句群中", "",
                "先写清人物的动作、核对与决定，再检查句群的分布。保持完整长句；"
                "不要因平均句长目标而把原本连贯的因果关系拆成一串短句。"]
    if short and long:
        guidance.append(
            f"以约二十句为观察尺度，≤20 汉字的句子约 {round(20 * float(short['min']))}–"
            f"{round(20 * float(short['max']))} 句，>30 汉字的完整句约 "
            f"{round(20 * float(long['min']))}–{round(20 * float(long['max']))} 句，"
            "其余自然落在中间长度。长句用于真正相连的条件、原因、核实与后果；"
            "短句用于明确动作或结论。不要逐二十句打勾或把句子拉长凑数。")
        derived["rhythm_reference_sentences"] = 20
        derived["short_sentence_reference_range"] = [round(20 * float(short["min"])),
                                                      round(20 * float(short["max"]))]
        derived["long_sentence_reference_range"] = [round(20 * float(long["min"])),
                                                     round(20 * float(long["max"]))]
    guidance.append(f"每段通常容纳约 {max(2, round(paragraph_mid / sentence_mid))} 个相连的完整句；"
                    "发言、核对或认知转折可以另起段，但避免连续的一句一段。")
    if quote and midpoint(quote) > 0:
        quote_mid = midpoint(quote)
        speech_mid = dialogue_mid * 1000 / quote_mid
        paragraphs_per_quote = 1000 / (quote_mid * paragraph_mid)
        guidance.append(
            f"对白约占正文 {dialogue_mid:.0%}，引号片段约 {quote_mid:g} 组/千汉字，"
            f"两者合起来意味着每组引号内平均约 {speech_mid:.0f} 汉字。"
            f"可把关键发言分布在平均每 {paragraphs_per_quote:.1f} 段一组的节奏中；"
            "一组发言说清事实、回应或选择，不拆成几个短问短答，也不把必要的直接对白全改成转述。"
            "这些是全文比例的局部参照，不规定段落或发言总数。")
        derived["speech_han_per_quote_center"] = round(speech_mid, 2)
        derived["paragraphs_per_quote_center"] = round(paragraphs_per_quote, 2)
    punctuation_mid = midpoint(targets["punctuation_per_1000_han"])
    guidance.append(
        f"标点目标包括成对引号。按平均句长估算，每句对应约 {punctuation_mid * sentence_mid / 1000:.1f} "
        "处全部标点，实际须在长短句与对白间自然变化；引号增多时减少多余逗号、冒号与碎句，"
        "不要把标点平均摊到每句话。")
    if "function_pos_share_proxy" in secondary:
        guidance.append(
            "在关键因果长句和叙述段中自然写出时间、方位、条件、修饰与完成关系；"
            "让助词、介词、连词随语义出现，避免连续只列人物、物件和动作的省略句。"
            "按全文自动词性比率评测，不靠堆叠同一个虚词。")
    guidance.extend(["", "先核对长短句分布、对白份额与引号组数的相容性，"
                     "再看段落、标点、词性、MATTR 和高频词；"
                     "如果局部指引与具体场景冲突，优先保留真实交涉和清楚因果。", ""])
    index = lines.index("## 句段与对白主轴")
    lines[index:index] = guidance
    derived.update({"calibration_focus": "coupled_sentence_dialogue_punctuation_and_function_words",
                    "paragraph_sentences_center": max(2, round(paragraph_mid / sentence_mid)),
                    "punctuation_per_sentence_center": round(punctuation_mid * sentence_mid / 1000, 2)})
    return lines, derived


def compile_prompt(profile: dict[str, Any], controls: dict[str, Any], *,
                   strategy: str = "full", target_han: int = 750,
                   calibration_version: str = CALIBRATED_COMPILER_VERSION,
                   dependency_parse: dict | None = None) -> dict[str, Any]:
    if profile.get("schema") != "stylometric-profile/v1":
        raise ContractError("profile must have schema stylometric-profile/v1")
    unsigned_profile = {key: value for key, value in profile.items() if key != "profile_sha256"}
    if profile.get("profile_sha256") != digest(unsigned_profile):
        raise ContractError("profile hash does not match its contents")
    normalized = validate_controls(profile, controls)
    secondary = validate_secondary_controls(profile, controls)
    lexical = validate_lexical_targets(profile, controls)
    if (strategy not in {"full", "calibrated"} or not 200 <= target_han <= 5000 or
            calibration_version not in {CALIBRATED_COMPILER_VERSION, STRICT_COMPILER_VERSION,
                                        REBALANCED_COMPILER_VERSION, BOUNDED_DIALOGUE_COMPILER_VERSION,
                                        PARAGRAPH_JSON_COMPILER_VERSION, SUSTAINED_COMPILER_VERSION,
                                        BUDGETED_JSON_COMPILER_VERSION,
                                        STYLE_FIRST_COMPILER_VERSION, LINKED_STYLE_COMPILER_VERSION,
                                        PRIMARY_GUARDED_COMPILER_VERSION,
                                        COUPLED_DISTRIBUTION_COMPILER_VERSION}):
        raise ContractError("strategy must be full or calibrated; target_han 200..5000; calibration_version 0.4.0..0.14.0")
    lines = [
        "# 文学风格执行提示词",
        "",
        "你是现代中文叙事写作者。根据用户给出的场景、人物与事实写原创文本。优先满足事件因果、人物逻辑、叙事视角和用户明确要求，再调整下列语言分布。",
        "",
        "## 本次可测目标",
        "",
    ]
    for key in AXES:
        observed = float(profile["axes"][key]["median"])
        lines.append(f"- {_instruction(key, normalized[key], observed)}")
    if secondary:
        lines.extend(["", "## 句式、对白、词汇与语法的次级目标", "",
                      "这些范围是可复算的实验目标。按整体效果取向写作，不逐句计数。"])
        for key in SECONDARY_AXES:
            source_key = secondary_summary_key(key)
            observed = float(profile["extended_window_summary"][source_key]["median"])
            lines.append(f"- {_secondary_instruction(key, secondary[key], observed)}")
        marks = profile.get("punctuation_per_1000_han_by_mark") or {}
        if "，" in marks and "。" in marks:
            lines.append(f"- 标点构成参考：来源逗号 {marks['，']:.1f}、句号 {marks['。']:.1f} 处/千汉字。"
                         "目标提高停顿密度时，保留两者的交替，避免只靠逗号或感叹号凑数。")
        if "quote_spans_per_1000_han" in secondary:
            dialogue_center = (float(normalized["dialogue_share"]["min"]) +
                               float(normalized["dialogue_share"]["max"])) / 2
            quote_center = (float(secondary["quote_spans_per_1000_han"]["min"]) +
                            float(secondary["quote_spans_per_1000_han"]["max"])) / 2
            implied = dialogue_center * 1000 / quote_center if quote_center > 0 else 0
            if implied >= 10 and float(normalized["dialogue_share"]["min"]) > 0.05:
                lines.append(f"- 指标相容性：若对白正文占比与引号片段数都接近目标，每段引号内平均约 {implied:.0f} 汉字。"
                             "以完整发言实现，不通过增加引号对数硬凑对白比例。")
    if lexical:
        source_words = {row["word"]: row for row in
                        profile["extended_diagnostics"]["grammar"]["function_word_top"]}
        lines.extend(["", "## 高频语法词的频率轮廓", "",
                      "下列词来自训练文本的自动词性统计；只在语义自然时使用，不逐项凑数，也不照搬来源的题材词。"])
        for row in lexical:
            observed = float(source_words[str(row["word"])]["per_1000_words"])
            lines.append(f"- 「{row['word']}」：来源 {observed:.1f}、目标 {row['min']:g}–{row['max']:g} 次/千词元。")
    lines.extend([
        "",
        "## 写作方法",
        "",
        "先确定本场的叙述焦点与冲突，再按上述目标选择句群、换段和对白。让语言变化服从场景需要；若精确指标与清楚表达冲突，保留清楚表达，并在评测中记录偏差。",
        "不要调用参考语料的人物、专名、事件或连续原句。输出正文，不附指标说明、创作计划或自评。",
        "",
    ])
    derived_plan = None
    if strategy == "calibrated":
        if calibration_version == COUPLED_DISTRIBUTION_COMPILER_VERSION:
            lines, derived_plan = _coupled_distribution_lines(normalized, secondary, lexical)
        elif calibration_version == PRIMARY_GUARDED_COMPILER_VERSION:
            lines, derived_plan = _primary_guarded_lines(normalized, secondary, lexical)
        elif calibration_version == LINKED_STYLE_COMPILER_VERSION:
            lines, derived_plan = _linked_style_lines(normalized, secondary, lexical)
        elif calibration_version == STYLE_FIRST_COMPILER_VERSION:
            lines, derived_plan = _style_first_lines(normalized, secondary, lexical)
        elif calibration_version == SUSTAINED_COMPILER_VERSION:
            lines, derived_plan = _sustained_lines(normalized, secondary, lexical, target_han)
        elif calibration_version in {REBALANCED_COMPILER_VERSION, BOUNDED_DIALOGUE_COMPILER_VERSION,
                                   PARAGRAPH_JSON_COMPILER_VERSION, BUDGETED_JSON_COMPILER_VERSION}:
            lines, derived_plan = _rebalanced_lines(
                normalized, secondary, lexical, target_han,
                bounded_dialogue=calibration_version == BOUNDED_DIALOGUE_COMPILER_VERSION)
            if calibration_version == PARAGRAPH_JSON_COMPILER_VERSION:
                lines[-2] = "不要照搬来源作品的人物、事件或连续原句。下面的 JSON 只是交付容器，文学正文仍须完整自然。"
                lines.extend(["## 可验证的输出容器", "",
                              "只返回一个合法 JSON 对象，唯一的键是 `paragraphs`，值是按阅读顺序排列的字符串数组。"
                              "不要输出代码围栏、标题、编号、解释或其他键。每个数组元素代表一个完整自然段，"
                              "字符串内部不要换行；系统将按数组顺序用换行连接段落，JSON 标点不计入文风指标。",
                              f"优先写 {math.ceil(target_han / float(normalized['paragraph_length_han']['max']))}–"
                              f"{math.floor(target_han / float(normalized['paragraph_length_han']['min']))} 个段落，"
                              f"各段接近 {float(normalized['paragraph_length_han']['min']):g}–"
                              f"{float(normalized['paragraph_length_han']['max']):g} 汉字；最后一段可随结局自然收束。"
                              "直接引语放在相应自然段的字符串内。生成前检查 JSON 语法和段落数组。", ""])
                derived_plan["calibration_focus"] = "paragraph JSON delivery with metric-preserving assembly"
            elif calibration_version == BUDGETED_JSON_COMPILER_VERSION:
                paragraph = normalized["paragraph_length_han"]
                center = (float(paragraph["min"]) + float(paragraph["max"])) / 2
                count = max(2, round(target_han / center))
                total_min = max(derived_plan["min_han"], round(target_han * .88))
                total_max = min(derived_plan["max_han"], round(target_han * 1.12))
                each_min = max(math.ceil(total_min / count), math.ceil(float(paragraph["min"])))
                each_max = min(math.floor(total_max / count), math.floor(float(paragraph["max"])))
                if each_min > each_max:
                    raise ContractError("target length and paragraph band cannot form a budgeted JSON plan")
                lines[-2] = "不要照搬来源作品的人物、事件或连续原句。下面的 JSON 仅是交付容器，正文仍要有完整因果和自然段落。"
                lines.extend(["## 固定段落预算与输出容器", "",
                              "只返回一个合法 JSON 对象，唯一的键是 `paragraphs`，值是按阅读顺序排列的字符串数组。"
                              "不要输出代码围栏、标题、编号、解释或其他键；每个字符串是一段完整正文，内部不要换行。",
                              f"数组必须恰好有 {count} 个段落。每段构思为约 {each_min}–{each_max} 汉字、通常两到四个完整句；"
                              f"全文合计约 {total_min}–{total_max} 汉字，绝不靠重复解释填补篇幅。"
                              "开头先建立具体阻碍，中段让人物交涉并核对事实，结尾写出选择和可见后果；"
                              "段落不标记阶段。若某段过长，在动作或认识转折处重写并分配到相邻段，"
                              "不要把单句碎成一段；若全文过长，删去重复动作和解释，保留题面事实。",
                              "发言写入相关段落字符串。输出前在心中核对段落数量、篇幅、JSON 语法、"
                              "直接引语占比与标点密度；不要在结果中写出计数或自评。", ""])
                derived_plan.update({"calibration_focus": "fixed paragraph and character budget in JSON",
                                     "paragraph_count_exact": count,
                                     "paragraph_han_budget": [each_min, each_max],
                                     "total_han_budget": [total_min, total_max]})
        else:
            lines, derived_plan = _calibrated_lines(normalized, secondary, lexical, target_han,
                                                    strict=calibration_version == STRICT_COMPILER_VERSION)
    markdown = "\n".join(lines)
    prompt = {
        "schema": "literary-style-prompt/v1",
        "compiler_version": calibration_version if strategy == "calibrated" else COMPILER_VERSION,
        "profile_sha256": profile["profile_sha256"],
        "controls_sha256": digest(controls),
        "targets": normalized,
        "secondary_targets": secondary,
        "lexical_targets": lexical,
        "prompt_markdown": markdown,
        "prompt_sha256": hashlib.sha256(markdown.encode("utf-8")).hexdigest(),
        "warnings": list(profile.get("warnings") or []),
    }
    if strategy == "calibrated":
        prompt.update({"strategy": strategy, "derived_structure": derived_plan})
    if strategy == "calibrated" and calibration_version in {PARAGRAPH_JSON_COMPILER_VERSION,
                                                             BUDGETED_JSON_COMPILER_VERSION}:
        prompt["response_format"] = "paragraph-json/v1"
    prompt["prompt_artifact_sha256"] = digest(prompt)
    return attach_prompt(prompt, controls, dependency_parse)

"""Exploratory, character-preserving paragraph layout of generated prose.

This is a post-generation intervention, never evidence of prompt-only control.
Only a sentence-final mark outside quotation may introduce a new break.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Any

from .io import ContractError
from .metrics import han_count, measure, sentences


OPEN_QUOTES = {"“": "”", "「": "」", "『": "』", '"': '"'}
END_MARKS = set("。！？!?")


@dataclass(frozen=True)
class Unit:
    text: str
    original_end: bool
    quote_paragraph: bool


def canonical_prose(text: str) -> str:
    """Ignore only original paragraph separators and surrounding indentation."""
    return "".join(line.strip() for line in text.splitlines() if line.strip())


def _units(text: str) -> list[Unit]:
    units: list[Unit] = []
    for line in (part.strip() for part in text.splitlines()):
        if not line:
            continue
        quote_paragraph = (line.startswith(tuple(OPEN_QUOTES)) or
                           line.endswith(tuple(OPEN_QUOTES.values())))
        stack: list[str] = []
        start = 0
        for index, char in enumerate(line):
            if stack and char == stack[-1]:
                stack.pop()
            elif char in OPEN_QUOTES:
                stack.append(OPEN_QUOTES[char])
            if char in END_MARKS and not stack and index + 1 < len(line):
                # An end mark followed by a closing quotation belongs to the
                # speaker's sentence; keep its attribution in the same unit.
                if line[index + 1] in set(OPEN_QUOTES.values()):
                    continue
                units.append(Unit(line[start:index + 1], False, quote_paragraph))
                start = index + 1
        tail = line[start:]
        if tail:
            units.append(Unit(tail, True, quote_paragraph))
        elif units:
            last = units[-1]
            units[-1] = Unit(last.text, True, last.quote_paragraph)
    return units


def reflow_paragraphs(text: str, *, min_han: int, max_han: int) -> tuple[str, dict[str, Any]]:
    """Find paragraph breaks nearest the requested band using dynamic programming.

    A boundary cannot split a quote paragraph or an incomplete sentence. The
    objective prefers the original breaks when lengths are similarly close.
    It reports infeasible bands instead of claiming every paragraph is valid.
    """
    if min_han < 1 or max_han < min_han:
        raise ContractError("invalid paragraph length band")
    original = measure(text)
    if original["paragraph_count"] and min_han <= original["axes"]["paragraph_length_han"] <= max_han:
        sizes = [han_count(part) for part in text.splitlines() if part.strip()]
        return text, {
            "schema": "style-layout-reflow/v1",
            "source_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "result_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "character_sequence_preserved": True,
            "min_han": min_han, "max_han": max_han,
            "before_paragraph_count": original["paragraph_count"],
            "after_paragraph_count": original["paragraph_count"],
            "before_mean_han": original["axes"]["paragraph_length_han"],
            "after_mean_han": original["axes"]["paragraph_length_han"],
            "paragraph_lengths_han": sizes,
            "paragraphs_in_band": sum(min_han <= size <= max_han for size in sizes),
            "all_paragraphs_in_band": all(min_han <= size <= max_han for size in sizes),
            "intervention": "none_already_in_mean_band",
        }
    units = _units(text)
    if not units or canonical_prose(text) != "".join(unit.text for unit in units):
        raise ContractError("cannot preserve source prose while segmenting")
    n = len(units)
    lengths = [0]
    for unit in units:
        lengths.append(lengths[-1] + han_count(unit.text))
    crossed_penalty = [0.0]
    crossed_protected = [0]
    for index in range(n - 1):
        original_break = units[index].original_end
        crossed_penalty.append(crossed_penalty[-1] + (0.45 if original_break else 0.0))
        crossed_protected.append(crossed_protected[-1] + int(
            original_break and (units[index].quote_paragraph or units[index + 1].quote_paragraph)))
    center = (min_han + max_han) / 2
    # A long indivisible unit is allowed, but always disclosed as out of band.
    best: list[tuple[float, int, int] | None] = [None] * (n + 1)
    best[0] = (0.0, 0, -1)
    for end in range(1, n + 1):
        candidates: list[tuple[float, int, int]] = []
        for start in range(end):
            previous = best[start]
            if previous is None:
                continue
            if crossed_protected[end - 1] != crossed_protected[start]:
                continue
            size = lengths[end] - lengths[start]
            if size == 0:
                continue
            outside = max(min_han - size, size - max_han, 0)
            # Out-of-range lengths dominate layout preferences. The midpoint
            # term distinguishes equally feasible partitions.
            cost = 100 * outside * outside + ((size - center) / center) ** 2
            cost += crossed_penalty[end - 1] - crossed_penalty[start]
            if end < n and not units[end - 1].original_end:
                cost += 0.12
            candidates.append((previous[0] + cost, previous[1] + 1, start))
        best[end] = min(candidates) if candidates else None
    if best[n] is None:
        raise ContractError("paragraph layout has no valid partition")
    spans: list[tuple[int, int]] = []
    end = n
    while end:
        start = best[end][2]  # type: ignore[index]
        spans.append((start, end))
        end = start
    spans.reverse()
    result = "\n".join("".join(unit.text for unit in units[start:end]) for start, end in spans)
    if canonical_prose(result) != canonical_prose(text):
        raise ContractError("paragraph layout changed source characters")
    before, after = measure(text), measure(result)
    invariant_axes = ("sentence_length_han", "dialogue_share", "punctuation_per_1000_han")
    # Sentence count can change if a source paragraph lacks final punctuation;
    # this is an audit failure, not something to silently accept.
    if (before["han_count"] != after["han_count"] or
            before["sentence_count"] != after["sentence_count"] or
            any(before["axes"][key] != after["axes"][key] for key in invariant_axes)):
        before_sentences, after_sentences = sentences(text), sentences(result)
        first_difference = next((index for index, pair in enumerate(zip(before_sentences, after_sentences))
                                 if pair[0] != pair[1]), min(len(before_sentences), len(after_sentences)))
        raise ContractError(f"paragraph layout changed a non-layout primary axis: "
                            f"sentences {before['sentence_count']}→{after['sentence_count']}; "
                            f"first difference {first_difference}: "
                            f"{before_sentences[first_difference:first_difference + 2]!r} → "
                            f"{after_sentences[first_difference:first_difference + 2]!r}")
    sizes = [han_count(part) for part in result.splitlines()]
    return result, {
        "schema": "style-layout-reflow/v1",
        "source_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "result_sha256": hashlib.sha256(result.encode("utf-8")).hexdigest(),
        "character_sequence_preserved": True,
        "min_han": min_han,
        "max_han": max_han,
        "before_paragraph_count": before["paragraph_count"],
        "after_paragraph_count": after["paragraph_count"],
        "before_mean_han": before["axes"]["paragraph_length_han"],
        "after_mean_han": after["axes"]["paragraph_length_han"],
        "paragraph_lengths_han": sizes,
        "paragraphs_in_band": sum(min_han <= size <= max_han for size in sizes),
        "all_paragraphs_in_band": all(min_han <= size <= max_han for size in sizes),
        "intervention": "post_generation_paragraph_reflow",
    }

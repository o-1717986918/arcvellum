"""Exact shared-denominator constraints and measured joint construction guidance."""
from __future__ import annotations

from fractions import Fraction

from .dependency_examples import deepest_chain, validate_library
from .dependency_feedback import actual, fraction, gap, sha, validate_plan
from .dependency_metrics import analyze_dependencies
from .extended_metrics import extended_statistics
from .io import ContractError, digest
from .metrics import measure
from .reporting import normalization_evidence

SCHEMA = "style-joint-guidance/v1"
VERSION = "0.1.0"


def integer_interval(target, denominator, scale):
    if type(denominator) is not int or denominator <= 0 or type(scale) is not int or scale <= 0:
        raise ContractError("joint budget requires positive integer denominator and scale")
    gap(Fraction(0), target)
    lower = Fraction(str(target["min"])) * denominator / scale
    upper = Fraction(str(target["max"])) * denominator / scale
    low = -(-lower.numerator // lower.denominator)
    high = upper.numerator // upper.denominator
    return {"min": low, "max": high, "attainable": low <= high}


def denominator_family(row):
    if row["group"] == "dependency":
        if row["key"] == "mean_nonleaf_branching":
            return "LTP:nonleaf_nonpunct_nodes"
        if row["key"] == "leaf_share":
            return "LTP:nonpunct_nodes"
        return "LTP:eligible_dependency_arcs"
    if row["key"] == "word_mattr_50":
        return "jieba:50_times_complete_sliding_windows"
    return {"词元": "jieba:all_Han_tokens", "动词+形容词": "jieba:V_plus_A",
            "名词+动词": "jieba:N_plus_V", "汉字": "surface:Han",
            "句": "surface:sentences", "段": "surface:paragraphs"}[row["basis"]["denominator_unit"]]


def constraints(rows):
    result = []
    for row in rows:
        basis, band = row["basis"], row["target"]
        actual(basis)
        n, d, scale = basis["numerator"], basis["denominator"], basis["scale"]
        lower = n * scale - Fraction(str(band["min"])) * d
        upper = Fraction(str(band["max"])) * d - n * scale
        result.append({"group": row["group"], "key": row["key"], "target": band, "basis": basis,
                       "denominator_family": denominator_family(row),
                       "numerator_interval_at_current_denominator": integer_interval(band, d, scale),
                       "lower_margin_exact": fraction(lower), "upper_margin_exact": fraction(upper),
                       "delta_rule": "lower'=lower+scale*delta_n-min*delta_d; upper'=upper+max*delta_d-scale*delta_n"})
    return result


def shifted_interval(constraint, delta_denominator):
    if type(delta_denominator) is not int:
        raise ContractError("joint budget denominator delta must be an integer")
    return integer_interval(constraint["target"], constraint["basis"]["denominator"] + delta_denominator,
                            constraint["basis"]["scale"])


def sentence_measurements(example, prompt):
    text, parsed = example["text"], example["parsed"]
    if parsed["text"] != text or parsed["text_sha256"] != sha(text):
        raise ContractError("joint example parse belongs to a different text")
    surface, extended = measure(text), extended_statistics(text)
    evidence = normalization_evidence(surface, extended, prompt["targets"], prompt["secondary_targets"], prompt["lexical_targets"])
    rows = []
    for group in ("primary", "secondary", "lexical"):
        for key, basis in evidence[group].items():
            measured = bool(basis.get("denominator"))
            rows.append({"group": group, "key": key, "basis": basis, "status": "measured" if measured else "unmeasured",
                         "observed_exact": fraction(actual(basis)) if measured else None})
    analysis = analyze_dependencies(parsed)
    for key in prompt["dependency_targets"]:
        value = analysis["summary"]["metrics"][key]
        basis = {"numerator": value["numerator"], "denominator": value["denominator"], "scale": 1}
        rows.append({"group": "dependency", "key": key, "basis": basis, "status": "measured",
                     "observed_exact": fraction(actual(basis))})
    return {"text": text, "text_sha256": sha(text), "parse_hash": parsed["parse_hash"],
            "analysis_hash": analysis["analysis_hash"], "sample": extended["sample"],
            "pos_counts": extended["grammar"]["pos_counts"],
            "function_word_counts": extended["grammar"]["function_word_counts"], "metrics": rows}


def entry(matrix, group, key):
    return next(row for row in matrix["metrics"] if row["group"] == group and row["key"] == key)


def eligible(matrix, prompt):
    mhd = actual(entry(matrix, "dependency", "mhd")["basis"])
    word_length = actual(entry(matrix, "secondary", "word_length_mean_han")["basis"])
    return (matrix["sample"]["sentence_count"] == 1 and matrix["sample"]["han_count"] <= 20
            and gap(mhd, prompt["dependency_targets"]["mhd"]) == 0
            and word_length >= Fraction(str(prompt["secondary_targets"]["word_length_mean_han"]["min"]))
            and matrix["function_word_counts"].get("的", 0) == 0
            and matrix["function_word_counts"].get("把", 0) >= 1)


def joint_examples(plan, library):
    prompt = plan["prompt"]
    if "mhd" not in prompt["dependency_targets"] or not prompt.get("secondary_targets"):
        raise ContractError("joint construction guidance v1 needs MHD and the original secondary targets")
    pairs = validate_library(library, prompt["dependency_measurement"])
    rows, selected = [], []
    for pair in pairs:
        measured = {"pair_id": pair["id"], "facts": pair["facts"]}
        for kind in ("separate", "embedded"):
            if pair[kind]["parsed"]["annotator"] != plan["initial_parse"]["annotator"]:
                raise ContractError("joint example annotator/provenance differs from initial parse")
            measured[kind] = sentence_measurements(pair[kind], prompt)
        rows.append(measured)
        if eligible(measured["embedded"], prompt) and not eligible(measured["separate"], prompt) and len(selected) < 3:
            selected.append(pair["id"])
    if not selected:
        raise ContractError("no construction meets the unchanged joint eligibility rule")
    return rows, selected


def render_budget(rows):
    lines = ["## 共享分母的联动预算", "",
             "每一项都按修订全文重新计量，下表是初稿分母下的核算快照，不是字数或逐句配额。",
             "分子、分母会同时变化。新增Δn、Δd后，下界余量加s×Δn−下界×Δd；上界余量加上界×Δd−s×Δn。",
             "余量为负表示该边界尚未达到。词性只用相应词性分母，LTP边数和jieba词元分别计。", "",
             "| 指标 | 共享分母族 | 当前分子/分母×倍率 | 当前分母下整数范围 | 下界/上界余量 |",
             "| --- | --- | --- | --- | --- |"]
    for row in rows:
        b, bounds = row["basis"], row["numerator_interval_at_current_denominator"]
        low, high = row["lower_margin_exact"], row["upper_margin_exact"]
        lines.append(f"| {row['group']}:{row['key']} | {row['denominator_family']} | {b['numerator']}/{b['denominator']}×{b['scale']} | "
                     f"{bounds['min']}–{bounds['max']}（{'可达' if bounds['attainable'] else '无整数解'}） | "
                     f"{low['numerator']}/{low['denominator']}；{high['numerator']}/{high['denominator']} |")
    lines += ["", "增加单音节‘把’会消耗平均词长预算。优先在已有动作需要处改用把字句，搭配语义准确的双音节名词和动词，",
              "同时保留所需名词比例、功能词性及动词/形容词关系，避免全改成动词密集的催促句。",
              "MATTR50按全部完整50词滑窗重算；不能把例句TTR、各段MATTR平均或重复模板当作全文MATTR。",
              "深结构必须分散在内容所需的短句中；少数长句的高树深会被其余大量浅边稀释。",
              "若既有事实没有使令关系，不为了模仿范例添加人物命令；保留事实优先，数值仍如实报告。", ""]
    return "\n".join(lines)


def render_joint_examples(rows, selected, library):
    source = {row["id"]: row for row in library["pairs"]}
    lines = ["## 新增的联合实测结构", "",
             "以下范例同时检查树深、短句、平均词长及‘的/把’词元。原指导和全部目标继续适用。",
             "例句只是结构校准；不搬入物件、事实或原句，不要求每句同构。句对语义等价未经独立审阅。", ""]
    for pair in rows:
        if pair["pair_id"] not in selected:
            continue
        for kind, label in (("separate", "分开写"), ("embedded", "联合筛选通过的句式")):
            row = pair[kind]
            mhd = entry(row, "dependency", "mhd")["basis"]
            length = entry(row, "secondary", "word_length_mean_han")["basis"]
            lines.append(f"- {label}：{row['text']} MHD={mhd['numerator']}/{mhd['denominator']}={float(actual(mhd)):.6f}；"
                         f"汉字{row['sample']['han_count']}；平均词长={length['numerator']}/{length['denominator']}={float(actual(length)):.6f}；"
                         f"‘把’词元{row['function_word_counts'].get('把', 0)}，‘的’词元{row['function_word_counts'].get('的', 0)}。")
        lines.append("  最长实测父链：" + deepest_chain(source[pair["pair_id"]]["embedded"]["parsed"]) + "。")
    lines += ["", "小例句不足50词，MATTR50明确缺测；例句的POS与词频不代表完整小说达标。",
              "按事实选择结构并变换词汇；全文仍核对所有18项，任何一项退步都会拒收。", ""]
    return "\n".join(lines)


def compile_joint(plan, library, corpus):
    validate_plan(plan, corpus)
    rows, selected = joint_examples(plan, library)
    budgets = constraints(plan["metric_inventory"])
    instruction = (plan["feedback_text"] + "\n" + render_budget(budgets) + "\n" + render_joint_examples(rows, selected, library)
                   + "\n完成全篇修订，保留原任务的事实与因果。只输出正文，不输出计数和评注。\n")
    result = {"schema": SCHEMA, "version": VERSION, "base_feedback_plan": plan,
              "base_feedback_plan_sha256": plan["plan_sha256"], "library": library,
              "library_sha256": library["library_sha256"], "constraints": budgets,
              "construction_measurements": rows, "selected_pairs": selected,
              "selection_rule": "sorted id, max3; embedded MHD in unchanged band, one surface sentence <=20 Han, word length >=target min, de tokens=0, ba tokens>=1, paired separate fails",
              "feedback_text": instruction, "feedback_sha256": sha(instruction), "quality_status": "unverified",
              "web_modes": plan["web_modes"], "length_in_gate": False, "experiment_design": "target_only"}
    result["joint_guidance_sha256"] = digest(result)
    return result


def validate_joint(artifact, corpus):
    if artifact.get("schema") != SCHEMA or artifact.get("joint_guidance_sha256") != digest(
            {key: value for key, value in artifact.items() if key != "joint_guidance_sha256"}):
        raise ContractError("joint guidance schema/hash differs")
    if compile_joint(artifact["base_feedback_plan"], artifact["library"], corpus) != artifact:
        raise ContractError("joint guidance differs from recomputed counts, selection or constraints")

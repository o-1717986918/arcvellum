"""Equal-budget, metric-aware candidate selection for exploratory Pi runs."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from .io import ContractError, digest
from .reporting import evaluate
from .dependency_targets import require_legacy_targets


SCHEMA = "style-candidate-selection/v1"
VERSION = "0.1.1"
STYLE_FIRST_VERSION = "0.2.1"
SYNTAX_PROXIES = (
    "short_sentence_share_le20_han", "long_sentence_share_gt30_han",
    "clause_segments_per_sentence_proxy", "activity_v_over_v_plus_a",
    "nominality_n_over_n_plus_v", "function_pos_share_proxy",
)


def _normalized(distance: float | None, band: dict[str, Any]) -> float | None:
    if distance is None:
        return None
    width = float(band["max"]) - float(band["min"])
    normalized = round(float(distance) / max(width, 1e-9), 6)
    return max(normalized, 0.000001) if distance > 0 else 0.0


def candidate_rank(row: dict[str, Any], prompt: dict[str, Any], *,
                   objective: str = "style_first") -> tuple[Any, ...]:
    """Lexicographic engineering rule, never a score of literary quality."""
    require_legacy_targets(prompt, "legacy candidate selection")
    if objective not in {"style_first", "length_first"}:
        raise ContractError("candidate objective must be style_first or length_first")
    if row.get("status") != "completed":
        return (2,)
    primary = [_normalized(row["target_distance"][key], band)
               for key, band in prompt["targets"].items()]
    secondary_by_key = {key: _normalized(row["secondary_target_distance"].get(key), band)
                        for key, band in (prompt.get("secondary_targets") or {}).items()}
    secondary = list(secondary_by_key.values())
    lexical = [_normalized(row["lexical_target_distance"].get(str(band["word"])), band)
               for band in (prompt.get("lexical_targets") or [])]
    copy = row.get("copy_risk") or {}
    copy_bad = int(copy.get("longest_shared_han", 10**9) > 24)
    if objective == "length_first":
        han = int(row["han_count"])
        length_gap = max(600 - han, han - 900, 0)
        return (copy_bad, int(length_gap > 0), sum(value > 0 for value in primary),
                round(max(primary, default=0), 6), round(sum(primary), 6),
                round(length_gap / 300, 6),
                sum(value is None for value in secondary),
                round(sum(value for value in secondary if value is not None), 6),
                sum(value is None for value in lexical),
                round(sum(value for value in lexical if value is not None), 6),
                str(row["blind_id"]))
    syntax = [secondary_by_key[key] for key in SYNTAX_PROXIES if key in secondary_by_key]
    other = [value for key, value in secondary_by_key.items() if key not in SYNTAX_PROXIES]
    def gap_rank(values: list[float | None]) -> tuple[int, int, float, float]:
        measured = [value for value in values if value is not None]
        return (len(values) - len(measured), sum(value > 0 for value in measured),
                round(max(measured, default=0), 6), round(sum(measured), 6))
    return (copy_bad, sum(value > 0 for value in primary),
            round(max(primary, default=0), 6), round(sum(primary), 6),
            *gap_rank(syntax), *gap_rank(other), *gap_rank(lexical), str(row["blind_id"]))


def select(experiment: dict[str, Any], prompt: dict[str, Any], *,
           candidates_per_set: int = 3, objective: str = "style_first") -> tuple[dict[str, Any], dict[str, Any]]:
    if candidates_per_set < 2 or candidates_per_set > 10:
        raise ContractError("candidates_per_set must be 2..10")
    if objective not in {"style_first", "length_first"}:
        raise ContractError("candidate objective must be style_first or length_first")
    repetitions = experiment.get("repetitions")
    if (not isinstance(repetitions, int) or repetitions % candidates_per_set or
            repetitions < candidates_per_set or experiment.get("planned_run_count") != len(experiment.get("runs") or []) or
            experiment.get("completed_run_count") != experiment.get("planned_run_count")):
        raise ContractError("candidate selection needs complete sets of equal-sized repetitions")
    report = evaluate(experiment, prompt, {})
    measurements = {row["blind_id"]: row for row in report["runs"]}
    if len(measurements) != len(experiment["runs"]):
        raise ContractError("candidate blind IDs must be unique")
    cases = {case["case_id"] for case in experiment["cases"]}
    groups: dict[tuple[str, int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in experiment["runs"]:
        if (row.get("case_id") not in cases or row.get("arm") not in {"baseline", "target"} or
                not isinstance(row.get("repetition"), int) or not 1 <= row["repetition"] <= repetitions):
            raise ContractError("candidate row has invalid case, arm or repetition")
        set_number = (row["repetition"] - 1) // candidates_per_set + 1
        groups[(row["case_id"], set_number, row["arm"])].append(row)
    expected = {(case, number, arm) for case in cases
                for number in range(1, repetitions // candidates_per_set + 1)
                for arm in ("baseline", "target")}
    if set(groups) != expected or any(len(rows) != candidates_per_set for rows in groups.values()):
        raise ContractError("candidate groups are missing or uneven")
    selections = []
    chosen_rows = []
    for case_id, number, arm in sorted(groups):
        rows = groups[(case_id, number, arm)]
        ranked = sorted(rows, key=lambda row: candidate_rank(measurements[row["blind_id"]], prompt,
                                                              objective=objective))
        if measurements[ranked[0]["blind_id"]]["status"] != "completed":
            raise ContractError("candidate group has no completed answer")
        chosen = dict(ranked[0])
        chosen["candidate_repetition"] = chosen["repetition"]
        chosen["repetition"] = number
        chosen_rows.append(chosen)
        selections.append({"case_id": case_id, "repetition": number, "arm": arm,
                           "selected_blind_id": chosen["blind_id"],
                           "candidates": [{"blind_id": row["blind_id"],
                                           "original_repetition": row["repetition"],
                                           "han_count": measurements[row["blind_id"]].get("han_count"),
                                           "rank": list(candidate_rank(measurements[row["blind_id"]], prompt,
                                                                       objective=objective))}
                                          for row in ranked]})
    record = {"schema": SCHEMA,
              "algorithm_version": VERSION if objective == "length_first" else STYLE_FIRST_VERSION,
              "objective": objective,
              "source_experiment_sha256": digest(experiment),
              "prompt_artifact_sha256": prompt["prompt_artifact_sha256"],
              "candidates_per_set": candidates_per_set,
              "selection_rule": ("lexicographic: copy risk, length band, primary misses, maximum and sum of normalized primary gaps, length gap, secondary and lexical gaps, blind ID"
                                 if objective == "length_first" else
                                 "lexicographic: copy risk, primary misses and normalized gaps, syntax-proxy misses and gaps, other secondary misses and gaps, lexical misses and gaps, blind ID; length descriptive only"),
              "groups": selections}
    record["selection_sha256"] = digest(record)
    selected = dict(experiment)
    selected.update({"repetitions": repetitions // candidates_per_set,
                     "planned_run_count": len(chosen_rows),
                     "completed_run_count": len(chosen_rows),
                     "runs": sorted(chosen_rows, key=lambda row: row["blind_id"]),
                     "phase": "equal-budget-candidate-selection",
                     "candidate_source_experiment_sha256": digest(experiment),
                     "candidate_selection_sha256": record["selection_sha256"]})
    return record, selected


def render_selection(record: dict[str, Any]) -> str:
    if record.get("schema") != SCHEMA or record.get("selection_sha256") != digest({
            key: value for key, value in record.items() if key != "selection_sha256"}):
        raise ContractError("candidate selection record hash or schema is invalid")
    style_first = record.get("objective") == "style_first"
    lines = ["# 等预算候选筛选", "", f"规则版本 `{record['algorithm_version']}`；每组 "
             f"{record['candidates_per_set']} 篇候选。", "",
             ("每组按连续复写、四主轴、句法代理、其余次级指标与高频词目标依次排序；篇幅只记录，不参与选稿。" if style_first else
              "每组按连续复写、篇幅是否达标、四主轴偏离数与归一距离，再按次级和词频距离排序。") +
             "这是机器筛选顺序，不是文学质量总分；基线与目标组使用同一规则。", "",
             "| 场景 | 重复 | 组别 | 选中盲号 | 候选盲号（从优到劣） |",
             "| --- | ---: | --- | --- | --- |"]
    for row in record["groups"]:
        lines.append(f"| {row['case_id']} | {row['repetition']} | {row['arm']} | "
                     f"{row['selected_blind_id']} | "
                     f"{', '.join(item['blind_id'] for item in row['candidates'])} |")
    lines.extend(["", "候选逐项测量见完整实验报告；选中正文仍需匿名人工盲评。", ""])
    return "\n".join(lines)

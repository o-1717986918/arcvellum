"""Public, pinned LTP Base2 model transport and integrity checks (no credentials)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import urllib.request

from .io import ContractError, digest, read_object, write_object

MODEL_ID = "LTP/base2"
REVISION = "70c57011dab606d130c4027705fa155118ca396f"
MODEL_URL = f"https://huggingface.co/{MODEL_ID}/tree/{REVISION}"
FILES = {
    "added_tokens.json": (2, "9e26dfeeb6e641a33dae4961196235bdb965b21b", "git_blob_sha1"),
    "config.json": (10090, "b70f395971e3cb8403267db923417f013f50514e", "git_blob_sha1"),
    "special_tokens_map.json": (112, "e7b0375001f109a6b8873d756ad4f7bbb15fbaa5", "git_blob_sha1"),
    "tokenizer.json": (268961, "eba64ab600f7bb029b38ac391b35651e3b55f185", "git_blob_sha1"),
    "tokenizer_config.json": (19, "66051e65c65b3ec5e0b437496d1e545c5d8934b4", "git_blob_sha1"),
    "vocab.txt": (109540, "ca4f9781030019ab9b253c6dcb8c7878b6dc87a5", "git_blob_sha1"),
    "pytorch_model.bin": (660016593,
                          "c10f249fc2f6d84d66d90c4b75f9cfa8beb7773a855821fec4773941c66afc4a",
                          "sha256"),
}


def verify_file(path: Path, name: str) -> dict:
    size, expected, algorithm = FILES[name]
    if not path.is_file() or path.stat().st_size != size:
        raise ContractError(f"missing/wrong-size official model file: {name}")
    sha256 = hashlib.sha256()
    blob = hashlib.sha1(f"blob {size}\0".encode())
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            sha256.update(chunk)
            blob.update(chunk)
    measured = sha256.hexdigest() if algorithm == "sha256" else blob.hexdigest()
    if measured != expected:
        raise ContractError(f"official model checksum mismatch: {name}")
    return {"file": name, "bytes": size, "sha256": sha256.hexdigest(),
            "upstream_checksum": expected, "upstream_checksum_algorithm": algorithm}


def _transfer(partial: Path, name: str, resume: bool) -> None:
    offset = partial.stat().st_size if partial.exists() else 0
    size = FILES[name][0]
    if offset and not resume:
        raise ContractError(f"incomplete download: {partial}; use --resume after inspection")
    if offset > size:
        raise ContractError(f"oversized partial model download: {name}")
    while offset < size:
        end = min(offset + 8 * 1024 * 1024, size) - 1
        _transfer_range(partial, name, offset, end, size)
        offset = partial.stat().st_size


def _transfer_range(partial: Path, name: str, offset: int, end: int, size: int) -> None:
    url = f"https://huggingface.co/{MODEL_ID}/resolve/{REVISION}/{name}"
    headers = {"User-Agent": "stylometric-prompt-lab/0.8.9"}
    headers["Range"] = f"bytes={offset}-{end}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=60) as response:
        full = response.status == 200 and offset == 0 and end == size - 1
        ranged = response.status == 206 and response.headers.get("Content-Range") == f"bytes {offset}-{end}/{size}"
        if not (full or ranged):
            raise ContractError("server did not confirm requested model byte range")
        _write_stream(response, partial, name, offset)
    if partial.stat().st_size != end + 1:
        raise ContractError(f"incomplete byte range for {name}; inspected partial may be resumed")


def _write_stream(response, partial: Path, name: str, offset: int) -> None:
    with partial.open("ab" if offset else "xb") as stream:
        received, next_notice = offset, offset + 32 * 1024 * 1024
        while chunk := response.read(1024 * 1024):
            stream.write(chunk)
            received += len(chunk)
            if received >= next_notice:
                print(f"{name}: {received}/{FILES[name][0]} bytes", flush=True)
                next_notice += 32 * 1024 * 1024


def _fetch_file(directory: Path, name: str, resume: bool) -> dict:
    target = directory / name
    if target.exists():
        return verify_file(target, name)
    partial = directory / f"{name}.part"
    _transfer(partial, name, resume)
    result = verify_file(partial, name)
    partial.rename(target)
    return result


def download_model(directory: Path, *, resume: bool = False) -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    metadata_url = f"https://huggingface.co/api/models/{MODEL_ID}/revision/{REVISION}?blobs=true"
    with urllib.request.urlopen(metadata_url, timeout=60) as response:
        metadata = json.load(response)
    if metadata.get("sha") != REVISION:
        raise ContractError("official model metadata revision mismatch")
    write_object(directory / "upstream-metadata.json", metadata)
    rows = [_fetch_file(directory, name, resume) for name in FILES]
    result = {"schema": "style-ltp-model/v1", "model_id": MODEL_ID,
              "revision": REVISION, "source_url": MODEL_URL, "files": rows}
    result["model_manifest_hash"] = digest(result)
    write_object(directory / "model-manifest.json", result)
    return result


def verify_model(directory: Path) -> dict:
    manifest = read_object(directory / "model-manifest.json", "style-ltp-model/v1")
    unsigned = {key: value for key, value in manifest.items() if key != "model_manifest_hash"}
    if manifest.get("model_manifest_hash") != digest(unsigned):
        raise ContractError("model manifest hash mismatch")
    if manifest.get("model_id") != MODEL_ID or manifest.get("revision") != REVISION:
        raise ContractError("unsupported model/revision; this adapter pins official LTP/base2")
    if manifest.get("files") != [verify_file(directory / name, name) for name in FILES]:
        raise ContractError("model manifest file inventory/checksum mismatch")
    return manifest

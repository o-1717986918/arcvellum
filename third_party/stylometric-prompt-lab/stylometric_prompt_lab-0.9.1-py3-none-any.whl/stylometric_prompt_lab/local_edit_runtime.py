"""Equal-budget local editing, with auditable rejection and replayed checkpoints."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Callable

from .corpus import Corpus
from .experiment import copy_risk
from .experiment_design import validate_design
from .io import ContractError, digest
from .local_edit import (ALL_POLICY, PLAN_SCHEMA, RUN_SCHEMA, SYSTEM, VERSION, accept, apply_response,
                         edit_prompt, measure_text, seal, sha, validate, validate_policy)
from .pi import PiResult, PiWorker
from .local_edit_memory import augment, validate_strategy


def _decision(text: str, raw: str, status: str, plan: dict[str, Any], corpus: Corpus) -> dict[str, Any]:
    before = measure_text(text, plan["prompt"], corpus)
    if status != "completed":
        return {"candidate_text": None, "before": before, "after": None,
                "decision": {"accepted": False, "reasons": ["model-call-failed"],
                             "quality_status": "unverified"}}
    try:
        allowed = None
        if plan.get("feedback_strategy") == "paragraph_balance_v1":
            from .paragraph_balance import analyze as plan_paragraphs
            allowed = plan_paragraphs(text, plan["prompt"], plan["max_paragraphs"])["selected_paragraph_ids"]
        candidate = apply_response(text, raw, max_paragraphs=plan["max_paragraphs"], allowed_paragraph_ids=allowed)
        after = measure_text(candidate, plan["prompt"], corpus)
        decision = accept(before, after, all_nonworse=plan.get("acceptance_policy") == ALL_POLICY)
    except ContractError as exc:
        return {"candidate_text": None, "before": before, "after": None,
                "decision": {"accepted": False, "reasons": [f"protocol-invalid:{exc}"],
                             "quality_status": "unverified"}}
    return {"candidate_text": candidate, "before": before, "after": after, "decision": decision}


def _record(job: dict[str, Any], step: int, text: str, user: str, result: PiResult,
            plan: dict[str, Any], corpus: Corpus) -> dict[str, Any]:
    row = {"attempt_id": f"{job['blind_id']}-{step}", "blind_id": job["blind_id"],
           "step": step, "arm": job["arm"], "draft_sha256": sha(text),
           "user_prompt": user, "user_prompt_sha256": sha(user),
           "system_prompt_sha256": sha(SYSTEM), "status": result.status,
           "raw_response": result.answer, "failure": result.failure,
           "model": result.model, "worker_version": result.worker_version,
           "events": list(result.events)}
    row.update(_decision(text, result.answer, result.status, plan, corpus))
    return seal(row, "attempt_sha256")


def _restore(row: dict[str, Any], job: dict[str, Any], step: int, text: str, user: str,
             plan: dict[str, Any], corpus: Corpus) -> None:
    if row.get("attempt_sha256") != digest({k: v for k, v in row.items() if k != "attempt_sha256"}):
        raise ContractError("local checkpoint attempt hash differs")
    expected = {"attempt_id": f"{job['blind_id']}-{step}", "blind_id": job["blind_id"],
                "step": step, "arm": job["arm"], "draft_sha256": sha(text),
                "user_prompt": user, "user_prompt_sha256": sha(user),
                "system_prompt_sha256": sha(SYSTEM)}
    if any(row.get(k) != v for k, v in expected.items()):
        raise ContractError("local checkpoint input differs from frozen plan")
    actual = _decision(text, row["raw_response"], row["status"], plan, corpus)
    if any(row.get(k) != v for k, v in actual.items()):
        raise ContractError("local checkpoint decision does not replay")


def _initial_result(plan: dict[str, Any], worker: PiWorker, version: str,
                    existing: dict[str, Any] | None) -> dict[str, Any]:
    result = {"schema": RUN_SCHEMA, "algorithm_version": VERSION,
              "plan_sha256": plan["plan_sha256"], "model": worker.model,
              "model_version": worker.model_version, "worker_version": version,
              "planned_call_count": plan["planned_call_count"], "attempts": []}
    if "feedback_strategy" in plan:
        result.update(feedback_strategy=plan["feedback_strategy"], feedback_version=plan["feedback_version"])
    if "acceptance_policy" in plan:
        result.update(acceptance_policy=plan["acceptance_policy"], acceptance_policy_version=plan["acceptance_policy_version"])
    if existing is not None:
        validate(existing, RUN_SCHEMA, "run_sha256")
        if any(existing.get(k) != v for k, v in result.items() if k != "attempts"):
            raise ContractError("local checkpoint plan, model or Worker differs")
        result["attempts"] = deepcopy(existing["attempts"])
    return result


def _validate_complete_measurements(plan: dict[str, Any], corpus: Corpus) -> None:
    validate_policy(plan)
    if plan.get("acceptance_policy") != ALL_POLICY:
        return
    for text in {job["draft"] for job in plan["jobs"]}:
        observed = measure_text(text, plan["prompt"], corpus)
        missing = [key for field in ("target_distance", "secondary_target_distance", "lexical_target_distance")
                   for key, value in observed[field].items() if value is None]
        if missing:
            raise ContractError(f"all-control policy requires measurable initial targets: {missing}")


def run(plan: dict[str, Any], worker: PiWorker, corpus: Corpus, *,
        existing: dict[str, Any] | None = None,
        on_progress: Callable[[dict[str, Any]], None] | None = None) -> dict[str, Any]:
    validate(plan, PLAN_SCHEMA, "plan_sha256")
    validate_design(plan)
    if plan["planned_call_count"] != plan["steps"] * len(plan["jobs"]):
        raise ContractError("local plan call count differs from job budget")
    validate_strategy(plan)
    _validate_complete_measurements(plan, corpus)
    if plan.get("algorithm_version") != VERSION or plan.get("system_prompt_sha256") != sha(SYSTEM):
        raise ContractError("local plan algorithm differs")
    if plan["source_digest"] != digest([source.public() for source in corpus.sources]):
        raise ContractError("local plan corpus differs")
    if plan.get("model", worker.model) != worker.model or plan.get("model_version", worker.model_version) != worker.model_version:
        raise ContractError("local plan model differs")
    version = worker.version()
    if plan.get("worker_expected_version", version) != version:
        raise ContractError("local plan Worker version differs")
    result = _initial_result(plan, worker, version, existing)
    sequence = [(step, job) for step in range(1, plan["steps"] + 1) for job in plan["jobs"]]
    if len(result["attempts"]) > len(sequence):
        raise ContractError("local checkpoint exceeds frozen budget")
    texts = {job["blind_id"]: job["draft"] for job in plan["jobs"]}
    for index, (step, job) in enumerate(sequence):
        text = texts[job["blind_id"]]
        user = edit_prompt(job, text, plan["prompt"], corpus, plan["max_paragraphs"],
                           acceptance_policy=plan.get("acceptance_policy"))
        user = augment(user, plan, job, text, result["attempts"][:index])
        if index < len(result["attempts"]):
            row = result["attempts"][index]
            _restore(row, job, step, text, user, plan, corpus)
        else:
            response = worker.run(SYSTEM, user)
            if response.model != worker.model:
                raise ContractError("local Worker returned an unexpected model")
            row = _record(job, step, text, user, response, plan, corpus)
            result["attempts"].append(row)
            seal(result, "run_sha256")
            if on_progress:
                on_progress(deepcopy(result))
        if row["decision"]["accepted"]:
            texts[job["blind_id"]] = row["candidate_text"]
        if row["status"] != "completed":
            result["stopped_reason"] = "model-call-failed; no automatic retry"
            break
    result["attempted_call_count"] = len(result["attempts"])
    result["successful_call_count"] = sum(row["status"] == "completed" for row in result["attempts"])
    result["accepted_patch_count"] = sum(row["decision"]["accepted"] for row in result["attempts"])
    result["outputs"] = [{"blind_id": job["blind_id"], "answer": texts[job["blind_id"]],
                          "initial_draft_sha256": job["draft_sha256"],
                          "answer_sha256": sha(texts[job["blind_id"]]),
                          "source_kind": "accepted-local-edit" if texts[job["blind_id"]] != job["draft"]
                          else "retained-original"} for job in plan["jobs"]]
    return seal(result, "run_sha256")


def experiment(plan: dict[str, Any], result: dict[str, Any], corpus: Corpus) -> dict[str, Any]:
    validate(plan, PLAN_SCHEMA, "plan_sha256")
    validate(result, RUN_SCHEMA, "run_sha256")
    if result["plan_sha256"] != plan["plan_sha256"]:
        raise ContractError("local output belongs to another plan")
    outputs = {row["blind_id"]: row for row in result["outputs"]}
    rows = [{**{k: job[k] for k in ("blind_id", "arm", "case_id", "repetition", "source_blind_id")},
             **outputs[job["blind_id"]], "status": "completed",
             "copy_risk": copy_risk(outputs[job["blind_id"]]["answer"], corpus)} for job in plan["jobs"]]
    derived = {"schema": "style-experiment/v1", "prompt_sha256": plan["prompt_sha256"],
            "profile_sha256": plan["prompt"]["profile_sha256"], "runs": rows,
            "cases": plan["cases"], "seed": plan["seed"],
            "model": result["model"], "model_version": result["model_version"],
            "worker_version": result["worker_version"], "planned_run_count": len(rows),
            "completed_run_count": len(rows), "phase": "guarded-local-edit-selected-output",
            "local_edit_plan_sha256": plan["plan_sha256"], "local_edit_run_sha256": result["run_sha256"],
            "parent_experiment_sha256": plan["source_experiment_sha256"],
            "warnings": ["Outputs include retained originals when patches were rejected; these are not new successful generations.",
                         f"Model calls: {result['successful_call_count']}/{result['planned_call_count']}; quality unverified."]}
    if plan.get("experiment_design"):
        derived["experiment_design"] = plan["experiment_design"]
    return derived

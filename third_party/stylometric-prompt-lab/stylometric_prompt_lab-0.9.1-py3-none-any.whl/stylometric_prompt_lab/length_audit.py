"""Paragraph-boundary, near-equal-length sensitivity analysis for paired outputs."""

from __future__ import annotations

from copy import deepcopy
import hashlib
from typing import Any

from .io import ContractError, digest
from .metrics import han_count, paragraphs
from .reporting import evaluate


def paragraph_prefix(text: str, target_han: int, tolerance_han: int) -> tuple[str, int] | None:
    """Choose the complete-paragraph prefix nearest the target, preferring shorter on a tie."""
    if target_han < 200 or tolerance_han < 0 or tolerance_han >= target_han:
        raise ContractError("target_han must be >=200; tolerance_han must be 0..target_han-1")
    rows = paragraphs(text)
    count = 0
    candidates: list[tuple[int, int, int]] = []
    for index, row in enumerate(rows, 1):
        count += han_count(row)
        if abs(count - target_han) <= tolerance_han:
            candidates.append((abs(count - target_han), count, index))
    if not candidates:
        return None
    _, count, index = min(candidates)
    return "\n".join(rows[:index]), count


def audit_length(experiment: dict[str, Any], prompt: dict[str, Any], *,
                 target_han: int = 500, tolerance_han: int = 70,
                 prespecified: bool = False) -> dict[str, Any]:
    # Validate parameters even when no completed runs are present.
    paragraph_prefix("", target_han, tolerance_han)
    clipped = deepcopy(experiment)
    clipped["acceptance"] = None
    choices = []
    for run in clipped.get("runs", []):
        if run.get("status") != "completed" or not str(run.get("answer") or "").strip():
            choices.append({"blind_id": run.get("blind_id"), "arm": run.get("arm"),
                            "status": "original-run-unavailable"})
            continue
        original_han = han_count(str(run["answer"]))
        selected = paragraph_prefix(str(run["answer"]), target_han, tolerance_han)
        if selected is None:
            choices.append({"blind_id": run["blind_id"], "arm": run["arm"],
                            "status": "no-paragraph-boundary-in-band", "original_han": original_han})
            run["status"] = "failed"
            run["answer"] = ""
            run["failure"] = "no paragraph boundary in matched-length band"
            continue
        excerpt, excerpt_han = selected
        choices.append({"blind_id": run["blind_id"], "arm": run["arm"], "status": "included",
                        "original_han": original_han, "excerpt_han": excerpt_han,
                        "paragraph_count": len(paragraphs(excerpt)),
                        "excerpt_sha256": hashlib.sha256(excerpt.encode("utf-8")).hexdigest()})
        run["answer"] = excerpt
        run["copy_risk"] = None
    recomputed = evaluate(clipped, prompt, {})
    public_runs = [{key: row.get(key) for key in ("blind_id", "case_id", "repetition", "arm", "status",
                                                    "han_count", "observed", "target_distance",
                                                    "diagnostic_observed", "secondary_target_distance",
                                                    "lexical_observed", "lexical_target_distance")}
                   for row in recomputed["runs"]]
    return {
        "schema": "style-length-audit/v1",
        "source_experiment_sha256": digest(experiment),
        "prompt_sha256": prompt["prompt_sha256"],
        "target_han": target_han, "tolerance_han": tolerance_han,
        "excerpt_rule": "first complete paragraphs with Han count closest to target; shorter prefix wins ties",
        "analysis_role": ("prespecified secondary sensitivity analysis; not the primary result" if prespecified else
                          "post-hoc sensitivity analysis; not the preregistered primary result"),
        "selected_runs": choices, "included_pair_count": recomputed["paired_count"],
        "axes": recomputed["axes"], "secondary_axes": recomputed["secondary_axes"],
        "lexical_axes": recomputed["lexical_axes"], "pairs": recomputed["pairs"],
        "runs": public_runs,
        "limitations": ["Paragraph prefixes alter the sampled narrative content and may favor opening scenes.",
                        "Actual excerpt lengths vary within the declared tolerance.",
                        "No human quality or source-copy judgment is inferred from these excerpts."],
    }


def render_length_audit(audit: dict[str, Any]) -> str:
    lines = ["# 近等长段落前缀复算", "",
             f"- 目标：{audit['target_han']}±{audit['tolerance_han']} 汉字，取最近的完整段落边界",
             f"- 有效配对：{audit['included_pair_count']}",
             ("- 性质：生成前冻结的次级敏感性分析，不替代全篇主结果或人工盲评" if
              audit["analysis_role"].startswith("prespecified") else
              "- 性质：事后敏感性分析，不替代预注册全篇主结果或人工盲评"), "",
             "## 四主轴", "",
             "| 指标 | 旧版平均目标距离 | 新版平均目标距离 | 新版改善/恶化/持平 |",
             "| --- | ---: | ---: | ---: |"]
    for key, row in audit["axes"].items():
        by_arm = row["mean_distance_by_arm"]
        lines.append(f"| `{key}` | {by_arm['baseline']} | {by_arm['target']} | "
                     f"{row['paired_improved']}/{row['paired_worsened']}/{row['paired_tied']} |")
    for title, key in (("次级目标", "secondary_axes"), ("高频语法词", "lexical_axes")):
        lines.extend(["", f"## {title}", "",
                      "| 指标 | 旧版平均目标距离 | 新版平均目标距离 | 新版改善/恶化/持平/无法测量 |",
                      "| --- | ---: | ---: | ---: |"])
        for name, row in audit[key].items():
            by_arm = row["mean_distance_by_arm"]
            lines.append(f"| `{name}` | {by_arm['baseline']} | {by_arm['target']} | "
                         f"{row['paired_improved']}/{row['paired_worsened']}/{row['paired_tied']}/"
                         f"{row['paired_unmeasured']} |")
    lines.extend(["", "## 逐篇取样", "", "| 盲号 | 方案 | 原汉字数 | 前缀汉字数 | 段数 | 状态 |",
                  "| --- | --- | ---: | ---: | ---: | --- |"])
    for row in audit["selected_runs"]:
        lines.append(f"| {row.get('blind_id')} | {row.get('arm')} | {row.get('original_han', '—')} | "
                     f"{row.get('excerpt_han', '—')} | {row.get('paragraph_count', '—')} | {row['status']} |")
    lines.extend(["", "完整逐篇读数与前缀哈希见 JSON。截取前缀会改变叙事内容和场景构成；",
                  "各前缀实际长度仍在容差内变化。本文不据此推断文学质量、内容保持或复写风险。", ""])
    return "\n".join(lines)

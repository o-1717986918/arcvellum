"""Run original stylo::perform.delta with train-only features and scaling."""

from __future__ import annotations

import csv
import hashlib
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from typing import Any

from . import __version__
from .corpus import Corpus, HAN, normalize_source
from .io import ContractError, digest
from .stylo_reference import UPSTREAM_COMMIT, cjk_tokens, split_audit


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _read_distances(path: Path) -> tuple[list[str], list[str], list[list[float | None]]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.reader(stream))
    train_ids = rows[0][1:]
    test_ids = [row[0] for row in rows[1:]]
    values = [[None if cell in {"", "NA"} else float(cell) for cell in row[1:]]
              for row in rows[1:]]
    return train_ids, test_ids, values


def _source_id(sample_id: str) -> str:
    return sample_id.split("_", 1)[0]


def _candidate(path: Path, sample_size: int | None) -> tuple[str, str]:
    if path.suffix.lower() not in {".txt", ".md", ".markdown"} or not path.is_file():
        raise ContractError("candidate must be an existing UTF-8 TXT or Markdown file")
    raw = path.read_bytes()
    try:
        body = normalize_source(raw.decode("utf-8-sig"), markdown=path.suffix.lower() != ".txt")
    except UnicodeError as exc:
        raise ContractError(f"candidate must be UTF-8: {exc}") from exc
    if len(HAN.findall(body)) < 100:
        raise ContractError("candidate needs at least 100 Han characters")
    if sample_size is not None and len(cjk_tokens(body)) < sample_size:
        raise ContractError("candidate has fewer CJK token runs than sample_size")
    return body, hashlib.sha256(raw).hexdigest()


def run_detection(corpus: Corpus, *, rscript: Path, stylo_library: Path,
                  dependency_library: Path, candidate: Path | None = None,
                  ngram_size: int = 1, sample_size: int | None = None,
                  sample_overlap: int = 0, mfw: int = 100,
                  list_cutoff: int = 5000, culling: float = 0,
                  timeout: int = 300) -> dict[str, Any]:
    if not 1 <= ngram_size <= 3 or mfw < 2 or list_cutoff < 2 or not 0 <= culling <= 100:
        raise ContractError("invalid feature, MFW, list cutoff or culling setting")
    if sample_size is not None and (sample_size < 10 or not 0 <= sample_overlap < sample_size):
        raise ContractError("sample_size must be >=10 and 0 <= overlap < sample_size")
    if sample_size is None and sample_overlap:
        raise ContractError("sample_overlap requires sample_size")
    if sample_size is not None:
        short = [source.source_id for source in corpus.sources
                 if len(cjk_tokens(source.text)) < sample_size]
        if short:
            raise ContractError("sources shorter than sample_size in CJK token runs: "
                                + ", ".join(short))
    train = [source for source in corpus.sources if source.split == "train"]
    holdout = [source for source in corpus.sources if source.split == "holdout"]
    if any(source.style_id is None for source in corpus.sources):
        raise ContractError("detect requires style_id on every corpus source")
    styles = {source.style_id for source in train}
    if len(styles) < 2 or any(source.style_id not in styles for source in holdout):
        raise ContractError("detect needs at least two training styles and all holdout styles represented in training")
    for path in (rscript, stylo_library, dependency_library):
        if not path.exists():
            raise ContractError(f"R runtime path is missing: {path}")
    if candidate and any(source.source_id == "candidate" for source in corpus.sources):
        raise ContractError("source_id 'candidate' is reserved when --candidate is used")
    candidate_body, candidate_hash = _candidate(candidate, sample_size) if candidate else (None, None)
    with tempfile.TemporaryDirectory(prefix="stylo-detect-") as temporary:
        root = Path(temporary)
        index = root / "sources.csv"
        with index.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["source_id", "style_id", "split", "path"])
            for source in corpus.sources:
                target = root / f"{source.source_id}.txt"
                target.write_text(source.text, encoding="utf-8", newline="\n")
                writer.writerow([source.source_id, source.style_id, source.split, target.as_posix()])
            if candidate_body is not None:
                target = root / "candidate.txt"
                target.write_text(candidate_body, encoding="utf-8", newline="\n")
                writer.writerow(["candidate", "", "candidate", target.as_posix()])
        script = Path(__file__).parent / "r_scripts" / "stylo_detect.R"
        command = [str(rscript.resolve()), str(script), str(stylo_library.resolve()),
                   str(dependency_library.resolve()), str(index), str(root),
                   str(ngram_size), str(sample_size or 0), str(sample_overlap),
                   str(mfw), str(list_cutoff), str(culling)]
        environment = os.environ.copy()
        if sys.platform == "win32":
            environment["LC_ALL"] = "English_United States.utf8"
        try:
            process = subprocess.run(command, capture_output=True, text=True,
                                     encoding="utf-8", errors="replace", env=environment,
                                     timeout=timeout, check=False)
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"stylo R detection timed out after {timeout}s") from exc
        if process.returncode:
            raise RuntimeError(f"stylo R detection failed: {(process.stderr or process.stdout)[-2000:]}")
        features = [row["feature"] for row in _read_csv(root / "features.csv")]
        train_ids, test_ids, distances = _read_distances(root / "distances.csv")
        predictions = {row["sample_id"]: row for row in _read_csv(root / "predictions.csv")}
        runtime = (root / "runtime.txt").read_text(encoding="utf-8").splitlines()
    source_map = {source.source_id: source for source in corpus.sources}
    train_styles = [source_map[_source_id(sample_id)].style_id for sample_id in train_ids]
    sample_rows = []
    grouped: dict[str, list[dict[str, Any]]] = {}
    for sample_id, row in zip(test_ids, distances):
        if sample_id not in predictions:
            raise RuntimeError(f"R prediction missing sample {sample_id}")
        by_style: dict[str, float] = {}
        for style in sorted(styles):
            finite = [value for value, train_style in zip(row, train_styles)
                      if train_style == style and value is not None and math.isfinite(value)]
            if not finite:
                raise RuntimeError(f"no finite Delta distance for {sample_id} and style {style}")
            by_style[style] = min(finite)
        source_id = _source_id(sample_id)
        source = source_map.get(source_id)
        predicted_style = predictions[sample_id]["predicted_style"]
        item = {"sample_id": sample_id, "source_id": source_id,
                "expected_style": source.style_id if source else None,
                "predicted_style": predicted_style,
                "correct": predicted_style == source.style_id if source else None,
                "nearest_training_delta_by_style": by_style}
        sample_rows.append(item)
        grouped.setdefault(source_id, []).append(item)
    source_results = []
    for source_id, rows in grouped.items():
        average_nearest = {style: sum(row["nearest_training_delta_by_style"][style]
                                      for row in rows) / len(rows) for style in sorted(styles)}
        ranked = sorted(average_nearest, key=lambda style: (average_nearest[style], style))
        source = source_map.get(source_id)
        source_results.append({
            "source_id": source_id, "split": source.split if source else "candidate",
            "expected_style": source.style_id if source else None,
            "predicted_style": ranked[0],
            "mean_nearest_delta_by_style": average_nearest,
            "margin_to_runner_up": average_nearest[ranked[1]] - average_nearest[ranked[0]],
            "sample_count": len(rows),
            "correct": ranked[0] == source.style_id if source else None,
        })
    holdout_results = [row for row in source_results if row["split"] == "holdout"]
    audit = split_audit(corpus)
    train_works_per_style = {style: len({source.work_id for source in train
                                        if source.style_id == style}) for style in sorted(styles)}
    holdout_works_per_style = {style: len({source.work_id for source in holdout
                                          if source.style_id == style}) for style in sorted(styles)}
    design_eligible = (audit["cross_topic_holdout_eligible"] and sample_size is not None
                       and sample_overlap == 0 and all(value >= 2 for value in train_works_per_style.values())
                       and all(value >= 1 for value in holdout_works_per_style.values()))
    result = {
        "schema": "stylo-detection/v1", "implementation_version": __version__,
        "method": "stylo::perform.delta / classic Delta / train-only z scores",
        "upstream": {"repository": "computationalstylistics/stylo", "commit": UPSTREAM_COMMIT,
                     "version": "0.7.71"},
        "runtime": runtime,
        "source_digest": digest([source.public() for source in corpus.sources]),
        "candidate_raw_sha256": candidate_hash,
        "parameters": {"corpus_lang": "CJK", "features": "c", "ngram_size": ngram_size,
                       "sampling": "normal.sampling" if sample_size else "no.sampling",
                       "sample_size_tokens": sample_size, "sample_overlap_tokens": sample_overlap,
                       "mfw": mfw, "mfw_list_cutoff": list_cutoff,
                       "culling_percent": culling, "z_scores_both_sets": False},
        "selected_features": features, "training_sample_ids": train_ids,
        "training_sample_styles": train_styles,
        "sample_results": sample_rows,
        "source_results": source_results,
        "holdout_window_accuracy": (sum(row["correct"] for row in sample_rows
                                        if source_map.get(row["source_id"])
                                        and source_map[row["source_id"]].split == "holdout") /
                                   sum(1 for row in sample_rows if source_map.get(row["source_id"])
                                       and source_map[row["source_id"]].split == "holdout")),
        "holdout_source_accuracy": sum(row["correct"] for row in holdout_results) / len(holdout_results),
        "split_audit": audit,
        "train_works_per_style": train_works_per_style,
        "holdout_works_per_style": holdout_works_per_style,
        "design_eligible": design_eligible,
        "status": "cross-work-cross-topic-evaluation" if design_eligible else "exploratory-detection",
        "notes": [
            "Predictions use the original stylo::perform.delta with features and z parameters fitted on training samples only.",
            "Source-level prediction averages each window's nearest Delta by style; stylo's original window predictions are preserved in sample_results.",
            "Delta and the margin are distances, not probabilities; style and topic can remain confounded.",
        ],
    }
    result["result_sha256"] = digest(result)
    return result

"""CLI boundary for optional real parsing and neural-free tree recomputation."""

from __future__ import annotations

import json
from pathlib import Path

from .dependency_metrics import analyze_dependencies, render_dependencies
from .io import ContractError, read_object, write_object, write_text


def add_commands(commands, path_type) -> None:
    parse = commands.add_parser("dependency-parse", help="独立LTP环境：真实分词/POS/依存树及句法统计")
    parse.add_argument("text", type=path_type, help="UTF-8纯文本")
    parse.add_argument("--model-dir", type=path_type, required=True, help="已核验的官方LTP/base2本地目录")
    parse.add_argument("--out", type=path_type, required=True)
    analyze = commands.add_parser("dependency-analyze", help="离线复算已保存依存树；无需LTP/PyTorch")
    analyze.add_argument("--parse", type=path_type, required=True)
    analyze.add_argument("--out", type=path_type, required=True)


def render_tokens(parsed: dict) -> str:
    lines = ["# 自动依存标注，未经人工校正；0是人工ROOT。", "# id\tform\tpos\thead\trelation"]
    for row in parsed["sentences"]:
        lines.extend(["", f"# sentence_id = {row['id']}",
                      f"# text = {json.dumps(row['text'], ensure_ascii=False)}"])
        for token in row["tokens"]:
            form = json.dumps(token["form"], ensure_ascii=False)
            lines.append(f"{token['id']}\t{form}\t{token['pos']}\t{token['head']}\t{token['relation']}")
    return "\n".join(lines) + "\n"


def save_analysis(parsed: dict, out: Path, *, include_parse: bool = False) -> dict:
    names = ["dependency-analysis.json", "dependency-analysis.md", "dependency-tokens.tsv"]
    if include_parse:
        names.append("dependency-parse.json")
    if any((out / name).exists() for name in names):
        raise ContractError("dependency output already exists; choose a new directory")
    result = analyze_dependencies(parsed)
    if include_parse:
        write_object(out / "dependency-parse.json", parsed)
    write_object(out / "dependency-analysis.json", result)
    write_text(out / "dependency-analysis.md", render_dependencies(result))
    write_text(out / "dependency-tokens.tsv", render_tokens(parsed))
    return result


def run_command(args) -> int:
    if args.command == "dependency-parse":
        from .dependency_parser import DependencyParser
        parsed = DependencyParser(args.model_dir).parse(args.text.read_text(encoding="utf-8-sig"))
    else:
        parsed = read_object(args.parse, "style-dependency-parse/v1")
    result = save_analysis(parsed, args.out, include_parse=args.command == "dependency-parse")
    print(f"依存分析：{args.out / 'dependency-analysis.md'}；{result['summary']['eligible_arc_count']}条有效边")
    return 0

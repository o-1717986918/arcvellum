"""Frozen, metric-guided second-turn prompts for visible web conversations."""

from __future__ import annotations

import hashlib
from decimal import Decimal
from pathlib import Path
from statistics import mean
from typing import Any

from .corpus import Corpus
from .experiment import copy_risk
from .io import ContractError, digest
from .metrics import measure
from .reporting import evaluate, exact_distance_from_counts


PLAN_SCHEMA = "style-web-feedback-plan/v1"
BASELINE_REVISION = (
    "请把上一条正文作为初稿，重新编辑成 600–900 汉字的完整现代中文叙事场景。"
    "核对原任务的事实、人物动机、因果与最后的选择；删除重复和多余解释，保留自然的句段和必要对白。"
    "仅输出修订后的完整正文，不解释修改过程。"
)
STYLE_BASELINE_REVISION = (
    "请按原场景任务编辑上一条正文，核对人物、事实、因果与结局，删除重复或不自然的句子。"
    "篇幅由故事需要决定。只输出修订后的完整正文，不解释修改过程。"
)
ACTION = {
    "sentence_length_han": ("合并连续碎句，保留完整动作或判断。", "把过长句拆成清晰的句群。"),
    "paragraph_length_han": ("把相连动作合并成段，不要每句换段。", "在动作或认知转折处分段。"),
    "dialogue_share": ("增加推动关系和选择的完整发言；减少纯说明。", "把非必要对白改为动作或叙述。"),
    "punctuation_per_1000_han": ("自然补充分句和停顿。", "减少碎句、密集引号与多余标点。"),
    "short_sentence_share_le20_han": ("在动作和判断处缩短部分长句。", "合并一两个词组成的碎句。"),
    "long_sentence_share_gt30_han": ("保留少量有因果层次的长句。", "拆解多层套接句。"),
    "clause_segments_per_sentence_proxy": ("适度保留逗号连接的完整句。", "减少连续逗号串接。"),
    "quote_spans_per_1000_han": ("让必要对白承担更多信息。", "合并短发言；每段引号内给出完整判断，别靠增加轮次凑对白比例。"),
    "word_length_mean_han": ("自然使用具体的二字名词与动词。", "简化冗长抽象词。"),
    "word_mattr_50": ("减少近距离词语重复，保留必要称谓。", "允许必要复现，避免为换词牺牲清楚表达。"),
    "activity_v_over_v_plus_a": ("让具体动作推动场景。", "加入必要的具体描写，避免动作串。"),
    "nominality_n_over_n_plus_v": ("让人物、地点和物件更具体。", "减少名词堆叠，改用动作。"),
    "function_pos_share_proxy": ("用自然的连接和助词讲清句间关系。", "删去重复连接与虚词。"),
}
RATIOS = {"dialogue_share", "short_sentence_share_le20_han", "long_sentence_share_gt30_han",
          "word_mattr_50", "activity_v_over_v_plus_a", "nominality_n_over_n_plus_v",
          "function_pos_share_proxy"}


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _render_value(key: str, value: float) -> str:
    return f"{value * 100:.1f}%" if key in RATIOS and key != "word_mattr_50" else f"{value:.2f}"


def _candidate(key: str, value: float | None, band: dict[str, Any], *, kind: str,
               word: str = "", basis: dict[str, Any] | None = None) -> dict[str, Any] | None:
    if value is None:
        return None
    lower, upper = float(band["min"]), float(band["max"])
    if basis is not None:
        distance = exact_distance_from_counts(basis, band)
        if distance is None or distance == 0:
            return None
        actual = (Decimal(int(basis["numerator"])) * int(basis["scale"]) /
                  int(basis["denominator"]))
        direction = "low" if actual < Decimal(str(band["min"])) else "high"
        gap = float(abs(actual - Decimal(str(band["min"] if direction == "low" else band["max"]))))
        value = float(actual)
    else:
        if lower <= value <= upper:
            return None
        direction = "low" if value < lower else "high"
        gap = lower - value if direction == "low" else value - upper
    action = (("只在语义自然时适度使用该词。" if direction == "low" else
               "减少不必要的该词重复。") if kind == "lexical" else
              ACTION[key][0 if direction == "low" else 1])
    label = f"高频语法词「{word}」" if kind == "lexical" else key
    return {"key": key, "kind": kind, "label": label, "observed": round(value, 4),
            "target_min": lower, "target_max": upper, "unit": band["unit"],
            "direction": direction, "normalized_gap": round(gap / max(upper - lower, .001), 4),
            "instruction": action}


def _feedback(row: dict[str, Any], prompt: dict[str, Any], *,
              length_free: bool = False) -> tuple[str, list[dict[str, Any]]]:
    basis = row.get("normalization_evidence") or {}
    primary = [_candidate(key, row["observed"][key], band, kind="primary",
                          basis=(basis.get("primary") or {}).get(key))
               for key, band in prompt["targets"].items()]
    secondary = [_candidate(key, row["diagnostic_observed"][key], band, kind="secondary",
                            basis=(basis.get("secondary") or {}).get(key))
                 for key, band in (prompt.get("secondary_targets") or {}).items()]
    lexical = [_candidate(str(band["word"]), row["lexical_observed"][str(band["word"])],
                          band, kind="lexical", word=str(band["word"]),
                          basis=(basis.get("lexical") or {}).get(str(band["word"])))
               for band in prompt.get("lexical_targets") or []]
    required = [item for item in primary if item is not None]
    optional = sorted((item for item in secondary + lexical if item is not None),
                      key=lambda item: (-item["normalized_gap"], item["kind"], item["key"]))
    selected = required + optional[:max(0, 6 - len(required))]
    selected = sorted(selected, key=lambda item: (-item["normalized_gap"], item["kind"], item["key"]))
    lines = [("请把上一条正文作为初稿，在同一故事中修订为完整、自然的现代中文叙事；篇幅由事件需要决定。"
              if length_free else
              "请把上一条正文作为初稿，在同一故事中修订为 600–900 汉字的完整现代中文叙事。"),
             "保留原任务的事实、人物动机、因果和最后的选择；不要复述统计说明。",
             "下列是程序对初稿的实测偏差，只优先修正这些项目；不要为数字牺牲清楚表达："]
    if selected:
        for item in selected:
            key = item["key"]
            lines.append(f"- {item['label']}：实测 {_render_value(key, item['observed'])}，"
                         f"目标 {_render_value(key, item['target_min'])}–"
                     f"{_render_value(key, item['target_max'])} {item['unit']}"
                     f"（{'偏低' if item['direction'] == 'low' else '偏高'}）。{item['instruction']}")
    else:
        lines.append("- 实测指标均在目标区间内；只改善不自然的语句和内容逻辑。")
    lines.append("只输出修订后的完整正文，不列指标、自评或修改说明。")
    return "\n".join(lines), selected


def prepare_feedback_plan(experiment: dict[str, Any], prompt: dict[str, Any],
                          answer_root: Path) -> dict[str, Any]:
    from .dependency_targets import require_legacy_targets
    require_legacy_targets(prompt, "legacy web feedback")
    report = evaluate(experiment, prompt, {})
    if report["completed_run_count"] != experiment.get("planned_run_count"):
        raise ContractError("feedback plan requires every first-turn answer")
    observed = {row["blind_id"]: row for row in report["runs"]}
    length_free = (prompt.get("derived_structure") or {}).get("length_policy") == "descriptive_only"
    jobs = []
    urls = set()
    for run in experiment["runs"]:
        blind_id = str(run["blind_id"])
        meta_path = answer_root / "answers" / f"{blind_id}.meta.json"
        try:
            import json
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ContractError(f"missing capture metadata for {blind_id}") from exc
        source_url = str(meta.get("source_url") or "")
        if (meta.get("blind_id") != blind_id or meta.get("answer_sha256") != _sha(run["answer"])
                or not source_url.startswith("https://chat.deepseek.com/a/chat/") or source_url in urls):
            raise ContractError(f"capture metadata differs from first-turn answer: {blind_id}")
        urls.add(source_url)
        feedback, selected = (((STYLE_BASELINE_REVISION if length_free else BASELINE_REVISION), [])
                              if run["arm"] == "baseline" else
                              _feedback(observed[blind_id], prompt, length_free=length_free))
        jobs.append({"blind_id": blind_id, "case_id": run["case_id"], "arm": run["arm"],
                     "source_url": source_url, "draft_sha256": _sha(run["answer"]),
                     "feedback_text": feedback, "feedback_sha256": _sha(feedback),
                     "selected_deviations": selected, "answer_file": f"revisions/{blind_id}.txt"})
    plan = {"schema": PLAN_SCHEMA, "algorithm_version": "0.3.0" if length_free else "0.1.1",
            "parent_experiment_sha256": digest(experiment), "prompt_sha256": prompt["prompt_sha256"],
            "planned_run_count": len(jobs), "jobs": jobs,
            "procedure": ("one visible second turn in the same DeepSeek chat; no length gate; baseline gets a generic edit, target gets at most six measured deviations"
                          if length_free else
                          "one visible second turn in the same DeepSeek chat for each job; baseline gets a generic edit, target gets at most six measured deviations")}
    if experiment.get("experiment_design") == "target_only":
        plan.update(experiment_design="target_only",
                    web_modes=experiment.get("web_modes") or {"deep_think_pressed": "true", "web_search_pressed": "false"},
                    procedure="one thinking-mode second turn per target job; measured feedback; no length gate")
    plan["plan_sha256"] = digest(plan)
    return plan


def render_feedback_plan(plan: dict[str, Any]) -> str:
    lines = ["# DeepSeek 网页端第二轮修订执行单", "", f"计划哈希：`{plan['plan_sha256']}`",
             "", "在每个盲号的原会话中提交反馈。保存第二条最终正文；原始正文保持不变。", ""]
    if plan.get("web_modes"):
        lines += ["按计划逐篇核验思考开启、搜索关闭，保存模式元数据；只采集最终正文。", ""]
    for job in plan["jobs"]:
        lines.extend([f"## {job['blind_id']} · {job['case_id']}", "", f"会话：{job['source_url']}",
                      f"输出：`{job['answer_file']}`", "", "```text", job["feedback_text"], "```", ""])
    return "\n".join(lines)


def import_feedback_answers(plan: dict[str, Any], experiment: dict[str, Any],
                            prompt: dict[str, Any], corpus: Corpus, answer_root: Path) -> dict[str, Any]:
    if (plan.get("schema") != PLAN_SCHEMA or
            plan.get("plan_sha256") != digest({key: value for key, value in plan.items() if key != "plan_sha256"}) or
            plan.get("parent_experiment_sha256") != digest(experiment) or
            plan.get("prompt_sha256") != prompt.get("prompt_sha256")):
        raise ContractError("feedback plan or source artifacts do not match")
    by_id = {str(row["blind_id"]): row for row in plan.get("jobs") or []}
    if len(by_id) != len(experiment["runs"]) or plan.get("planned_run_count") != len(by_id):
        raise ContractError("feedback plan needs exactly one job per first-turn run")
    root = answer_root.resolve()
    rows = []
    for prior in experiment["runs"]:
        blind_id = str(prior["blind_id"])
        job = by_id[blind_id]
        if (job.get("arm") != prior["arm"] or job.get("case_id") != prior["case_id"] or
                job.get("draft_sha256") != _sha(prior["answer"]) or
                job.get("feedback_sha256") != _sha(job["feedback_text"]) or
                job.get("answer_file") != f"revisions/{blind_id}.txt"):
            raise ContractError(f"feedback job differs from first turn: {blind_id}")
        path = (root / job["answer_file"]).resolve()
        if root not in path.parents:
            raise ContractError("feedback answer path escapes root")
        answer = path.read_text(encoding="utf-8-sig").strip() if path.is_file() else ""
        metadata = path.with_suffix(".meta.json")
        if answer:
            import json
            try:
                meta = json.loads(metadata.read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                raise ContractError(f"missing feedback capture metadata: {blind_id}") from exc
            if (meta.get("blind_id") != blind_id or
                    meta.get("plan_sha256") != plan["plan_sha256"] or
                    meta.get("source_url") != job["source_url"] or
                    meta.get("answer_sha256") != _sha(answer)):
                raise ContractError(f"feedback capture metadata mismatch: {blind_id}")
            if plan.get("web_modes") and any(meta.get(key) != value for key, value in plan["web_modes"].items()):
                raise ContractError(f"feedback modes differ from frozen plan: {blind_id}")
        row = dict(prior)
        if answer and plan.get("web_modes"):
            row["browser_modes"] = {key: meta[key] for key in plan["web_modes"]}
        row.update({"draft_answer_sha256": job["draft_sha256"], "draft_han_count": measure(prior["answer"])["han_count"],
                    "feedback_prompt_sha256": job["feedback_sha256"], "feedback_source_url": job["source_url"],
                    "answer": answer, "status": "completed" if answer else "failed",
                    "failure": "" if answer else "missing visible revised answer",
                    "copy_risk": copy_risk(answer, corpus) if answer else None,
                    "events": list(prior.get("events") or []) +
                    ([{"event": "web.feedback.captured", "data": {"source_url": job["source_url"]}}] if answer else [])})
        rows.append(row)
    result = dict(experiment)
    result.update({"runs": rows, "completed_run_count": sum(row["status"] == "completed" for row in rows),
                   "phase": "feedback-revision", "parent_experiment_sha256": digest(experiment),
                   "feedback_plan_sha256": plan["plan_sha256"], "conversation_turns": 2})
    return result


def compare_feedback_reports(first: dict[str, Any], revised: dict[str, Any],
                             first_experiment: dict[str, Any],
                             revised_experiment: dict[str, Any]) -> dict[str, Any]:
    """Compare each run with its own draft and then compare those changes by arm."""
    if (revised_experiment.get("phase") != "feedback-revision" or
            revised_experiment.get("parent_experiment_sha256") != digest(first_experiment) or
            first.get("experiment_prompt_sha256") != revised.get("experiment_prompt_sha256") or
            first.get("completed_run_count") != first.get("planned_run_count") or
            revised.get("completed_run_count") != revised.get("planned_run_count")):
        raise ContractError("feedback comparison needs matching complete first and revised experiments")
    earlier = {str(row["blind_id"]): row for row in first["runs"]}
    later = {str(row["blind_id"]): row for row in revised["runs"]}
    if len(earlier) != len(first["runs"]) or set(earlier) != set(later):
        raise ContractError("feedback report blind IDs differ")
    groups = {"primary": ("target_distance", "axes"),
              "secondary": ("secondary_target_distance", "secondary_axes"),
              "lexical": ("lexical_target_distance", "lexical_axes")}
    result_metrics: dict[str, Any] = {}
    per_run = []
    for blind_id, before in earlier.items():
        after = later[blind_id]
        if (before["arm"], before["case_id"], before["repetition"]) != (
                after["arm"], after["case_id"], after["repetition"]):
            raise ContractError(f"feedback run identity differs: {blind_id}")
        per_run.append({"blind_id": blind_id, "arm": before["arm"],
                        "case_id": before["case_id"], "repetition": before["repetition"],
                        "draft_han_count": before["han_count"], "revised_han_count": after["han_count"],
                        "distance_change": {group: {key: round(after[field][key] - before[field][key], 4)
                                                    for key in before[field]}
                                            for group, (field, _) in groups.items()}})
    for group, (field, _) in groups.items():
        result_metrics[group] = {}
        for key in first[groups[group][1]]:
            by_arm: dict[str, Any] = {}
            for arm in ("baseline", "target"):
                rows = [(earlier[id][field][key], later[id][field][key]) for id in earlier
                        if earlier[id]["arm"] == arm]
                deltas = [end - start for start, end in rows]
                by_arm[arm] = {
                    "draft_mean_distance": round(mean(start for start, _ in rows), 4),
                    "revised_mean_distance": round(mean(end for _, end in rows), 4),
                    "mean_change": round(mean(deltas), 4),
                    "improved": sum(delta < -1e-8 for delta in deltas),
                    "worsened": sum(delta > 1e-8 for delta in deltas),
                    "tied": sum(abs(delta) <= 1e-8 for delta in deltas),
                }
            pairs = {}
            for row in per_run:
                pair = (row["case_id"], row["repetition"])
                pairs.setdefault(pair, {})[row["arm"]] = row["distance_change"][group][key]
            if any(set(values) != {"baseline", "target"} for values in pairs.values()):
                raise ContractError("feedback comparison requires complete case/repetition pairs")
            advantages = [values["baseline"] - values["target"] for values in pairs.values()]
            result_metrics[group][key] = {
                "by_arm": by_arm,
                "feedback_advantage_mean": round(mean(advantages), 4),
                "feedback_advantage_pairs": sum(value > 1e-8 for value in advantages),
                "feedback_disadvantage_pairs": sum(value < -1e-8 for value in advantages),
                "paired_ties": sum(abs(value) <= 1e-8 for value in advantages),
            }
    return {"schema": "style-web-feedback-comparison/v1",
            "first_experiment_sha256": digest(first_experiment),
            "revised_experiment_sha256": digest(revised_experiment),
            "first_report_sha256": digest(first), "revised_report_sha256": digest(revised),
            "run_count": len(per_run), "pair_count": len(per_run) // 2,
            "metrics": result_metrics, "runs": per_run,
            "human_ratings_status": "pending" if revised.get("acceptance", {}).get("status") == "not-evaluable" else "available",
            "interpretation": "Positive feedback_advantage_mean means the target arm's revision reduced target distance more than the baseline arm's revision; this is exploratory adaptive feedback."}


def render_feedback_comparison(value: dict[str, Any]) -> str:
    lines = ["# DeepSeek 网页端同会话修订比较", "",
             f"首轮与修订轮各 {value['run_count']} 篇；配对 {value['pair_count']} 组。",
             "正的反馈优势表示参数反馈比普通编辑更能缩小目标距离；只代表这批自写任务。", "",
             "| 指标 | 目标组首轮→修订 | 基线组首轮→修订 | 修订优势 | 优势配对 |", "| --- | --- | --- | ---: | ---: |"]
    for group, metrics in value["metrics"].items():
        for key, row in metrics.items():
            target = row["by_arm"]["target"]
            baseline = row["by_arm"]["baseline"]
            lines.append(f"| {group}/{key} | {target['draft_mean_distance']:.4f}→{target['revised_mean_distance']:.4f} "
                         f"({target['improved']}/{target['worsened']}/{target['tied']}) | "
                         f"{baseline['draft_mean_distance']:.4f}→{baseline['revised_mean_distance']:.4f} "
                         f"({baseline['improved']}/{baseline['worsened']}/{baseline['tied']}) | "
                         f"{row['feedback_advantage_mean']:+.4f} | {row['feedback_advantage_pairs']}/{value['pair_count']} |")
    lines.extend(["", "括号内依次是修订改善、恶化、持平篇数；不同指标的单位不同，不能横向相加。",
                  "人工盲评：" + ("待完成。" if value["human_ratings_status"] == "pending" else "已录入。"),
                  "", "逐篇变动及哈希见同目录 JSON。", ""])
    return "\n".join(lines)

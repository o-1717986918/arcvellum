"""Observable, weight-free statistics from CAT-LLM All_style_define.py.

This reproduces code behavior for sentence and word length only. It does not
reproduce the full TSD module, its learned classifiers, or style transfer.
"""

from __future__ import annotations

from collections import Counter
import re
from typing import Any

import jieba

from .corpus import Corpus
from .io import digest
from . import __version__


UPSTREAM_COMMIT = "a3371d810d00b3cbdb1fcfc66cc202706a0f6d1c"
SENTENCE_SPLIT = re.compile(r"([。！？])")
HAN_ONLY = re.compile(r"[^\u4e00-\u9fff]+")
SENTENCE_CHARS = re.compile(r"[\u4e00-\u9fa5a-zA-Z0-9]+")


def observable_statistics(text: str) -> dict[str, Any]:
    # CAT-LLM read_file() removes all whitespace before style definition.
    content = re.sub(r"[\s\u3000]+", "", text)
    parts = SENTENCE_SPLIT.split(content)
    sentences = ["".join(parts[index:index + 2]) for index in range(0, len(parts), 2)
                 if "".join(parts[index:index + 2])]
    sentence_count = sum(bool(sentence.strip()) for sentence in sentences)
    chinese_chars = len(HAN_ONLY.sub("", content))
    lengths = [len("".join(SENTENCE_CHARS.findall(sentence))) for sentence in sentences
               if sentence.strip()]
    bins = {"0_to_10": sum(length <= 10 for length in lengths),
            "11_to_20": sum(10 < length <= 20 for length in lengths),
            "21_to_30": sum(20 < length <= 30 for length in lengths),
            "over_30": sum(length > 30 for length in lengths)}
    short_share = ((bins["0_to_10"] + bins["11_to_20"]) / sentence_count
                   if sentence_count else None)
    if short_share is None:
        tone = None
    elif short_share > 0.6:
        tone = "short"
    elif short_share >= 0.4:
        tone = "balanced"
    else:
        tone = "long"
    # judge_wordlength() calls jieba.cut() with its default HMM setting and
    # filters with Python str.isalnum(), which also admits digits.
    words = list(jieba.cut(content))
    word_length_counts = Counter(len(word) for word in words if word.isalnum())
    top_lengths = sorted(word_length_counts, key=lambda length: -word_length_counts[length])[:2]
    return {
        "sentence_count": sentence_count,
        "chinese_char_count": chinese_chars,
        "average_sentence_length_floor_han": chinese_chars // sentence_count if sentence_count else None,
        "sentence_lengths_han_latin_digit": lengths,
        "sentence_length_bins": bins,
        "short_sentence_share": short_share,
        "sentence_tone_code": tone,
        "word_length_counts": {str(length): count for length, count in sorted(word_length_counts.items())},
        "top_two_word_lengths": top_lengths,
    }


def analyze_cat(corpus: Corpus) -> dict[str, Any]:
    result = {
        "schema": "cat-llm-observable/v1",
        "implementation_version": __version__,
        "method": "CAT-LLM/All_style_define.py sentence and word-length subset",
        "upstream": {"repository": "TaoZhen1110/CAT-LLM", "commit": UPSTREAM_COMMIT},
        "tokenizer": {"name": "jieba", "version": jieba.__version__, "HMM": True},
        "source_digest": digest([source.public() for source in corpus.sources]),
        "sources": [{"source_id": source.source_id, "work_id": source.work_id,
                     "topic": source.topic, "split": source.split,
                     "raw_sha256": source.raw_sha256,
                     "statistics": observable_statistics(source.text)} for source in corpus.sources],
        "warnings": [
            "This is a weight-free code subset, not a reproduction of the full TSD module or CAT-LLM transfer results.",
            "The paper's average-length formula is real-valued; the published code uses floor division.",
            "The repository does not pin jieba; tokenizer output may vary across versions.",
        ],
    }
    result["analysis_sha256"] = digest(result)
    return result

"""Validate and assemble a model-authored paragraph array without editing prose."""

from __future__ import annotations

import json

from .io import ContractError


FORMAT = "paragraph-json/v1"


def assemble_paragraph_json(raw: str) -> tuple[str, dict[str, int | str]]:
    value = raw.strip()
    fenced = False
    if value.startswith("```json\n") and value.endswith("```"):
        value = value[len("```json\n"):-3].strip()
        fenced = True
    elif value.startswith("```\n") and value.endswith("```"):
        value = value[len("```\n"):-3].strip()
        fenced = True
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ContractError(f"paragraph JSON parse failed: {exc.msg}") from exc
    if not isinstance(parsed, dict) or set(parsed) != {"paragraphs"}:
        raise ContractError("paragraph JSON needs exactly one key: paragraphs")
    rows = parsed["paragraphs"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= 40:
        raise ContractError("paragraphs must be a list of 1..40 strings")
    if any(not isinstance(row, str) or not row.strip() or "\n" in row or "\r" in row for row in rows):
        raise ContractError("each paragraph must be a nonempty single-line string")
    joined = "\n".join(row.strip() for row in rows)
    return joined, {"format": FORMAT, "paragraph_count": len(rows),
                    "normalization": "fence-removed" if fenced else "none"}

"""Finite exact ratio constraints, full MATTR, and provisional cached-tree selection."""
from __future__ import annotations

from fractions import Fraction
import json
import math

from .dependency_feedback import actual, fraction, gap, sha
from .dependency_variants import validate_variant_library
from .extended_metrics import extended_statistics
from .io import ContractError, digest
from .local_edit import apply_response
from .metrics import measure
from .reporting import normalization_evidence

SCHEMA = 'style-tree-candidate-selection/v1'
VERSION = '0.1.0'


def screening_specs(inventory, mode):
    if mode not in ('all_targets', 'all_nonworse'):
        raise ContractError('candidate search mode must be all_targets or all_nonworse')
    result = []
    for item in inventory:
        if item['key'] == 'word_mattr_50':
            continue
        band = item['target']
        delta = gap(actual(item['basis']),band) if mode == 'all_nonworse' else Fraction(0)
        low,high = Fraction(str(band['min']))-delta, Fraction(str(band['max']))+delta
        result.append({'key':f"{item['group']}:{item['key']}", 'scale':item['basis']['scale'],
                       'lower':fraction(low), 'upper':fraction(high)})
    return result


def vector(counts, specs):
    result = []
    for spec in specs:
        b = counts[spec['key']]
        if any(type(b.get(k)) is not int or b[k]<0 for k in ('numerator','denominator')) or b['scale'] != spec['scale']:
            raise ContractError('candidate counts need nonnegative integers and matching scales')
        lo,hi = spec['lower'],spec['upper']
        n,d,s = b['numerator'],b['denominator'],spec['scale']
        result += [s*n*lo['denominator']-lo['numerator']*d,
                   hi['numerator']*d-s*n*hi['denominator']]
    return tuple(result)


def search_space(library, batches, specs):
    known = {b['job_id'] for b in library['batches']}
    if not batches or len(set(batches)) != len(batches) or not set(batches) <= known:
        raise ContractError('candidate pool must name distinct recorded parameter batches')
    grouped = {}
    for row in library['candidates']:
        if row['batch_id'] == 'source' or row['batch_id'] in batches:
            grouped.setdefault(row['paragraph_id'],[]).append({**row,'vector':vector(row['counts'],specs)})
    dimensions = len(specs)*2
    fixed,variables = {},[]
    mhd_index = next(i*2 for i,s in enumerate(specs) if s['key']=='dependency:mhd')
    for key,items in sorted(grouped.items()):
        seen,unique = set(),[]
        for item in items:
            if item['text_sha256'] not in seen:
                seen.add(item['text_sha256']);unique.append(item)
        unique.sort(key=lambda r:(-r['vector'][mhd_index],r['candidate_id']))
        if len(unique) == 1:
            fixed[key] = unique[0]
        else:
            variables.append((key,unique))
    variables.sort(key=lambda item:(-(max(r['vector'][mhd_index] for r in item[1])-min(r['vector'][mhd_index] for r in item[1])),item[0]))
    initial = tuple(sum(r['vector'][i] for r in fixed.values()) for i in range(dimensions))
    suffix = [tuple(0 for _ in range(dimensions)) for _ in range(len(variables)+1)]
    for depth in range(len(variables)-1,-1,-1):
        suffix[depth] = tuple(suffix[depth+1][i]+max(r['vector'][i] for r in variables[depth][1]) for i in range(dimensions))
    return fixed,variables,initial,suffix


def assemble(base, chosen, allowed):
    original = {r['paragraph_id']:r for r in base['paragraphs']}
    patches = [{'paragraph_id':key,'original_sha256':original[key]['original_sha256'],'replacement':row['text']}
               for key,row in sorted(chosen.items()) if row['batch_id'] != 'source']
    return apply_response(base['initial_text'],json.dumps({'patches':patches},ensure_ascii=False),
                          max_paragraphs=len(allowed),allowed_paragraph_ids=allowed)


def assess_choice(state, chosen):
    base = state['base']
    text = assemble(base,chosen,state['allowed'])
    p = base['prompt']
    evidence = normalization_evidence(measure(text),extended_statistics(text),p['targets'],p['secondary_targets'],p['lexical_targets'])
    rows = []
    for item in base['metric_inventory']:
        group,key = item['group'],item['key']
        if group == 'dependency':
            counts = [r['counts'][f'{group}:{key}'] for r in chosen.values()]
            b = {'numerator':sum(v['numerator'] for v in counts),'denominator':sum(v['denominator'] for v in counts),'scale':1}
        else:
            b = evidence[group][key]
            if key != 'word_mattr_50':
                for field in ('numerator','denominator'):
                    if b[field] != sum(r['counts'][f'{group}:{key}'][field] for r in chosen.values()):
                        raise ContractError('candidate paragraph counts do not compose under full text measurement')
        if not b['denominator']:
            state['missing_full_measurement'] += 1
            return None
        distance = gap(actual(b),item['target'])
        before = gap(actual(item['basis']),item['target'])
        rows.append({'group':group,'key':key,'basis':b,'target':item['target'], 'distance_exact':fraction(distance),
                     'trend':'improved' if distance<before else 'regressed' if distance>before else 'tied',
                     'measurement':'cached_paragraph_tree_prediction' if group=='dependency' else 'actual_complete_assembled_text'})
    if any(r['trend']=='regressed' for r in rows) or not any(r['trend']=='improved' for r in rows):
        return None
    hits = sum(r['distance_exact']['numerator']==0 for r in rows)
    if state['mode']=='all_targets' and hits != len(rows):
        state['full_mattr_or_precision_rejected'] += 1
        return None
    return {'text':text,'text_sha256':sha(text),'selected_candidate_ids':{str(k):v['candidate_id'] for k,v in sorted(chosen.items())},
            'metric_inventory':rows,'provisional_hits':hits,'requires_fresh_complete_parse':True,
            'assessment_status':'provisional_cached_dependency_prediction_not_statistical_acceptance'}


def visit(depth, margins, chosen, state):
    if state['found'] is not None or state['budget_exhausted']:
        return
    if state['nodes'] >= state['node_budget']:
        state['budget_exhausted'] = True
        return
    state['nodes'] += 1
    if any(value+remaining<0 for value,remaining in zip(margins,state['suffix'][depth])):
        state['pruned_nodes'] += 1
        return
    if depth == len(state['variables']):
        state['linear_feasible_leaves'] += 1
        state['found'] = assess_choice(state,chosen)
        return
    key,options = state['variables'][depth]
    for option in options:
        chosen[key] = option
        visit(depth+1,tuple(a+b for a,b in zip(margins,option['vector'])),chosen,state)
        if state['found'] is not None or state['budget_exhausted']:
            break
    chosen.pop(key,None)


def select_candidates(library, batches, corpus, mode='all_targets', node_budget=500000):
    validate_variant_library(library,corpus)
    if type(node_budget) is not int or not 1<=node_budget<=2000000:
        raise ContractError('candidate search requires an explicit 1..2000000 node budget')
    scope = library['plan']['scope']
    base = {**scope['joint_guidance']['base_feedback_plan'],'paragraphs':scope['paragraphs']}
    specs = screening_specs(base['metric_inventory'],mode)
    fixed,variables,initial,suffix = search_space(library,batches,specs)
    state = {'base':base,'allowed':scope['allowed_paragraph_ids'],'mode':mode,'variables':variables,'suffix':suffix,
             'node_budget':node_budget,'nodes':0,'pruned_nodes':0,'linear_feasible_leaves':0,
             'full_mattr_or_precision_rejected':0,'missing_full_measurement':0,'found':None,'budget_exhausted':False}
    visit(0,initial,dict(fixed),state)
    found = state['found']
    status = 'candidate_found_provisional' if found else 'search_budget_exhausted' if state['budget_exhausted'] else 'no_solution_in_this_cached_finite_pool'
    result = {'schema':SCHEMA,'version':VERSION,'library_sha256':library['library_sha256'],'batches':list(batches),
              'mode':mode,'node_budget':node_budget,'screening_constraints':specs,'status':status,'candidate':found,
              'unique_option_counts':{str(k):len(v) for k,v in variables},'theoretical_unique_combinations':math.prod(len(v) for _,v in variables),
              'search_complete':not found and not state['budget_exhausted'],'nodes':state['nodes'],'pruned_nodes':state['pruned_nodes'],
              'linear_feasible_leaves':state['linear_feasible_leaves'],'full_mattr_or_precision_rejected':state['full_mattr_or_precision_rejected'],
              'missing_full_measurement':state['missing_full_measurement'],'quality_status':'unverified',
              'proof_scope':'finite choices under measured additive paragraph counts and cached trees; full MATTR actual; final new tree mandatory',
              'selection_rule':'first feasible in deterministic depth-margin order; not a maximum-quality or global-optimality claim'}
    result['selection_sha256'] = digest(result)
    return result

"""Loopback-only page and JSON adapter over the prototype's public functions."""

from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
from urllib.parse import unquote, urlsplit
from typing import Any

from .corpus import load_corpus
from .io import ContractError
from .metrics import build_profile
from .prompting import compile_prompt
from .style_card import build_parameter_card, render_parameter_card
from .dependency_targets import reference_view


PACKAGE = Path(__file__).parent
MAX_BODY = 2_000_000


class StudioHandler(BaseHTTPRequestHandler):
    server_version = "StylometricPromptLab/0.4"

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, code: str, message: str) -> None:
        self._json(status, {"error": {"code": code, "message": message}})

    def _body(self) -> dict[str, Any]:
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ContractError("Content-Type must be application/json")
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://127.0.0.1:{self.server.server_port}",
                                    f"http://localhost:{self.server.server_port}"}:
            raise ContractError("cross-origin requests are not accepted")
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ContractError("invalid Content-Length") from exc
        if size < 1 or size > MAX_BODY:
            raise ContractError("JSON request body must be 1..2000000 bytes")
        try:
            value = json.loads(self.rfile.read(size).decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ContractError("request body must be UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise ContractError("request body must be a JSON object")
        return value

    def _profile(self, manifest_path: str) -> dict[str, Any]:
        corpus = load_corpus(Path(manifest_path).expanduser().resolve())
        profile, controls = build_profile(corpus)
        return {"profile": profile, "profile_json": json.dumps(profile, ensure_ascii=False, sort_keys=True),
                "controls": controls, "inspection": corpus.public()}

    def do_GET(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path == "/api/health":
            self._json(200, {"status": "ok", "schema": "style-card-local-api/v1"})
            return
        if path == "/api/demo":
            try:
                payload = self._profile(str(PACKAGE / "demo" / "manifest.json"))
                payload["demo"] = True
                self._json(200, payload)
            except (ContractError, OSError, ValueError) as exc:
                self._error(422, "demo_unavailable", str(exc))
            return
        if path.startswith("/api/"):
            self._error(404, "not_found", "unknown API route")
            return
        root = (PACKAGE / "web_dist").resolve()
        relative = "index.html" if path == "/" else unquote(path).lstrip("/")
        target = (root / relative).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            self._error(404, "not_found", "page asset is missing; run npm run build")
            return
        body = target.read_bytes()
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", mime + ("; charset=utf-8" if mime.startswith("text/") else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path not in {"/api/profile", "/api/card", "/api/dependency-reference"}:
            self._error(404, "not_found", "unknown API route")
            return
        try:
            body = self._body()
            if path == "/api/dependency-reference":
                parsed = self._dependency_parse(body, required=True)
                self._json(200, {"reference": reference_view(parsed)})
                return
            if path == "/api/profile":
                manifest = body.get("manifest_path")
                if not isinstance(manifest, str) or not manifest.strip():
                    raise ContractError("manifest_path must be a local file path")
                self._json(200, self._profile(manifest))
                return
            profile_json = body.get("profile_json")
            profile = json.loads(profile_json) if isinstance(profile_json, str) else body.get("profile")
            controls = body.get("controls")
            if not isinstance(profile, dict) or not isinstance(controls, dict):
                raise ContractError("profile and controls must be JSON objects")
            title, intent = body.get("title"), body.get("intent", "")
            if not isinstance(title, str) or not isinstance(intent, str):
                raise ContractError("title and intent must be text")
            prompt_strategy = body.get("prompt_strategy", "style_first")
            target_han = body.get("target_han", 750)
            if not isinstance(prompt_strategy, str) or type(target_han) is not int:
                raise ContractError("prompt_strategy must be text and target_han must be an integer")
            parsed = self._dependency_parse(body)
            card = build_parameter_card(profile, controls, title=title, intent=intent, dependency_parse=parsed)
            if prompt_strategy == "style_first":
                prompt = compile_prompt(profile, controls, strategy="calibrated",
                                        calibration_version="0.11.0", target_han=target_han, dependency_parse=parsed)
            else:
                prompt = compile_prompt(profile, controls, strategy=prompt_strategy, target_han=target_han,
                                        dependency_parse=parsed)
            self._json(200, {"card": card, "card_markdown": render_parameter_card(card),
                             "card_json": json.dumps(card, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                             "controls": controls,
                             "controls_json": json.dumps(controls, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                             "prompt": prompt})
        except (ContractError, ValueError, FileNotFoundError, OSError, KeyError, TypeError) as exc:
            self._error(422, "invalid_input", str(exc))

    def _dependency_parse(self, body: dict, *, required: bool = False) -> dict | None:
        raw = body.get("dependency_parse_json")
        if raw is None and not required:
            return None
        if not isinstance(raw, str):
            raise ContractError("dependency_parse_json must be the original JSON text")
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise ContractError("dependency parse must be an object")
        return parsed


def serve(host: str = "127.0.0.1", port: int = 8765) -> None:
    if host not in {"127.0.0.1", "localhost"} or not 1 <= port <= 65535:
        raise ContractError("studio accepts only localhost and a port in 1..65535")
    server = ThreadingHTTPServer((host, port), StudioHandler)
    print(f"文风参数卡页面：http://{host}:{port}/", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

"""Offline bridge for visible, independently recorded webpage local edits."""

from __future__ import annotations

from copy import deepcopy
import hashlib
from pathlib import Path
from urllib.parse import urlparse

from .io import ContractError, read_object, write_object, write_text
from .experiment_design import TARGET_ONLY, local_target_gate, validate_design
from .local_edit import PLAN_SCHEMA, SYSTEM, seal, sha, validate
from .pi import PiResult


VERSION = "visible-web-local-edit 0.1.0"
REQUEST_SCHEMA = "style-web-local-request/v1"
RESPONSE_SCHEMA = "style-web-local-response/v1"
MODEL = "deepseek/web-unreported"


class AwaitingWebAnswer(RuntimeError):
    """No answer has been captured; this is not an attempted model failure."""


def combine(system: str, user: str) -> str:
    return system + "\n\n" + user


def prepare_web_plan(parent: dict, source_hashes: dict, *, deep_think: bool = True,
                     instance_id: str | None = None) -> dict:
    validate(parent, PLAN_SCHEMA, "plan_sha256")
    validate_design(parent)
    plan = deepcopy(parent)
    for key in ("worker_entrypoint", "worker_entrypoint_sha256", "timeout_seconds", "thinking"):
        plan.pop(key, None)
    plan.update({"parent_pi_plan_sha256": parent["plan_sha256"],
                 "model": MODEL, "model_version": "unreported",
                 "worker_expected_version": VERSION, "source_file_hashes": source_hashes,
                 "execution_surface": "visible-deepseek-webpage-single-textbox",
                 "web_modes": {"deep_think_pressed": "true" if deep_think else "false",
                               "web_search_pressed": "false"},
                 "prompt_transport": "system + two newlines + user; no separate system channel",
                 "fresh_conversation_per_attempt": True,
                 "screening_gate": {**parent.get("screening_gate", {}), "all_planned_calls_completed": True,
                     "target_accepted_patches_min": 1, "target_primary_improved_vs_initial_min": 2,
                     "target_primary_worsened_vs_initial_max": 0,
                     "target_primary_improved_vs_baseline_min": 1,
                     "target_primary_worsened_vs_baseline_max": 0}})
    if parent.get("experiment_design") == TARGET_ONLY:
        plan["screening_gate"] = local_target_gate()
    if instance_id is not None:
        if not isinstance(instance_id, str) or not instance_id.strip():
            raise ContractError("web instance ID must be nonempty")
        plan.update(instance_id=instance_id, input_verification_required=True,
                    web_input_method="fill-restore-verify-enter")
    return seal(plan, "plan_sha256")


class CapturedWebWorker:
    """Reads files captured through UI automation; never queries a model endpoint."""

    model, model_version = MODEL, "unreported"

    def __init__(self, plan: dict, root: Path, *, completed_count: int = 0):
        validate(plan, PLAN_SCHEMA, "plan_sha256")
        self.plan, self.root = plan, root.resolve()
        self.position = completed_count
        self.loaded_count = 0

    def version(self) -> str:
        return VERSION

    def _request(self, system: str, user: str) -> dict:
        if system != SYSTEM or self.position >= self.plan["planned_call_count"]:
            raise ContractError("web request differs from frozen local protocol")
        job = self.plan["jobs"][self.position % len(self.plan["jobs"])]
        step = self.position // len(self.plan["jobs"]) + 1
        text = combine(system, user)
        return seal({"schema": REQUEST_SCHEMA, "plan_sha256": self.plan["plan_sha256"],
                     "call_index": self.position + 1, "attempt_id": f"{job['blind_id']}-{step}",
                     "arm": job["arm"], "request_text": text, "request_text_sha256": sha(text),
                     "system_prompt_sha256": sha(system), "user_prompt_sha256": sha(user)},
                    "request_sha256")

    def _evidence(self, relative: str, expected: str) -> None:
        path = (self.root / relative).resolve()
        if self.root not in path.parents or not path.is_file():
            raise ContractError("web evidence file missing or outside capture directory")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ContractError("web evidence file hash differs")

    def _input_verification(self, value: dict, request: dict) -> dict:
        if not self.plan.get("input_verification_required"):
            return {}
        relative, expected = value.get("input_verification_file"), value.get("input_verification_sha256")
        if not isinstance(relative, str) or not isinstance(expected, str):
            raise ContractError("submission input verification evidence missing")
        self._evidence(relative, expected)
        proof = read_object(self.root / relative, "style-web-input-verification/v1")
        if (proof.get("matches") is not True or proof.get("length") != len(request["request_text"]) or
                proof.get("request_text_sha256") != request["request_text_sha256"] or
                proof.get("modes") != self.plan["web_modes"] or
                proof.get("input_method") != self.plan["web_input_method"]):
            raise ContractError("submission input verification differs from frozen request")
        return {"input_verification_file": relative, "input_verification_sha256": expected}

    def _response(self, value: dict, request: dict) -> PiResult:
        validate(value, RESPONSE_SCHEMA, "response_sha256")
        for key in ("plan_sha256", "call_index", "attempt_id", "request_text_sha256", "request_sha256"):
            if value.get(key) != request[key]:
                raise ContractError(f"captured web answer differs: {key}")
        url = urlparse(value.get("source_url", ""))
        if url.scheme != "https" or url.netloc != "chat.deepseek.com" or not url.path.startswith("/a/chat/"):
            raise ContractError("captured answer needs a visible DeepSeek conversation URL")
        if value.get("modes_before_submit") != self.plan["web_modes"]:
            raise ContractError("observed web modes differ from the frozen plan")
        if value.get("completion_observed") is not True or not value.get("completion_evidence"):
            raise ContractError("web response completion was not observed")
        answer = value.get("raw_response")
        if not isinstance(answer, str) or not answer.strip() or sha(answer) != value.get("answer_sha256"):
            raise ContractError("captured web response text/hash differs")
        for kind in ("dom", "screenshot", "submitted_dom"):
            self._evidence(value[f"{kind}_file"], value[f"{kind}_sha256"])
        verified_input = self._input_verification(value, request)
        event = {key: value[key] for key in ("response_sha256", "source_url", "call_index",
                 "request_sha256", "modes_before_submit", "completion_evidence",
                 "dom_file", "dom_sha256", "screenshot_file", "screenshot_sha256",
                 "submitted_dom_file", "submitted_dom_sha256")}
        event.update(verified_input)
        return PiResult("completed", answer, "", self.version(), self.model,
                        ({"type": "visible-web-capture", **event},))

    def run(self, system: str, user: str) -> PiResult:
        request = self._request(system, user)
        prefix = f"capture/{request['call_index']:02d}"
        request_path = self.root / f"{prefix}-request.json"
        if request_path.exists() and read_object(request_path, REQUEST_SCHEMA) != request:
            raise ContractError("existing webpage request differs; do not resubmit")
        write_object(request_path, request)
        write_text(self.root / f"{prefix}-request.txt", request["request_text"])
        response_path = self.root / f"{prefix}-response.json"
        if not response_path.exists():
            write_object(self.root / "pending-request.json", request)
            raise AwaitingWebAnswer(f"awaiting visible answer for {request['attempt_id']}")
        result = self._response(read_object(response_path, RESPONSE_SCHEMA), request)
        self.position += 1
        self.loaded_count += 1
        return result

    def verify_completed(self, existing: dict | None) -> None:
        """Recheck original captures as well as the controller's metric replay."""
        position = self.position
        try:
            for index, row in enumerate((existing or {}).get("attempts", [])):
                self.position = index
                request = self._request(SYSTEM, row["user_prompt"])
                response = read_object(self.root / f"capture/{index + 1:02d}-response.json", RESPONSE_SCHEMA)
                result = self._response(response, request)
                if row["raw_response"] != result.answer or row["events"] != list(result.events):
                    raise ContractError("web checkpoint differs from original capture")
        finally:
            self.position = position

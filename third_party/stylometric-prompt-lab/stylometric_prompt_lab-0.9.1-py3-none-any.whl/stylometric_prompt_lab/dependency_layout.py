"""Exact mean-paragraph layout with fresh-tree and all-target invariants."""
from __future__ import annotations

from fractions import Fraction
import hashlib
from pathlib import Path
import re

from .dependency_feedback import actual, adjudicate, fraction, gap, validate_plan
from .dependency_parser import split_sentences, SEGMENTATION
from .extended_metrics import extended_statistics
from .io import ContractError, digest
from .layout import OPEN_QUOTES, _units, canonical_prose
from .metrics import han_count, measure, sentences
from .reporting import normalization_evidence

PLAN_SCHEMA = "style-tree-layout-plan/v1"
RESULT_SCHEMA = "style-tree-layout-result/v1"
VERSION = "0.1.1"
TERMINAL = re.compile(r'''[。！？!?]+[”’」』"']*$''')


def source_sha():
    return {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
            for name in ("dependency_layout.py", "layout.py", "dependency_parser.py", "metrics.py", "extended_metrics.py")}


def boundary_rules(units):
    stack, allowed, required = [], [], []
    closings = set(OPEN_QUOTES.values())
    for index, unit in enumerate(units):
        for char in unit.text:
            if stack and char == stack[-1]:
                stack.pop()
            elif char in OPEN_QUOTES:
                stack.append(OPEN_QUOTES[char])
            elif char in closings:
                raise ContractError("layout source has unmatched closing quotation")
        if index + 1 < len(units):
            allowed.append(unit.original_end or (not stack and bool(TERMINAL.search(unit.text))))
            required.append(unit.original_end and (bool(stack) or not TERMINAL.search(unit.text)
                            or unit.quote_paragraph or units[index + 1].quote_paragraph))
    if stack:
        raise ContractError("layout source has unclosed quotation")
    return allowed, required


def feasible_counts(han, band, allowed, required):
    low, high = Fraction(str(band["min"])), Fraction(str(band["max"]))
    if low <= 0 or low > high:
        raise ContractError("layout needs a positive ordered mean paragraph target")
    wanted_low = -(-(Fraction(han) / high).numerator // (Fraction(han) / high).denominator)
    wanted_high = (Fraction(han) / low).numerator // (Fraction(han) / low).denominator
    legal_low, legal_high = sum(required) + 1, sum(allowed) + 1
    first, last = max(wanted_low, legal_low), min(wanted_high, legal_high)
    feasible = first <= last
    if not feasible:
        candidates = {max(legal_low, min(legal_high, value)) for value in (legal_low, legal_high, wanted_low, wanted_high)}
        best_gap = min(gap(Fraction(han, count), band) for count in candidates)
        nearest = sorted(count for count in candidates if gap(Fraction(han, count), band) == best_gap)
        first, last = nearest[0], nearest[-1]
    return {"wanted": {"min": wanted_low, "max": wanted_high}, "legal": {"min": legal_low, "max": legal_high},
            "search": {"min": first, "max": last}, "mean_band_attainable": feasible}


def partitions(units, allowed, required, band, counts):
    n, lengths, originals, protected = len(units), [0], [0], [0]
    for unit in units:
        lengths.append(lengths[-1] + han_count(unit.text))
    for index in range(n - 1):
        originals.append(originals[-1] + int(units[index].original_end))
        protected.append(protected[-1] + int(required[index]))
    center = (Fraction(str(band["min"])) + Fraction(str(band["max"]))) / 2
    dp = {(0, 0): (0, Fraction(0), -1)}
    for end in range(1, n + 1):
        if end < n and not allowed[end - 1]:
            continue
        for start in range(end):
            if start and not allowed[start - 1] or protected[end - 1] != protected[start]:
                continue
            size = lengths[end] - lengths[start]
            if not size:
                continue
            outside = max(Fraction(str(band["min"])) - size, size - Fraction(str(band["max"])), Fraction(0))
            cost = 100 * outside**2 + (size - center)**2
            edits = originals[end - 1] - originals[start] + int(end < n and not units[end - 1].original_end)
            for count in range(1, min(end, counts["search"]["max"]) + 1):
                previous = dp.get((start, count - 1))
                if previous is None:
                    continue
                candidate = (previous[0] + edits, previous[1] + cost, start)
                if (end, count) not in dp or candidate < dp[end, count]:
                    dp[end, count] = candidate
    candidates = [(dp[n, k][0], dp[n, k][1], k) for k in range(counts["search"]["min"], counts["search"]["max"] + 1) if (n, k) in dp]
    if not candidates:
        raise ContractError("layout has no positive-Han legal partition")
    edits, cost, count = min(candidates)
    spans, end, remaining = [], n, count
    while end:
        start = dp[end, remaining][2]
        spans.append((start, end))
        end, remaining = start, remaining - 1
    return list(reversed(spans)), {"edited_boundaries": edits, "within_count_layout_cost_exact": fraction(cost)}


def mean_layout(text, band):
    gap(Fraction(0), band)
    units = _units(text)
    if not units or len(units) > 512 or canonical_prose(text) != "".join(unit.text for unit in units):
        raise ContractError("layout requires 1..512 complete source blocks; no truncation")
    allowed, required = boundary_rules(units)
    counts = feasible_counts(han_count(text), band, allowed, required)
    spans, decision = partitions(units, allowed, required, band, counts)
    revised = "\n".join("".join(unit.text for unit in units[start:end]) for start, end in spans)
    if canonical_prose(revised) != canonical_prose(text):
        raise ContractError("layout changed canonical source characters")
    if ([row["text"] for row in split_sentences(text)] != [row["text"] for row in split_sentences(revised)]
            or [han_count(row) for row in sentences(text)] != [han_count(row) for row in sentences(revised)]):
        raise ContractError("layout changed source sentences")
    sizes = [han_count(row) for row in revised.splitlines()]
    value = Fraction(han_count(revised), len(sizes))
    return revised, {"count_constraints": counts, "decision": decision, "paragraph_lengths_han": sizes,
                     "mean_exact": fraction(value), "mean_band_hit": gap(value, band) == 0,
                     "all_paragraphs_in_band": all(gap(Fraction(size), band) == 0 for size in sizes),
                     "canonical_sequence_preserved": True, "LTP_sentence_texts_preserved": True,
                     "algorithm": "exact_global_mean_then_min_boundary_edits/v1"}


def legacy_invariants(base, revised):
    prompt = base["prompt"]
    norm = normalization_evidence(measure(revised), extended_statistics(revised), prompt["targets"],
                                  prompt["secondary_targets"], prompt["lexical_targets"])
    for row in base["metric_inventory"]:
        if row["group"] == "dependency" or row["key"] == "paragraph_length_han":
            continue
        new = norm[row["group"]][row["key"]]
        if new != row["basis"]:
            raise ContractError("layout changed nonparagraph counts:" + row["group"] + ":" + row["key"])


def prepare_layout(base, corpus):
    validate_plan(base, corpus)
    if base["initial_parse"]["sentence_segmentation"] != SEGMENTATION:
        raise ContractError("layout requires the pinned terminal-or-newline segmentation")
    if [row["text"] for row in base["initial_parse"]["sentences"]] != [row["text"] for row in split_sentences(base["initial_text"])]:
        raise ContractError("layout source parse segmentation differs")
    revised, info = mean_layout(base["initial_text"], base["prompt"]["targets"]["paragraph_length_han"])
    legacy_invariants(base, revised)
    result = {"schema": PLAN_SCHEMA, "version": VERSION, "base_feedback_plan": base, "layout": info,
              "candidate_text": revised, "candidate_text_sha256": hashlib.sha256(revised.encode()).hexdigest(),
              "source_sha256": source_sha(), "intervention": "explicit_post_generation_layout",
              "quality_status": "unverified", "prompt_only_control_evidence": False, "length_in_gate": False}
    result["layout_plan_sha256"] = digest(result)
    return result


def validate_layout(plan, corpus):
    if plan.get("schema") != PLAN_SCHEMA or plan.get("layout_plan_sha256") != digest(
            {key: value for key, value in plan.items() if key != "layout_plan_sha256"}):
        raise ContractError("layout plan schema/hash differs")
    if prepare_layout(plan["base_feedback_plan"], corpus) != plan:
        raise ContractError("layout plan differs from recomputed sources and boundaries")


def adjudicate_layout(plan, parsed, corpus):
    validate_layout(plan, corpus)
    if parsed is None:
        raise ContractError("layout candidate requires a fresh real parse")
    base = plan["base_feedback_plan"]
    if parsed["text"] != plan["candidate_text"]:
        raise ContractError("layout candidate parse belongs to another text")
    first, second = base["initial_parse"]["sentences"], parsed["sentences"]
    if len(first) != len(second) or any(a["text"] != b["text"] or a["tokens"] != b["tokens"] for a, b in zip(first, second)):
        raise ContractError("layout candidate changed a sentence token, POS, head or relation")
    assessed = adjudicate(base, plan["candidate_text"], parsed, corpus)
    before = {(r["group"], r["key"]): r for r in base["metric_inventory"]}
    for row in assessed["metric_inventory"]:
        if row["key"] != "paragraph_length_han" and row != before[row["group"], row["key"]]:
            raise ContractError("layout candidate changed a nonparagraph target")
    result = {"schema": RESULT_SCHEMA, "version": VERSION, "layout_plan_sha256": plan["layout_plan_sha256"],
              "assessment": assessed, "checks": {"all_sentence_texts_and_token_trees_identical": True,
              "all_nonparagraph_counts_identical": True, "fresh_matching_full_parse": True},
              "prompt_only_control_evidence": False, "quality_status": "unverified"}
    result["layout_result_sha256"] = digest(result)
    return result

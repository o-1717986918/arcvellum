"""Independent public CLI for fresh-tree feedback; leaves historic CLI frozen."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .corpus import load_corpus
from .dependency_feedback import PLAN_SCHEMA, adjudicate, prepare, render_result
from .io import ContractError, read_object, write_object, write_text
from .reporting import render_markdown


def parser():
    result = argparse.ArgumentParser(description="真实依存与全目标反馈，不设篇幅门槛")
    commands = result.add_subparsers(dest="command", required=True)
    plan = commands.add_parser("plan")
    plan.add_argument("--prompt", type=Path, required=True)
    plan.add_argument("--task", type=Path, required=True)
    evaluate = commands.add_parser("evaluate")
    evaluate.add_argument("--plan", type=Path, required=True)
    for command in (plan, evaluate):
        command.add_argument("--text", type=Path, required=True)
        command.add_argument("--parse", type=Path, required=True)
        command.add_argument("--corpus", type=Path, required=True)
        command.add_argument("--out", type=Path, required=True)
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.out.exists():
            raise ContractError("feedback output already exists; choose a new directory")
        corpus = load_corpus(args.corpus)
        text = args.text.read_text(encoding="utf-8-sig")
        parsed = read_object(args.parse, "style-dependency-parse/v1")
        if args.command == "plan":
            prompt = read_object(args.prompt, "literary-style-prompt/v1")
            result = prepare(prompt, text, parsed, corpus, args.task.read_text(encoding="utf-8-sig"))
            write_object(args.out / "feedback-plan.json", result)
            write_text(args.out / "feedback.txt", result["feedback_text"])
            print(f"冻结反馈：{args.out / 'feedback.txt'}")
        else:
            result = adjudicate(read_object(args.plan, PLAN_SCHEMA), text, parsed, corpus)
            write_object(args.out / "feedback-result.json", result)
            write_text(args.out / "feedback-result.md", render_result(result))
            write_object(args.out / "report.json", result["candidate_report"])
            write_text(args.out / "report.md", render_markdown(result["candidate_report"]))
            print(f"统计接受：{result['decision']['accepted']}；结果：{args.out / 'feedback-result.md'}")
        return 0
    except (ContractError, ValueError, OSError, RuntimeError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

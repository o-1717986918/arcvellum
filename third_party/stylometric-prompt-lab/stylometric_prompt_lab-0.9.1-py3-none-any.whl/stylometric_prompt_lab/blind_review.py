"""Separate reviewer-facing texts from the experiment's arm and run identities."""

from __future__ import annotations

import csv
import hashlib
import io
import random
from pathlib import Path
from typing import Any

from .io import ContractError, digest


PACKET_SCHEMA = "style-blind-review-packet/v1"
MAP_SCHEMA = "style-blind-review-map/v1"
FIELDS = ("style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5")


def _verified(value: dict[str, Any], schema: str, hash_key: str) -> None:
    if value.get("schema") != schema or value.get(hash_key) != digest({
            key: item for key, item in value.items() if key != hash_key}):
        raise ContractError(f"{schema} hash or schema is invalid")


def prepare(experiment: dict[str, Any], prompt: dict[str, Any], *,
            seed: int = 20261003) -> tuple[dict[str, Any], dict[str, Any]]:
    if experiment.get("schema") != "style-experiment/v1" or prompt.get("schema") != "literary-style-prompt/v1":
        raise ContractError("blind review needs a versioned experiment and prompt")
    if experiment.get("prompt_sha256") != prompt.get("prompt_sha256") or (
            experiment.get("profile_sha256") != prompt.get("profile_sha256") or
            hashlib.sha256(str(prompt.get("prompt_markdown") or "").encode("utf-8")).hexdigest()
            != prompt.get("prompt_sha256") or
            prompt.get("prompt_artifact_sha256") != digest({
                key: item for key, item in prompt.items() if key != "prompt_artifact_sha256"})):
        raise ContractError("blind review prompt does not match the experiment")
    cases = {str(item["case_id"]): str(item["brief"]) for item in experiment.get("cases") or []}
    if len(cases) != len(experiment.get("cases") or []):
        raise ContractError("review cases must have unique IDs")
    runs = [item for item in experiment.get("runs") or [] if item.get("status") == "completed"
            and str(item.get("answer") or "").strip()]
    if not runs or len({str(item.get("blind_id")) for item in runs}) != len(runs):
        raise ContractError("review needs completed answers with unique blind IDs")
    if any(str(item.get("case_id")) not in cases or item.get("arm") not in {"baseline", "target"}
           for item in runs):
        raise ContractError("review answer has an unknown case or arm")
    shuffled = list(runs)
    random.Random(seed).shuffle(shuffled)
    public_rows = []
    private_rows = []
    for number, run in enumerate(shuffled, 1):
        review_id = f"R{number:03d}"
        answer = str(run["answer"])
        answer_sha = hashlib.sha256(answer.encode("utf-8")).hexdigest()
        public_rows.append({"review_id": review_id, "case_id": str(run["case_id"]),
                            "brief": cases[str(run["case_id"])], "answer": answer,
                            "answer_sha256": answer_sha})
        private_rows.append({"review_id": review_id, "blind_id": str(run["blind_id"]),
                             "arm": str(run["arm"]), "answer_sha256": answer_sha})
    packet = {"schema": PACKET_SCHEMA, "prompt_sha256": prompt["prompt_sha256"],
              "targets": prompt["targets"], "secondary_targets": prompt.get("secondary_targets") or {},
              "lexical_targets": prompt.get("lexical_targets") or [],
              "rows": public_rows,
              "instructions": "按目标风格、任务事实和自然表达分别评分；不要自行计数、查看实验报告或猜测方案。"}
    packet["packet_sha256"] = digest(packet)
    mapping = {"schema": MAP_SCHEMA, "source_experiment_sha256": digest(experiment),
               "prompt_artifact_sha256": prompt["prompt_artifact_sha256"],
               "packet_sha256": packet["packet_sha256"], "seed": seed,
               "rows": private_rows,
               "note": "只供研究者在评分提交后揭盲；不要发送给评审者。"}
    mapping["map_sha256"] = digest(mapping)
    return packet, mapping


def render_packet(packet: dict[str, Any]) -> str:
    _verified(packet, PACKET_SCHEMA, "packet_sha256")
    lines = ["# 匿名文学质量评审包", "",
             "请只使用本文件和 `review-ratings.csv`。逐篇独立评分，不查看方案、指标实测值或其他篇的机器结论。",
             "数值目标由程序另行测量；这里的文风贴合分评价整体阅读印象，不要求评审者自行计数。",
             "`content_preservation_1_to_5` 在原创生成任务中表示**任务事实与因果完成度**，不是与来源文本逐字相似。", "",
             "## 评分锚点", "",
             "三项均为 1–5 分；2、4 分表示相邻锚点之间。每项分别评分，不合成总分。", "",
             "| 分数 | 目标文风贴合 | 任务事实与因果完成度 | 中文表达自然度 |",
             "| ---: | --- | --- | --- |",
             "| 1 | 句段、对白和叙述节奏明显背离目标 | 关键人物或事实错乱，任务未完成 | 大量病句、机械重复或难以理解 |",
             "| 3 | 部分风格接近，但有显著失衡 | 核心场景可辨，仍有重要核对或后果缺口 | 大体通顺，有明显模板腔或生硬安排 |",
             "| 5 | 整体节奏、对白功能与词句关系稳定贴合 | 必要事实、询问、决定与结果完整且自洽 | 流畅、具体、自然，无明显凑指标痕迹 |", "",
             "## 共同目标范围（供理解文风，不要求手工计数）", ""]
    for key, band in packet["targets"].items():
        lines.append(f"- `{key}`：{band['min']:g}–{band['max']:g} {band['unit']}")
    for key, band in packet["secondary_targets"].items():
        lines.append(f"- `{key}`：{band['min']:g}–{band['max']:g} {band['unit']}")
    for band in packet["lexical_targets"]:
        lines.append(f"- 高频语法词「{band['word']}」：{band['min']:g}–{band['max']:g} {band['unit']}")
    for row in packet["rows"]:
        lines.extend(["", f"## {row['review_id']}", "", "**场景任务**", "", row["brief"],
                      "", "**待评正文**", "", row["answer"], ""])
    return "\n".join(line.rstrip(" \t") for line in "\n".join(lines).split("\n"))


def ratings_template(packet: dict[str, Any]) -> str:
    _verified(packet, PACKET_SCHEMA, "packet_sha256")
    stream = io.StringIO(newline="")
    writer = csv.writer(stream)
    writer.writerow(["review_id", *FIELDS, "notes"])
    for row in packet["rows"]:
        writer.writerow([row["review_id"], "", "", "", ""])
    return stream.getvalue()


def collate(experiment: dict[str, Any], prompt: dict[str, Any], packet: dict[str, Any],
            mapping: dict[str, Any], rating_path: Path) -> tuple[str, dict[str, Any]]:
    _verified(packet, PACKET_SCHEMA, "packet_sha256")
    _verified(mapping, MAP_SCHEMA, "map_sha256")
    if (mapping["source_experiment_sha256"] != digest(experiment) or
            mapping["prompt_artifact_sha256"] != prompt.get("prompt_artifact_sha256") or
            mapping["packet_sha256"] != packet["packet_sha256"] or
            packet["prompt_sha256"] != prompt.get("prompt_sha256") or
            packet.get("targets") != prompt.get("targets") or
            packet.get("secondary_targets") != (prompt.get("secondary_targets") or {}) or
            packet.get("lexical_targets") != (prompt.get("lexical_targets") or [])):
        raise ContractError("review source artifacts changed after packet preparation")
    by_id = {str(row["review_id"]): row for row in mapping["rows"]}
    public = {str(row["review_id"]): row for row in packet["rows"]}
    if set(by_id) != set(public) or len(by_id) != len(mapping["rows"]):
        raise ContractError("review map does not cover exactly the public packet")
    source_runs = {str(row["blind_id"]): row for row in experiment.get("runs") or []
                   if row.get("status") == "completed" and str(row.get("answer") or "").strip()}
    source_cases = {str(row["case_id"]): str(row["brief"]) for row in experiment.get("cases") or []}
    if len(source_runs) != len(by_id) or {row["blind_id"] for row in by_id.values()} != set(source_runs):
        raise ContractError("review map does not cover exactly the completed source answers")
    for review_id, row in public.items():
        actual_sha = hashlib.sha256(str(row["answer"]).encode("utf-8")).hexdigest()
        source = source_runs[by_id[review_id]["blind_id"]]
        if (actual_sha != row["answer_sha256"] or actual_sha != by_id[review_id]["answer_sha256"] or
                actual_sha != hashlib.sha256(str(source["answer"]).encode("utf-8")).hexdigest() or
                by_id[review_id]["arm"] != source["arm"] or row["case_id"] != source["case_id"] or
                row["brief"] != source_cases.get(str(source["case_id"]))):
            raise ContractError(f"review answer changed: {review_id}")
    try:
        submitted_bytes = rating_path.read_bytes()
        stream = io.StringIO(submitted_bytes.decode("utf-8-sig"), newline="")
    except (OSError, UnicodeError) as exc:
        raise ContractError(f"cannot read review ratings: {exc}") from exc
    scores = {}
    reader = csv.DictReader(stream)
    if not reader.fieldnames or not {"review_id", *FIELDS, "notes"}.issubset(reader.fieldnames):
        raise ContractError("review ratings CSV is missing required columns")
    for item in reader:
        review_id = str(item.get("review_id") or "").strip()
        if review_id not in by_id or review_id in scores:
            raise ContractError(f"unknown or duplicate review ID: {review_id}")
        score_row = {}
        for field in FIELDS:
            raw = str(item.get(field) or "").strip()
            if raw and (not raw.isdigit() or not 1 <= int(raw) <= 5):
                raise ContractError(f"{review_id} {field} must be 1..5 or blank")
            score_row[field] = raw
        score_row["notes"] = str(item.get("notes") or "").strip()
        scores[review_id] = score_row
    if set(scores) != set(by_id):
        raise ContractError("ratings must contain one row for every review ID")
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["blind_id", *FIELDS, "notes"])
    for review_id, row in sorted(by_id.items(), key=lambda item: item[1]["blind_id"]):
        values = scores[review_id]
        writer.writerow([row["blind_id"], *(values[field] for field in FIELDS), values["notes"]])
    provenance = {"schema": "style-blind-review-import/v1",
                  "map_sha256": mapping["map_sha256"],
                  "packet_sha256": packet["packet_sha256"],
                  "submitted_ratings_sha256": hashlib.sha256(submitted_bytes).hexdigest(),
                  "rated_items_by_field": {field: sum(bool(row[field]) for row in scores.values()) for field in FIELDS},
                  "total_items": len(scores),
                  "note": "单份独立人工评分；如有更多评审者，须单独保存原表并报告分歧。"}
    provenance["import_sha256"] = digest(provenance)
    return output.getvalue(), provenance

"""Direct target attainment, without constructing an ordinary comparison arm."""

from .experiment_design import TARGET_ONLY, validate_design


FIELDS = (("axes", "target_distance", "targets"),
          ("secondary_axes", "secondary_target_distance", "secondary_targets"),
          ("lexical_axes", "lexical_target_distance", "lexical_targets"))


def mean(values):
    return sum(values) / len(values) if values else None


def summarize(experiment: dict, prompt: dict, evaluated: list, diagnostics: dict) -> dict:
    validate_design(experiment)
    rows = [row for row in evaluated if row["status"] == "completed"]
    result = {"schema": "style-report/v1", "experiment_design": TARGET_ONLY,
              "experiment_prompt_sha256": experiment["prompt_sha256"],
              "model": experiment.get("model"), "model_version": experiment.get("model_version", "unreported"),
              "worker_version": experiment.get("worker_version"),
              "planned_run_count": experiment.get("planned_run_count"),
              "completed_run_count": len(rows), "paired_count": 0, "pairs": [],
              "status": "target-only-statistical-evaluation", "quality_status": "unverified",
              "phase": experiment.get("phase", "fresh-generation"), "runs": evaluated,
              "warnings": list(experiment.get("warnings") or []),
              "interpretation": "按实际分母逐项判定目标命中；统计达标不证明文学质量或内容保持。"}
    for group, field, source in FIELDS:
        bands = prompt.get(source) or {}
        if isinstance(bands, list):
            bands = {str(band["word"]): band for band in bands}
        result[group] = {}
        for key, band in bands.items():
            values = [row[field][key] for row in rows if row[field].get(key) is not None]
            result[group][key] = {"unit": band["unit"], "target_range": band,
                                  "mean_distance": mean(values), "measured_count": len(values),
                                  "in_range_count": sum(value == 0 for value in values)}
    primary = sum(all(value == 0 for value in row["target_distance"].values()) for row in rows)
    joint = sum(all(value == 0 for _, field, _ in FIELDS for value in row[field].values()) for row in rows)
    result["target_attainment"] = {"primary_joint_count": primary, "all_targets_joint_count": joint,
                                   "completed_count": len(rows)}
    complete = bool(rows) and len(rows) == experiment.get("planned_run_count")
    result["acceptance"] = {"status": "pass" if complete and joint == len(rows) else
                             "fail" if complete else "not-evaluable", "all_planned_outputs_measured": complete,
                             "primary_all_in_range": complete and primary == len(rows),
                             "all_targets_in_range": complete and joint == len(rows),
                             "quality_status": "unverified"}
    result["diagnostic_summary"] = {key: {"count": len(values), "mean": mean(values)}
        for key in diagnostics for values in [[row["diagnostic_observed"][key] for row in rows
                                               if row["diagnostic_observed"].get(key) is not None]]}
    result["copy_risk"] = {"target": {"max_longest_shared_han": max(
        (int((row.get("copy_risk") or {}).get("longest_shared_han") or 0) for row in rows), default=None)}}
    copy_checked = bool(rows) and all(row.get("copy_risk") is not None for row in rows)
    copy_ok = copy_checked and result["copy_risk"]["target"]["max_longest_shared_han"] <= 24
    result["acceptance"]["source_copy_within_limit"] = copy_ok if copy_checked else None
    if result["acceptance"]["status"] == "pass" and not copy_ok:
        result["acceptance"]["status"] = "fail" if copy_checked else "not-evaluable"
    result["human_ratings"] = {key: {"target": {"rated_count": len(values), "mean": mean(values)}}
        for key in ("style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5")
        for values in [[row["human_ratings"][key] for row in rows if key in row["human_ratings"]]]}
    return result


def render(report: dict) -> str:
    attainment = report["target_attainment"]
    lines = ["# 参数组文风统计报告", "", f"模型：`{report.get('model')}`；修订：`{report['model_version']}`。",
             f"可测产物 {report['completed_run_count']}/{report['planned_run_count']}；"
             f"四主轴共同命中 {attainment['primary_joint_count']}；全部目标共同命中 {attainment['all_targets_joint_count']}。",
             f"全部目标统计门槛：`{report['acceptance']['status']}`；文学质量未验证。", "",
             "| 指标 | 目标范围 | 平均距离 | 命中/可测 |", "| --- | --- | ---: | ---: |"]
    for group, _, _ in FIELDS:
        for key, row in report[group].items():
            band = row["target_range"]
            lines.append(f"| {key} | {band['min']:g}–{band['max']:g} {row['unit']} | "
                         f"{row['mean_distance']} | {row['in_range_count']}/{row['measured_count']} |")
    lines += ["", "## 逐篇实际计量", "", "| 编号 | 汉字 | 词元 | 句 | 段 | 主轴命中 | 全部命中 |",
              "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for row in report["runs"]:
        if row["status"] != "completed":
            lines.append(f"| {row['blind_id']} | 无有效正文 | — | — | — | — | — |")
            continue
        sample = row["normalization_evidence"]["sample"]
        distances = [value for _, field, _ in FIELDS for value in row[field].values()]
        if report.get("dependency_axes"):
            distances += [value["distance"] for value in row["dependency_evaluation"]["targets"].values()]
        lines.append(f"| {row['blind_id']} | {sample['han_count']} | {sample['word_token_count']} | "
                     f"{sample['sentence_count']} | {sample['paragraph_count']} | "
                     f"{sum(v == 0 for v in row['target_distance'].values())}/4 | {sum(v == 0 for v in distances)}/{len(distances)} |")
    lines += ["", "各篇按自身汉字、词元、句段数复算；MATTR50 使用完整固定词窗。篇幅不参加验收。",
              "局部编辑产物可能是拒收后保留的原稿；模型调用数以运行记录为准。",
              "逐项实测值、计数及未舍入距离见报告 JSON。", "", report["interpretation"], ""]
    lines += [f"- {warning}" for warning in report["warnings"]]
    return "\n".join(lines) + "\n"

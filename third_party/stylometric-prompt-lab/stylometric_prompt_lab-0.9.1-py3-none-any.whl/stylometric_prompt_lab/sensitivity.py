"""Pre-registered single-metric contrasts for Chinese narrative generation."""

from __future__ import annotations

import hashlib
import random
from statistics import mean, median
from typing import Any, Callable

from .corpus import Corpus
from .experiment import copy_risk, validate_cases
from .extended_metrics import scalar_values, extended_statistics
from .io import ContractError, digest
from .metrics import measure
from .pi import PiWorker


SCHEMA = "style-sensitivity-plan/v1"
EXPERIMENT_SCHEMA = "style-sensitivity-experiment/v1"
REPORT_SCHEMA = "style-sensitivity-report/v1"
VERSION = "0.2.0"
BASE_SYSTEM = ("你是现代中文叙事写作者。依据场景任务写原创、完整、自然的故事。"
               "保持事实、人物动机和因果清楚。下面只改变一项可测语言特征；"
               "在不损害故事的前提下使它靠近给定范围。"
               "长度是硬约束：写作后自行核对正文汉字数，须在600–900之间；"
               "超过900就删去重复解释，少于600就补足必要的动作与选择。只输出正文，不解释指标。")

# Levels are deliberately separated. They test response direction, not literary quality.
CONTRASTS: dict[str, dict[str, tuple[float, float, str]]] = {
    "sentence_length_han": {
        "low": (11, 16, "以短而完整的句子推进动作，减少多层从句。"),
        "high": (25, 35, "用较长的完整句交代动作、原因与感官层次，避免逗号堆砌。")},
    "paragraph_length_han": {
        "low": (30, 50, "在行动或认识转折处频繁换段，但不要每句单独成段。"),
        "high": (90, 140, "将连续动作与反应写成较长段落，只在场景转折处换段。")},
    "dialogue_share": {
        "low": (0, .08, "让选择主要通过动作和叙述显现，只保留一两句必要发言。"),
        "high": (.28, .40, "让关键关系与选择通过几次完整发言显现；每次发言承担判断或回应，避免一两字短答。")},
    "punctuation_per_1000_han": {
        "low": (90, 130, "用较完整的句子与较少的句内停顿写作，避免密集引号和插入语。"),
        "high": (180, 230, "用句号、逗号与少量其他标点组织清晰停顿，避免靠感叹号和密集引号凑数。")},
    "short_sentence_share_le20_han": {
        "low": (.25, .45, "让多数句子有展开的因果或动作层次，少用短句。"),
        "high": (.65, .85, "让多数句子在二十个汉字内完成一个动作或判断，避免碎片句。")},
    "long_sentence_share_gt30_han": {
        "low": (.02, .08, "把多层长句拆为清晰的完整句，少用超过三十汉字的句子。"),
        "high": (.25, .40, "在交代因果和感官时保留较多超过三十汉字的长句，保持易读。")},
    "clause_segments_per_sentence_proxy": {
        "low": (1.2, 1.6, "多数句子只说一个完整动作或判断，少用逗号串接。"),
        "high": (2.6, 3.3, "在完整句中用逗号连接动作、原因与反应，避免散乱的并列清单。")},
    "quote_spans_per_1000_han": {
        "low": (0, 4, "仅给最关键的发言加引号，其余关系通过叙述和动作表现。"),
        "high": (16, 24, "安排较多有信息量的发言轮次，每段发言仍是完整判断，不用单字应答凑数。")},
    "word_length_mean_han": {
        "low": (1.30, 1.45, "多用自然、具体的短词和单音节常用词，避免生造词。"),
        "high": (1.65, 1.85, "适当使用准确的双音节与多音节具体词，避免抽象名词堆砌。")},
    "word_mattr_50": {
        "low": (.76, .84, "有意识地复现几个关键物件和动作的原词，让语言形成回环，保持自然。"),
        "high": (.90, .96, "减少近距离的原词重复，用准确而自然的不同词语描写动作和物件。")},
    "activity_v_over_v_plus_a": {
        "low": (.72, .82, "在动作之间增加具体的形容词描写，让人物与环境有可感的状态。"),
        "high": (.90, .97, "以具体动词推动情节，形容词只在必要处出现。")},
    "nominality_n_over_n_plus_v": {
        "low": (.35, .45, "用人物的动作推进场景，减少反复列举物件和地点。"),
        "high": (.55, .65, "用具体人物、物件、地点和名称建立场景锚点，再让它们参与动作。")},
    "function_pos_share_proxy": {
        "low": (.12, .18, "以直接的短句连缀动作，少用重复的助词、介词和连接词。"),
        "high": (.25, .33, "用自然的助词、介词与连接词交代地点、时间和句间关系，不硬塞虚词。")},
}
LEXICAL_HINTS = {
    "的": "用准确的限定语说明人物和物件。",
    "把": "在符合语义的动作处使用把字句并交代处置结果。",
    "了": "在确已完成的动作或状态变化处自然使用。",
    "在": "在地点、时间或进行中的动作处自然使用。",
}


def _contrast(metric: str, prompt: dict[str, Any]) -> dict[str, Any]:
    targets = prompt.get("targets") or {}
    secondary = prompt.get("secondary_targets") or {}
    lexical = {f"lexical:{row['word']}": row for row in prompt.get("lexical_targets") or []}
    if metric in targets:
        band, family = targets[metric], "primary"
    elif metric in secondary:
        band, family = secondary[metric], "secondary"
    elif metric in lexical:
        band, family = lexical[metric], "lexical"
    else:
        raise ContractError(f"metric is not an active measured target: {metric}")
    if family != "lexical":
        if metric not in CONTRASTS:
            raise ContractError(f"no contrast definition for {metric}")
        levels = CONTRASTS[metric]
    else:
        word = str(band["word"])
        lower, upper = float(band["min"]), float(band["max"])
        width = max(upper - lower, 5)
        levels = {
            "low": (0, round(max(2, lower / 3), 2), f"只在语义必要时使用「{word}」，避免重复。"),
            "high": (round(upper, 2), round(min(1000, upper + width), 2),
                     f"适度提高「{word}」的自然使用频率。{LEXICAL_HINTS.get(word, '只在符合语义的句式中使用。')}"),
        }
    return {"metric": metric, "family": family, "unit": band["unit"],
            "levels": {name: {"min": values[0], "max": values[1], "instruction": values[2]}
                       for name, values in levels.items()}}


def prepare_plan(prompt: dict[str, Any], cases_value: dict[str, Any], metrics: list[str], *,
                 repetitions: int = 1, seed: int = 20260929) -> dict[str, Any]:
    from .dependency_targets import require_legacy_targets
    require_legacy_targets(prompt, "legacy sensitivity plan")
    if prompt.get("schema") != "literary-style-prompt/v1" or not prompt.get("prompt_sha256"):
        raise ContractError("sensitivity plan needs a versioned prompt artifact")
    if (hashlib.sha256(str(prompt.get("prompt_markdown") or "").encode("utf-8")).hexdigest()
            != prompt["prompt_sha256"] or
            prompt.get("prompt_artifact_sha256") != digest({key: value for key, value in prompt.items()
                                                           if key != "prompt_artifact_sha256"})):
        raise ContractError("source prompt hash does not match its contents")
    if repetitions < 1 or repetitions > 10 or not metrics or len(set(metrics)) != len(metrics):
        raise ContractError("sensitivity plan needs unique metrics and 1..10 repetitions")
    cases = validate_cases(cases_value)
    specs = {metric: _contrast(metric, prompt) for metric in metrics}
    jobs = [(case, repetition, metric, level) for case in cases
            for repetition in range(1, repetitions + 1) for metric in metrics
            for level in ("low", "high")]
    random.Random(seed).shuffle(jobs)
    rows = []
    for number, (case, repetition, metric, level) in enumerate(jobs, 1):
        spec = specs[metric]
        band = spec["levels"][level]
        system = (f"{BASE_SYSTEM}\n\n单项指标：{metric}；目标 "
                  f"{band['min']:g}–{band['max']:g} {spec['unit']}。\n{band['instruction']}")
        user = case["brief"] + "\n正文以约 700 汉字为中心，严格保持在 600–900 汉字内。"
        rows.append({"blind_id": f"S{number:03d}", "case_id": case["case_id"],
                     "topic": case["topic"], "repetition": repetition,
                     "metric": metric, "level": level,
                     "system_prompt": system, "user_prompt": user,
                     "system_prompt_sha256": hashlib.sha256(system.encode("utf-8")).hexdigest(),
                     "user_prompt_sha256": hashlib.sha256(user.encode("utf-8")).hexdigest()})
    plan = {"schema": SCHEMA, "algorithm_version": VERSION,
            "source_prompt_sha256": prompt["prompt_sha256"],
            "cases_sha256": digest(cases_value), "metrics": specs,
            "seed": seed, "repetitions": repetitions,
            "planned_run_count": len(rows), "jobs": rows,
            "purpose": "single-metric low/high response screening; no significance or literary quality claim"}
    plan["plan_sha256"] = digest(plan)
    return plan


def render_plan(plan: dict[str, Any]) -> str:
    lines = ["# 单参数高低扰动预注册执行单", "",
             f"计划哈希：`{plan['plan_sha256']}`；来源提示词哈希：`{plan['source_prompt_sha256']}`。",
             f"固定种子 {plan['seed']}；{plan['planned_run_count']} 次独立生成。",
             "每次只提示一个指标的高或低范围，故事任务与长度要求相同。比较同题同重复的高减低实测值，记录其他指标的连带变化；不据此推断文学质量。", "",
             "| 指标 | 低范围 | 高范围 | 单位 |", "| --- | ---: | ---: | --- |"]
    for metric, spec in plan["metrics"].items():
        low, high = spec["levels"]["low"], spec["levels"]["high"]
        lines.append(f"| {metric} | {low['min']:g}–{low['max']:g} | {high['min']:g}–{high['max']:g} | {spec['unit']} |")
    lines.extend(["", "逐次输入、顺序及提示词哈希见同目录 JSON。", ""])
    return "\n".join(lines)


def _validate_plan(plan: dict[str, Any]) -> None:
    if (plan.get("schema") != SCHEMA or
            plan.get("plan_sha256") != digest({key: value for key, value in plan.items()
                                               if key != "plan_sha256"})):
        raise ContractError("sensitivity plan hash or schema is invalid")


def run_plan(plan: dict[str, Any], worker: PiWorker, corpus: Corpus, *,
             existing: dict[str, Any] | None = None,
             on_progress: Callable[[dict[str, Any]], None] | None = None) -> dict[str, Any]:
    _validate_plan(plan)
    if existing is not None and (existing.get("schema") != EXPERIMENT_SCHEMA or
                                 existing.get("plan_sha256") != plan["plan_sha256"] or
                                 existing.get("model") != worker.model or
                                 existing.get("model_version") != getattr(worker, "model_version", "unreported")):
        raise ContractError("existing sensitivity run belongs to a different plan or model")
    completed = {row["blind_id"]: row for row in (existing or {}).get("runs", [])
                 if row.get("status") == "completed"}
    worker_version = worker.version()
    if existing is not None and existing.get("worker_version") != worker_version:
        raise ContractError("cannot resume sensitivity run with a different worker version")
    result = {"schema": EXPERIMENT_SCHEMA, "plan_sha256": plan["plan_sha256"],
              "model": worker.model, "model_version": getattr(worker, "model_version", "unreported"),
              "worker_version": worker_version, "planned_run_count": plan["planned_run_count"],
              "completed_run_count": len(completed), "runs": list(completed.values())}
    for job in plan["jobs"]:
        if job["blind_id"] in completed:
            continue
        output = worker.run(job["system_prompt"], job["user_prompt"])
        row = {key: job[key] for key in ("blind_id", "case_id", "topic", "repetition",
                                         "metric", "level", "system_prompt_sha256",
                                         "user_prompt_sha256")}
        row.update({"status": output.status, "answer": output.answer, "failure": output.failure,
                    "model": output.model, "worker_version": output.worker_version,
                    "events": list(output.events),
                    "copy_risk": copy_risk(output.answer, corpus) if output.answer else None})
        result["runs"] = [item for item in result["runs"] if item["blind_id"] != job["blind_id"]] + [row]
        result["completed_run_count"] = sum(item["status"] == "completed" for item in result["runs"])
        if on_progress:
            on_progress(result)
        if output.status != "completed" and any(text in output.failure.lower() for text in
                                                  ("quota", "not authenticated", "authentication")):
            break
    result["runs"].sort(key=lambda row: row["blind_id"])
    return result


def _value(text: str, spec: dict[str, Any]) -> tuple[float | None, dict[str, float | None], int]:
    primary = measure(text)
    extended = extended_statistics(text)
    scalars = scalar_values(extended)
    all_values: dict[str, float | None] = {**primary["axes"], **scalars}
    token_total = int(extended["sample"]["word_token_count"])
    counts = extended["grammar"]["function_word_counts"]
    for word in LEXICAL_HINTS:
        all_values[f"lexical:{word}"] = round(1000 * counts.get(word, 0) / token_total, 4) if token_total else None
    metric = spec["metric"]
    if metric.startswith("lexical:") and metric not in all_values:
        word = metric.removeprefix("lexical:")
        all_values[metric] = round(1000 * counts.get(word, 0) / token_total, 4) if token_total else None
    return all_values.get(metric), all_values, int(primary["han_count"])


def evaluate_plan(plan: dict[str, Any], experiment: dict[str, Any]) -> dict[str, Any]:
    _validate_plan(plan)
    if experiment.get("schema") != EXPERIMENT_SCHEMA or experiment.get("plan_sha256") != plan["plan_sha256"]:
        raise ContractError("sensitivity run does not match plan")
    jobs = {job["blind_id"]: job for job in plan["jobs"]}
    rows = []
    for run in experiment.get("runs", []):
        job = jobs.get(run.get("blind_id"))
        if job is None or any(run.get(key) != job[key] for key in
                              ("case_id", "repetition", "metric", "level", "system_prompt_sha256")):
            raise ContractError("sensitivity run job identity differs from plan")
        if run.get("status") != "completed" or not run.get("answer"):
            continue
        observed, all_values, han_count = _value(run["answer"], plan["metrics"][job["metric"]])
        rows.append({"blind_id": run["blind_id"], "case_id": job["case_id"],
                     "repetition": job["repetition"], "metric": job["metric"],
                     "level": job["level"], "observed": observed,
                     "all_observed": all_values, "han_count": han_count,
                     "copy_risk": run.get("copy_risk")})
    by_metric: dict[str, Any] = {}
    for metric in plan["metrics"]:
        found = {(row["case_id"], row["repetition"], row["level"]): row for row in rows
                 if row["metric"] == metric and row["observed"] is not None}
        pairs = []
        for case_id, repetition in sorted({(job["case_id"], job["repetition"])
                                           for job in plan["jobs"] if job["metric"] == metric}):
            low, high = found.get((case_id, repetition, "low")), found.get((case_id, repetition, "high"))
            if low and high:
                pairs.append({"case_id": case_id, "repetition": repetition,
                              "low": low["observed"], "high": high["observed"],
                              "difference": round(high["observed"] - low["observed"], 4),
                              "low_han_count": low["han_count"], "high_han_count": high["han_count"]})
        differences = [row["difference"] for row in pairs]
        low_band = plan["metrics"][metric]["levels"]["low"]
        high_band = plan["metrics"][metric]["levels"]["high"]
        length_hits = sum(600 <= row["low_han_count"] <= 900 for row in pairs) + sum(
            600 <= row["high_han_count"] <= 900 for row in pairs)
        cross_effects = {}
        for other_metric, other_spec in plan["metrics"].items():
            cross_differences = []
            for pair in pairs:
                low_run = found[(pair["case_id"], pair["repetition"], "low")]
                high_run = found[(pair["case_id"], pair["repetition"], "high")]
                low_value = low_run["all_observed"].get(other_metric)
                high_value = high_run["all_observed"].get(other_metric)
                if low_value is not None and high_value is not None:
                    cross_differences.append(high_value - low_value)
            if cross_differences:
                contrast_gap = max(other_spec["levels"]["high"]["min"] -
                                   other_spec["levels"]["low"]["max"], .001)
                cross_effects[other_metric] = {
                    "mean_high_minus_low": round(mean(cross_differences), 4),
                    "contrast_gap_units": round(mean(cross_differences) / contrast_gap, 4),
                    "measured_pairs": len(cross_differences),
                }
        by_metric[metric] = {"family": plan["metrics"][metric]["family"],
                             "unit": plan["metrics"][metric]["unit"],
                             "pair_count": len(pairs),
                             "low_mean": round(mean(row["low"] for row in pairs), 4) if pairs else None,
                             "high_mean": round(mean(row["high"] for row in pairs), 4) if pairs else None,
                             "low_band_hits": sum(low_band["min"] <= row["low"] <= low_band["max"]
                                                  for row in pairs),
                             "high_band_hits": sum(high_band["min"] <= row["high"] <= high_band["max"]
                                                   for row in pairs),
                             "length_600_to_900_hits": length_hits,
                             "positive_pairs": sum(value > 1e-8 for value in differences),
                             "negative_pairs": sum(value < -1e-8 for value in differences),
                             "tied_pairs": sum(abs(value) <= 1e-8 for value in differences),
                             "mean_high_minus_low": round(mean(differences), 4) if differences else None,
                             "median_high_minus_low": round(median(differences), 4) if differences else None,
                             "cross_effects": cross_effects,
                             "pairs": pairs}
    return {"schema": REPORT_SCHEMA, "plan_sha256": plan["plan_sha256"],
            "experiment_sha256": digest(experiment), "model": experiment["model"],
            "planned_run_count": plan["planned_run_count"], "completed_run_count": len(rows),
            "length_600_to_900_count": sum(600 <= row["han_count"] <= 900 for row in rows),
            "metrics": by_metric, "runs": rows,
            "interpretation": "High-minus-low is a directional prompt-response contrast, not proof of genre-independent style control or literary quality."}


def render_report(report: dict[str, Any]) -> str:
    lines = ["# 单参数提示响应筛查", "",
             f"模型：`{report['model']}`；完成 {report['completed_run_count']}/{report['planned_run_count']} 次。",
             f"长度 600–900 汉字：{report['length_600_to_900_count']}/{report['completed_run_count']} 篇。",
             "高减低为正表示输出沿指定方向变化；区间命中与长度遵守另列。样本少、未盲评，不作显著性或文学质量结论。", "",
             "| 指标 | 成对数 | 正向/反向/持平 | 低→高实测均值 | 指令区间命中低/高 | 长度命中 |",
             "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for metric, row in report["metrics"].items():
        observed = ("—" if row["low_mean"] is None else
                    f"{row['low_mean']:.4f}→{row['high_mean']:.4f} {row['unit']}")
        lines.append(f"| {metric} | {row['pair_count']} | {row['positive_pairs']}/{row['negative_pairs']}/{row['tied_pairs']} | "
                     f"{observed} | {row['low_band_hits']}/{row['high_band_hits']} | "
                     f"{row['length_600_to_900_hits']}/{row['pair_count'] * 2} |")
    lines.extend(["", "## 最大的连带变化", "",
                  "以受影响指标的高低目标间隔作尺度，仅供识别可能的相互牵制。", "",
                  "| 被提示指标 | 其他指标的最大三项变化 |", "| --- | --- |"])
    for metric, row in report["metrics"].items():
        others = [(key, value) for key, value in row["cross_effects"].items() if key != metric]
        others.sort(key=lambda item: -abs(item[1]["contrast_gap_units"]))
        parts = [f"{key} {value['mean_high_minus_low']:+.3f}" for key, value in others[:3]]
        lines.append(f"| {metric} | {', '.join(parts) if parts else '—'} |")
    lines.extend(["", "逐篇观测值和完整连带变化矩阵见同目录 JSON。", ""])
    return "\n".join(lines)

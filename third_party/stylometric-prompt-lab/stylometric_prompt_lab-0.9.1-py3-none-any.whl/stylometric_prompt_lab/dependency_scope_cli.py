"""Independent conditional-scope export, strict patch import and evaluation."""
import argparse
from pathlib import Path

from .corpus import load_corpus
from .dependency_feedback import adjudicate, render_result
from .dependency_scope import SCHEMA, apply_scope, prepare_scope, validate_scope
from .io import ContractError, read_object, write_object, write_text


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['plan', 'apply', 'evaluate'])
    parser.add_argument('--joint', type=Path)
    parser.add_argument('--scope', type=Path)
    parser.add_argument('--response', type=Path)
    parser.add_argument('--parse', type=Path)
    parser.add_argument('--corpus', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(argv)
    if args.out.exists():
        raise ContractError('scope output already exists')
    corpus = load_corpus(args.corpus)
    if args.phase == 'plan':
        if not args.joint:
            parser.error('plan requires --joint')
        scope = prepare_scope(read_object(args.joint, 'style-joint-guidance/v1'), corpus)
        write_object(args.out / 'scope-plan.json', scope)
        write_text(args.out / 'input.txt', scope['input_text'])
        print(scope['scope_plan_sha256'])
        return
    if not args.scope:
        parser.error('apply/evaluate require --scope')
    scope = read_object(args.scope, SCHEMA)
    validate_scope(scope, corpus)
    if args.phase == 'apply':
        if not args.response:
            parser.error('apply requires --response')
        candidate, record = apply_scope(scope, args.response.read_text(encoding='utf-8'), corpus)
        write_text(args.out / 'candidate.txt', candidate)
        write_object(args.out / 'import.json', record)
    else:
        if not args.parse or not args.response:
            parser.error('evaluate requires --parse and --response')
        candidate, record = apply_scope(scope, args.response.read_text(encoding='utf-8'), corpus)
        parsed = read_object(args.parse, 'style-dependency-parse/v1')
        if parsed['text'] != candidate:
            raise ContractError('scope parse belongs to a different assembled patch candidate')
        result = adjudicate(scope['joint_guidance']['base_feedback_plan'], parsed['text'], parsed, corpus)
        write_object(args.out / 'import.json', record)
        write_object(args.out / 'result.json', result)
        write_text(args.out / 'result.md', render_result(result))
        print('统计接受：', result['decision']['accepted'])


if __name__ == '__main__':
    main()

"""Narrow adapter to ArcVellum Pi Worker's tool-free conversation protocol."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import subprocess
import tempfile
from typing import Any


@dataclass(frozen=True)
class PiResult:
    status: str
    answer: str
    failure: str
    worker_version: str
    model: str
    events: tuple[dict[str, Any], ...]


class PiWorker:
    def __init__(self, entrypoint: Path, model: str, *, executable: str = "node", auth_path: Path | None = None,
                 timeout: int = 240, thinking: str = "low", model_version: str = "unreported") -> None:
        self.entrypoint = entrypoint.expanduser().resolve()
        self.model = model.strip()
        self.model_version = model_version.strip() or "unreported"
        self.executable = executable
        self.auth_path = auth_path.expanduser().resolve() if auth_path else None
        self.timeout = timeout
        self.thinking = thinking
        if not self.entrypoint.is_file() or not self.model or timeout < 10:
            raise ValueError("Pi Worker requires an existing entrypoint, explicit model, and timeout >= 10 seconds")

    def version(self) -> str:
        try:
            completed = subprocess.run([self.executable, str(self.entrypoint), "--version"],
                                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15,
                                       creationflags=_hidden())
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise RuntimeError(_redact(str(exc), self.auth_path)) from exc
        if completed.returncode:
            raise RuntimeError(_redact(completed.stderr or completed.stdout, self.auth_path))
        return completed.stdout.strip()

    def run(self, system_prompt: str, prompt: str) -> PiResult:
        envelope = {"schema": "arcvellum/default-conversation/v1", "system_prompt": system_prompt, "prompt": prompt}
        with tempfile.TemporaryDirectory(prefix="styloprompt-pi-") as directory:
            command = [self.executable, str(self.entrypoint), "--workspace", directory,
                       "--mode", "conversation", "--conversation-role", "default", "--model", self.model,
                       "--thinking", self.thinking, "--max-turns", "1", "--max-tools", "1",
                       "--provider-total-timeout-ms", str(self.timeout * 1000)]
            if self.auth_path:
                command.extend(["--auth-path", str(self.auth_path)])
            try:
                completed = subprocess.run(command, input=json.dumps(envelope, ensure_ascii=False),
                                           capture_output=True, text=True, encoding="utf-8", errors="replace",
                                           timeout=self.timeout + 10, cwd=directory, creationflags=_hidden())
            except (OSError, subprocess.TimeoutExpired) as exc:
                return PiResult("failed", "", _redact(str(exc), self.auth_path), "", self.model, ())
        events: list[dict[str, Any]] = []
        answer = ""
        status = "failed"
        failure = ""
        worker_version = ""
        for line in completed.stdout.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            name = str(event.get("event") or "")
            data = event.get("data") if isinstance(event.get("data"), dict) else {}
            if name == "runner.ready":
                worker_version = str(data.get("version") or "")
            if name == "runner.conversation.result":
                answer = str(data.get("answer") or "").strip()
                status = str(data.get("status") or "failed")
            if name == "runner.worker.result" and status != "completed":
                failure = str(data.get("message") or "")
            if name == "runner.warning" and not failure:
                failure = str(data.get("detail") or "")
            if name in {"runner.ready", "runner.session.created", "runner.session.finished",
                        "runner.provider.request.started", "usage.updated", "runner.conversation.result",
                        "runner.worker.result", "runner.warning"}:
                safe_data = _safe_data(data)
                if name in {"runner.conversation.result", "runner.worker.result"}:
                    safe_data.pop("answer", None)
                events.append({"event": name, "at": event.get("at"), "data": safe_data})
        if completed.returncode or status != "completed" or not answer:
            status = "failed"
            failure = _redact(failure or completed.stderr.strip() or f"worker exited {completed.returncode}", self.auth_path)
            answer = ""
        return PiResult(status, answer, failure[:1000], worker_version, self.model, tuple(events))


def _safe_data(data: dict[str, Any]) -> dict[str, Any]:
    allowed = {"version", "status", "model", "provider", "turn", "input_tokens", "output_tokens",
               "total_tokens", "duration_ms", "session_id", "conversation_id", "request_id"}
    result: dict[str, Any] = {}
    for key, value in data.items():
        if key not in allowed:
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            result[key] = _redact(value[:200], None) if isinstance(value, str) else value
    return result


def _redact(text: str, auth_path: Path | None) -> str:
    if auth_path:
        text = text.replace(str(auth_path), "[auth]")
    text = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._-]+", r"\1[redacted]", text)
    text = re.sub(r"(?i)(api[_-]?key\s*[:=]\s*)\S+", r"\1[redacted]", text)
    return re.sub(r"sk-[A-Za-z0-9_-]{12,}", "[redacted]", text)


def _hidden() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)

"""Dimension-wise evaluation without a composite literary quality score."""

from __future__ import annotations

import csv
import hashlib
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from statistics import mean
from typing import Any

from .io import ContractError, digest
from .extended_metrics import SECONDARY_AXES, SCALAR_PATHS, extended_statistics, scalar_values
from .metrics import AXES, measure
from .dependency_targets import attach_evaluations, attach_report, render_report_extension


DIAGNOSTIC_PATHS = SCALAR_PATHS


def normalization_evidence(metrics: dict[str, Any], extended: dict[str, Any],
                           targets: dict[str, Any], secondary: dict[str, Any],
                           lexical: list[dict[str, Any]]) -> dict[str, Any]:
    """Show the actual numerator and denominator behind each comparable target."""
    han = int(metrics["han_count"])
    sentences = int(metrics["sentence_count"])
    paragraphs = int(metrics["paragraph_count"])
    tokens = int(extended["sample"]["word_token_count"])
    rhythm = extended["rhythm"]
    grammar = extended["grammar"]
    pos = grammar["pos_counts"]

    def row(numerator: int, denominator: int, scale: int, band: dict[str, Any],
            numerator_unit: str, denominator_unit: str) -> dict[str, Any]:
        lower = Decimal(str(band["min"])) * denominator / scale
        upper = Decimal(str(band["max"])) * denominator / scale
        integer_min = int(lower.to_integral_value(rounding=ROUND_CEILING))
        integer_max = int(upper.to_integral_value(rounding=ROUND_FLOOR))
        return {"numerator": numerator, "numerator_unit": numerator_unit,
                "denominator": denominator, "denominator_unit": denominator_unit,
                "scale": scale,
                "target_numerator_range_at_actual_denominator": (
                    {"min": round(float(lower), 4), "max": round(float(upper), 4)} if denominator else None),
                "attainable_integer_count_range": (
                    {"min": integer_min, "max": integer_max}
                    if denominator and integer_min <= integer_max else None)}

    primary_basis = {
        "sentence_length_han": (han, sentences, 1, "汉字", "句"),
        "paragraph_length_han": (han, paragraphs, 1, "汉字", "段"),
        "dialogue_share": (int(metrics["dialogue_han_count"]), han, 1, "对白汉字", "汉字"),
        "punctuation_per_1000_han": (int(metrics["punctuation_count"]), han, 1000, "标点处", "汉字"),
    }
    secondary_basis = {
        "short_sentence_share_le20_han": (int(rhythm["short_sentence_count_le20_han"]), sentences, 1, "短句", "句"),
        "long_sentence_share_gt30_han": (int(rhythm["long_sentence_count_gt30_han"]), sentences, 1, "长句", "句"),
        "clause_segments_per_sentence_proxy": (int(rhythm["clause_segment_count_proxy"]), sentences, 1, "片段", "句"),
        "quote_spans_per_1000_han": (int(rhythm["quote_span_count"]), han, 1000, "引号片段", "汉字"),
        "word_length_mean_han": (int(extended["lexical"]["word_han_count"]), tokens, 1, "分词后汉字", "词元"),
        "activity_v_over_v_plus_a": (int(pos["v"]), int(pos["v"] + pos["a"]), 1, "动词", "动词+形容词"),
        "nominality_n_over_n_plus_v": (int(pos["n"]), int(pos["n"] + pos["v"]), 1, "名词", "名词+动词"),
        "function_pos_share_proxy": (sum(int(pos[key]) for key in ("d", "p", "c", "u", "o")), tokens, 1,
                                     "功能类词性词元", "词元"),
    }
    primary_rows = {key: row(n, d, scale, targets[key], nu, du)
                    for key, (n, d, scale, nu, du) in primary_basis.items()}
    secondary_rows = {key: row(n, d, scale, secondary[key], nu, du)
                      for key, (n, d, scale, nu, du) in secondary_basis.items() if key in secondary}
    if "word_mattr_50" in secondary:
        mattr_windows = int(extended["lexical"]["word_mattr_50_window_count"])
        secondary_rows["word_mattr_50"] = {
            **(row(int(extended["lexical"]["word_mattr_50_distinct_type_sum"]),
                   mattr_windows * 50, 1, secondary["word_mattr_50"],
                   "各完整词窗不同词数之和", "完整词窗总词元") if mattr_windows else {}),
            "window_size_tokens": 50,
            "complete_window_count": mattr_windows,
            "token_count": tokens, "length_scaling": "none; mean over complete fixed-width windows"}
    lexical_rows = {str(band["word"]): row(int(grammar["function_word_counts"].get(str(band["word"]), 0)),
                                           tokens, 1000, band, "功能词词元", "词元") for band in lexical}
    return {"schema": "actual-length-normalization/v1",
            "sample": {"han_count": han, "sentence_count": sentences,
                       "paragraph_count": paragraphs, "word_token_count": tokens},
            "primary": primary_rows, "secondary": secondary_rows, "lexical": lexical_rows,
            "note": "按各篇实际分母计算；目标原始计数范围仅供核算，不另设篇幅门槛。MATTR50 使用固定 50 词窗。"}


def load_ratings(path: Path | None, valid_ids: set[str]) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    result: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            blind_id = str(row.get("blind_id") or "").strip()
            if blind_id not in valid_ids or blind_id in result:
                raise ContractError(f"unknown or repeated blind_id in ratings: {blind_id}")
            scores: dict[str, Any] = {"notes": str(row.get("notes") or "").strip()}
            for field in ("style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5"):
                raw = str(row.get(field) or "").strip()
                if raw:
                    try:
                        score = int(raw)
                    except ValueError as exc:
                        raise ContractError(f"{field} must be an integer 1..5") from exc
                    if score < 1 or score > 5:
                        raise ContractError(f"{field} must be 1..5")
                    scores[field] = score
                else:
                    scores[field] = None
            result[blind_id] = scores
    return result


def exact_distance_from_counts(basis: dict[str, Any], band: dict[str, Any]) -> float | None:
    """Evaluate an unrounded measured ratio against the registered band."""
    denominator = int(basis.get("denominator") or 0)
    if denominator == 0:
        return None
    observed = Decimal(int(basis["numerator"])) * int(basis["scale"]) / denominator
    gap = max(Decimal(str(band["min"])) - observed,
              observed - Decimal(str(band["max"])), Decimal(0))
    return float(gap.quantize(Decimal("0.00000001"), rounding=ROUND_CEILING))


def _validate_inputs(experiment: dict[str, Any], prompt: dict[str, Any]) -> dict[str, Any]:
    if experiment.get("schema") != "style-experiment/v1":
        raise ContractError("experiment must have schema style-experiment/v1")
    if prompt.get("schema") != "literary-style-prompt/v1" or prompt.get("prompt_sha256") != experiment.get("prompt_sha256"):
        raise ContractError("prompt does not match experiment")
    if hashlib.sha256(str(prompt.get("prompt_markdown") or "").encode("utf-8")).hexdigest() != prompt.get("prompt_sha256"):
        raise ContractError("prompt hash does not match its contents")
    if prompt.get("prompt_artifact_sha256") != digest({key: value for key, value in prompt.items()
                                                       if key != "prompt_artifact_sha256"}):
        raise ContractError("prompt artifact hash does not match its contents")
    if prompt.get("profile_sha256") != experiment.get("profile_sha256"):
        raise ContractError("prompt profile does not match experiment")
    targets = prompt.get("targets")
    if not isinstance(targets, dict) or set(targets) != set(AXES):
        raise ContractError("prompt has invalid targets")
    secondary = prompt.get("secondary_targets") or {}
    if not isinstance(secondary, dict) or (secondary and set(secondary) != set(SECONDARY_AXES)):
        raise ContractError("prompt has invalid secondary targets")
    for key, band in secondary.items():
        if not isinstance(band, dict) or band.get("unit") != SECONDARY_AXES[key]:
            raise ContractError(f"invalid secondary target unit for {key}")
        try:
            lower, upper = float(band["min"]), float(band["max"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ContractError(f"invalid secondary target for {key}") from exc
        if lower > upper:
            raise ContractError(f"invalid secondary target range for {key}")
    lexical = prompt.get("lexical_targets") or []
    if not isinstance(lexical, list) or len(lexical) > 6 or len({
            row.get("word") for row in lexical if isinstance(row, dict)}) != len(lexical):
        raise ContractError("prompt has invalid lexical targets")
    return targets


def evaluate(experiment: dict[str, Any], prompt: dict[str, Any], ratings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    targets = _validate_inputs(experiment, prompt)
    secondary_targets = prompt.get("secondary_targets") or {}
    lexical_targets = prompt.get("lexical_targets") or []
    evaluated: list[dict[str, Any]] = []
    for run in experiment.get("runs", []):
        if not isinstance(run, dict):
            raise ContractError("run must be an object")
        if run.get("status") != "completed" or not str(run.get("answer") or "").strip():
            evaluated.append({"blind_id": run.get("blind_id"), "case_id": run.get("case_id"),
                              "repetition": run.get("repetition"), "arm": run.get("arm"),
                              "status": "failed", "failure": run.get("failure")})
            continue
        metrics = measure(str(run["answer"]))
        if not metrics["han_count"]:
            evaluated.append({"blind_id": run.get("blind_id"), "case_id": run.get("case_id"),
                              "repetition": run.get("repetition"), "arm": run.get("arm"),
                              "status": "failed", "failure": "answer contains no Han characters"})
            continue
        extended = extended_statistics(str(run["answer"]))
        diagnostic = scalar_values(extended)
        normalization = normalization_evidence(metrics, extended, targets,
                                               secondary_targets, lexical_targets)
        distances = {key: exact_distance_from_counts(normalization["primary"][key], targets[key])
                     for key in AXES}
        secondary_distances = {
            key: exact_distance_from_counts(normalization["secondary"][key], band)
            for key, band in secondary_targets.items()
        }
        token_total = int(extended["sample"]["word_token_count"])
        function_counts = extended["grammar"]["function_word_counts"]
        lexical_observed = {str(row["word"]): round(1000 * function_counts.get(str(row["word"]), 0) / token_total, 4)
                            if token_total else None for row in lexical_targets}
        lexical_distances = {str(row["word"]): exact_distance_from_counts(
            normalization["lexical"][str(row["word"])], row) for row in lexical_targets}
        evaluated.append({"blind_id": run["blind_id"], "case_id": run["case_id"],
                          "repetition": run["repetition"], "arm": run["arm"], "status": "completed",
                          "han_count": metrics["han_count"], "observed": metrics["axes"],
                          "diagnostic_observed": diagnostic,
                          "target_distance": distances,
                          "secondary_target_distance": secondary_distances,
                          "lexical_observed": lexical_observed,
                          "lexical_target_distance": lexical_distances,
                          "normalization_evidence": normalization,
                          "copy_risk": run.get("copy_risk"),
                          "human_ratings": ratings.get(run["blind_id"], {})})
    attach_evaluations(experiment, prompt, evaluated)
    valid = [row for row in evaluated if row["status"] == "completed"]
    if experiment.get("experiment_design") == "target_only":
        from .single_arm_reporting import summarize
        return attach_report(summarize(experiment, prompt, evaluated, DIAGNOSTIC_PATHS), prompt)
    pairs = _pairs(valid)
    summary: dict[str, Any] = {}
    for key, unit in AXES.items():
        by_arm = {arm: [row["target_distance"][key] for row in valid if row["arm"] == arm]
                  for arm in ("baseline", "target")}
        summary[key] = {
            "unit": unit, "target_range": targets[key],
            "mean_distance_by_arm": {arm: _mean(values) for arm, values in by_arm.items()},
            "paired_improved": sum(pair["axes"][key] == "improved" for pair in pairs),
            "paired_worsened": sum(pair["axes"][key] == "worsened" for pair in pairs),
            "paired_tied": sum(pair["axes"][key] == "tied" for pair in pairs),
        }
    secondary_summary = {}
    for key, unit in SECONDARY_AXES.items():
        if key not in secondary_targets:
            continue
        by_arm = {arm: [row["secondary_target_distance"][key] for row in valid
                        if row["arm"] == arm and row["secondary_target_distance"][key] is not None]
                  for arm in ("baseline", "target")}
        secondary_summary[key] = {
            "unit": unit, "target_range": secondary_targets[key],
            "mean_distance_by_arm": {arm: _mean(values) for arm, values in by_arm.items()},
            "paired_improved": sum(pair["secondary_axes"].get(key) == "improved" for pair in pairs),
            "paired_worsened": sum(pair["secondary_axes"].get(key) == "worsened" for pair in pairs),
            "paired_tied": sum(pair["secondary_axes"].get(key) == "tied" for pair in pairs),
            "paired_unmeasured": sum(pair["secondary_axes"].get(key) == "unmeasured" for pair in pairs),
        }
    lexical_summary = {}
    for band in lexical_targets:
        key = str(band["word"])
        by_arm = {arm: [row["lexical_target_distance"][key] for row in valid
                        if row["arm"] == arm and row["lexical_target_distance"][key] is not None]
                  for arm in ("baseline", "target")}
        lexical_summary[key] = {
            "unit": "次/千词元", "target_range": band,
            "mean_distance_by_arm": {arm: _mean(values) for arm, values in by_arm.items()},
            "paired_improved": sum(pair["lexical_axes"].get(key) == "improved" for pair in pairs),
            "paired_worsened": sum(pair["lexical_axes"].get(key) == "worsened" for pair in pairs),
            "paired_tied": sum(pair["lexical_axes"].get(key) == "tied" for pair in pairs),
            "paired_unmeasured": sum(pair["lexical_axes"].get(key) == "unmeasured" for pair in pairs),
        }
    human = _human_summary(valid)
    diagnostic_comparison = {}
    for key in DIAGNOSTIC_PATHS:
        by_arm = {
            arm: [float(row["diagnostic_observed"][key]) for row in valid if row["arm"] == arm
                  and row["diagnostic_observed"][key] is not None]
            for arm in ("baseline", "target")
        }
        paired_changes = []
        lookup = {row["blind_id"]: row for row in valid}
        for pair in pairs:
            base = lookup[pair["baseline_blind_id"]]["diagnostic_observed"][key]
            target = lookup[pair["target_blind_id"]]["diagnostic_observed"][key]
            if base is not None and target is not None:
                paired_changes.append(float(target) - float(base))
        diagnostic_comparison[key] = {
            "by_arm": {arm: {"count": len(values), "mean": _mean(values)}
                       for arm, values in by_arm.items()},
            "paired_change_count": len(paired_changes),
            "paired_mean_target_minus_baseline": _mean(paired_changes),
            "status": "exploratory-target" if key in secondary_targets else "descriptive-no-target",
        }
    copy = {arm: {"max_longest_shared_han": max((int((row.get("copy_risk") or {}).get("longest_shared_han") or 0)
                                                     for row in valid if row["arm"] == arm), default=None),
                  "mean_shared_12gram_share": _mean([float((row.get("copy_risk") or {}).get("shared_12gram_share") or 0)
                                                    for row in valid if row["arm"] == arm])}
            for arm in ("baseline", "target")}
    acceptance = _acceptance_result(experiment.get("acceptance"), summary, human, copy, len(pairs))
    result = {
        "schema": "style-report/v1", "experiment_prompt_sha256": experiment["prompt_sha256"],
        "model": experiment.get("model"), "model_version": experiment.get("model_version", "unreported"),
        "worker_version": experiment.get("worker_version"), "planned_run_count": experiment.get("planned_run_count"),
        "completed_run_count": len(valid), "paired_count": len(pairs),
        "status": "exploratory-comparison" if pairs else "unverified-generation-effect",
        "axes": summary, "secondary_axes": secondary_summary,
        "lexical_axes": lexical_summary,
        "diagnostic_comparison": diagnostic_comparison,
        "human_ratings": human, "copy_risk": copy,
        "acceptance": acceptance,
        "pairs": pairs, "runs": evaluated,
        "warnings": list(experiment.get("warnings") or []) + ([str(experiment["stopped_reason"])] if experiment.get("stopped_reason") else []),
        "interpretation": "各维度单独解释；指标靠近目标不能单独证明文学质量或内容保持。",
    }
    if experiment.get("baseline_policy"):
        result["baseline_policy"] = experiment["baseline_policy"]
    if experiment.get("baseline_prompt_sha256"):
        result["baseline_prompt_sha256"] = experiment["baseline_prompt_sha256"]
        result["baseline_prompt_artifact_sha256"] = experiment["baseline_prompt_artifact_sha256"]
    if experiment.get("target_response_format"):
        result["target_response_format"] = experiment["target_response_format"]
    return attach_report(result, prompt)


def _acceptance_result(criteria: Any, axes: dict[str, Any], human: dict[str, Any],
                       copy: dict[str, Any], pair_count: int) -> dict[str, Any] | None:
    if not isinstance(criteria, dict):
        return None
    min_pairs = int(criteria["min_pairs"])
    axis_checks = {key: (
        row["paired_improved"] >= int(criteria["min_improved_pairs_per_axis"])
        and row["mean_distance_by_arm"]["baseline"] is not None
        and row["mean_distance_by_arm"]["target"] is not None
        and row["mean_distance_by_arm"]["target"] < row["mean_distance_by_arm"]["baseline"]
    ) for key, row in axes.items()}
    human_checks: dict[str, bool | None] = {}
    min_rated = int(criteria["min_human_rated_per_arm"])
    for key in ("content_preservation_1_to_5", "naturalness_1_to_5"):
        base, target = human[key]["baseline"], human[key]["target"]
        if base["rated_count"] < min_rated or target["rated_count"] < min_rated:
            human_checks[key] = None
        else:
            human_checks[key] = bool(
                target["mean"] >= float(criteria["min_target_content_and_naturalness"])
                and target["mean"] >= base["mean"] - float(criteria["max_human_mean_drop"])
            )
    longest = copy["target"]["max_longest_shared_han"]
    copy_check = longest is not None and longest <= int(criteria["max_target_longest_shared_han"])
    if pair_count < min_pairs or any(value is None for value in human_checks.values()):
        status = "not-evaluable"
    elif all(axis_checks.values()) and all(human_checks.values()) and copy_check:
        status = "pass"
    else:
        status = "fail"
    return {"status": status, "criteria": criteria, "pair_count_sufficient": pair_count >= min_pairs,
            "axis_checks": axis_checks, "human_checks": human_checks, "copy_check": copy_check,
            "note": "预注册阶段门槛；不是显著性检验或文学质量总分。"}


def _pairs(valid: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, int], dict[str, dict[str, Any]]] = {}
    for row in valid:
        grouped.setdefault((str(row["case_id"]), int(row["repetition"])), {})[str(row["arm"])] = row
    pairs: list[dict[str, Any]] = []
    for (case_id, repetition), arms in sorted(grouped.items()):
        if set(arms) != {"baseline", "target"}:
            continue
        axes = {}
        for key in AXES:
            base = arms["baseline"]["target_distance"][key]
            target = arms["target"]["target_distance"][key]
            axes[key] = "improved" if target < base else "worsened" if target > base else "tied"
        secondary_axes = {}
        for key in arms["target"].get("secondary_target_distance", {}):
            base = arms["baseline"]["secondary_target_distance"][key]
            target = arms["target"]["secondary_target_distance"][key]
            secondary_axes[key] = ("unmeasured" if base is None or target is None else
                                   "improved" if target < base else "worsened" if target > base else "tied")
        lexical_axes = {}
        for key in arms["target"].get("lexical_target_distance", {}):
            base = arms["baseline"]["lexical_target_distance"][key]
            target = arms["target"]["lexical_target_distance"][key]
            lexical_axes[key] = ("unmeasured" if base is None or target is None else
                                 "improved" if target < base else "worsened" if target > base else "tied")
        pairs.append({"case_id": case_id, "repetition": repetition,
                      "baseline_blind_id": arms["baseline"]["blind_id"],
                      "target_blind_id": arms["target"]["blind_id"],
                      "axes": axes, "secondary_axes": secondary_axes,
                      "lexical_axes": lexical_axes})
    return pairs


def _mean(values: list[float]) -> float | None:
    return round(mean(values), 12) if values else None


def _human_summary(valid: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for field in ("style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5"):
        by_arm = {}
        for arm in ("baseline", "target"):
            scores = [int(row["human_ratings"][field]) for row in valid if row["arm"] == arm
                      and row.get("human_ratings", {}).get(field) is not None]
            by_arm[arm] = {"rated_count": len(scores), "mean": _mean(scores)}
        result[field] = by_arm
    return result


def render_markdown(report: dict[str, Any]) -> str:
    if report.get("experiment_design") == "target_only":
        from .single_arm_reporting import render
        return render(report) + render_report_extension(report)
    lines = ["# 文风调控实验报告", "", f"- 状态：`{report['status']}`",
             f"- 模型：`{report.get('model') or '未运行'}`",
             f"- 模型修订：`{report.get('model_version') or 'unreported'}`",
             f"- Worker：`{report.get('worker_version') or '未运行'}`",
             f"- 完成调用：{report['completed_run_count']}/{report['planned_run_count']}",
             f"- 有效配对：{report['paired_count']}"]
    if report.get("acceptance"):
        check = report["acceptance"]
        lines.append(f"- 预注册阶段门槛：`{check['status']}`（非显著性检验）")
    if report.get("baseline_policy"):
        lines.append(f"- 基线策略：`{report['baseline_policy']}`")
    if report.get("baseline_prompt_sha256"):
        lines.append(f"- 对照提示词 SHA-256：`{report['baseline_prompt_sha256']}`")
    if report.get("target_response_format"):
        lines.append(f"- 目标组交付格式：`{report['target_response_format']}`；指标只按组装后的正文计算")
    lines.extend(["", "## 可测目标", "",
                  "| 维度 | 目标范围 | 基线平均距离 | 调控平均距离 | 配对改善/恶化/持平 |",
                  "| --- | --- | ---: | ---: | ---: |"])
    for key, row in report["axes"].items():
        band = row["target_range"]
        averages = row["mean_distance_by_arm"]
        lines.append(f"| `{key}` | {band['min']:g}–{band['max']:g} {row['unit']} | "
                     f"{_display(averages['baseline'])} | {_display(averages['target'])} | "
                     f"{row['paired_improved']}/{row['paired_worsened']}/{row['paired_tied']} |")
    if report.get("secondary_axes"):
        lines.extend(["", "## 次级可测目标（探索性）", "",
                      "这些目标有相同的配对距离计算，但不计入原四轴阶段门槛。", "",
                      "| 维度 | 目标范围 | 基线平均距离 | 调控平均距离 | 配对改善/恶化/持平/无法测量 |",
                      "| --- | --- | ---: | ---: | ---: |"])
        for key, row in report["secondary_axes"].items():
            band = row["target_range"]
            averages = row["mean_distance_by_arm"]
            lines.append(f"| `{key}` | {band['min']:g}–{band['max']:g} {row['unit']} | "
                         f"{_display(averages['baseline'])} | {_display(averages['target'])} | "
                         f"{row['paired_improved']}/{row['paired_worsened']}/"
                         f"{row['paired_tied']}/{row['paired_unmeasured']} |")
    if report.get("lexical_axes"):
        lines.extend(["", "## 高频语法词目标（探索性）", "",
                      "只统计自动标为功能类词性的汉语词元；短文本波动及题材影响需要单独审查。", "",
                      "| 词 | 目标/千词元 | 基线平均距离 | 调控平均距离 | 配对改善/恶化/持平/无法测量 |",
                      "| --- | ---: | ---: | ---: | ---: |"])
        for key, row in report["lexical_axes"].items():
            band = row["target_range"]
            averages = row["mean_distance_by_arm"]
            lines.append(f"| {key} | {band['min']:g}–{band['max']:g} | "
                         f"{_display(averages['baseline'])} | {_display(averages['target'])} | "
                         f"{row['paired_improved']}/{row['paired_worsened']}/"
                         f"{row['paired_tied']}/{row['paired_unmeasured']} |")
    lines.extend(["", "## 扩展诊断变化", "",
                  "只有上节列出的次级指标设置了探索性目标；其余诊断不预设改善方向。", "",
                  "| 指标 | 基线样本/均值 | 调控样本/均值 | 配对平均变化 |",
                  "| --- | ---: | ---: | ---: |"])
    for key, row in report["diagnostic_comparison"].items():
        base, target = row["by_arm"]["baseline"], row["by_arm"]["target"]
        lines.append(f"| `{key}` | {base['count']} / {_display(base['mean'])} | "
                     f"{target['count']} / {_display(target['mean'])} | "
                     f"{_display(row['paired_mean_target_minus_baseline'])} |")
    lines.extend(["", "## 人工盲评", "", "| 维度 | 基线已评/平均 | 调控已评/平均 |",
                  "| --- | ---: | ---: |"])
    for key, values in report["human_ratings"].items():
        base, target = values["baseline"], values["target"]
        lines.append(f"| `{key}` | {base['rated_count']} / {_display(base['mean'])} | "
                     f"{target['rated_count']} / {_display(target['mean'])} |")
    lines.extend(["", "## 参考文本复写风险", "", "| 方案 | 最高连续共享汉字 | 平均共享 12 字窗口比例 |",
                  "| --- | ---: | ---: |"])
    for arm, row in report["copy_risk"].items():
        lines.append(f"| {arm} | {_display(row['max_longest_shared_han'])} | "
                     f"{_display(row['mean_shared_12gram_share'])} |")
    lines.extend(["", "## 逐篇结果", "", "| 盲号 | 场景 | 轮次 | 方案 | 状态 | 汉字数 | 句长 | 段长 | 对白占比 | 标点/千字 |",
                  "| --- | --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: |"])
    for row in report["runs"]:
        observed = row.get("observed") or {}
        lines.append(f"| {row.get('blind_id')} | {row.get('case_id')} | {row.get('repetition')} | {row.get('arm')} | {row['status']} | "
                     f"{row.get('han_count', '—')} | {_display(observed.get('sentence_length_han'))} | "
                     f"{_display(observed.get('paragraph_length_han'))} | {_display(observed.get('dialogue_share'))} | "
                     f"{_display(observed.get('punctuation_per_1000_han'))} |")
    if any(row.get("normalization_evidence") for row in report["runs"]):
        lines.extend(["", "## 实际长度归一化核算", "",
                      "各篇均按自身汉字、句、段或词元数作分母；目标范围对应的原始计数随实际分母变化。MATTR50 始终用完整 50 词窗，不按全文篇幅乘除。逐项分子、分母和换算范围见报告 JSON。", "",
                      "| 盲号 | 汉字 | 句 | 段 | 词元 | 对白汉字 | 标点处 | 引号片段 | MATTR50 完整词窗 |",
                      "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"])
        for row in report["runs"]:
            evidence = row.get("normalization_evidence")
            if not evidence:
                continue
            sample = evidence["sample"]
            primary = evidence["primary"]
            quote = evidence["secondary"].get("quote_spans_per_1000_han") or {}
            mattr = evidence["secondary"].get("word_mattr_50") or {}
            lines.append(f"| {row['blind_id']} | {sample['han_count']} | {sample['sentence_count']} | "
                         f"{sample['paragraph_count']} | {sample['word_token_count']} | "
                         f"{primary['dialogue_share']['numerator']} | "
                         f"{primary['punctuation_per_1000_han']['numerator']} | "
                         f"{_display(quote.get('numerator'))} | "
                         f"{_display(mattr.get('complete_window_count'))} |")
    if report["warnings"]:
        lines.extend(["", "## 限制与警告", ""] + [f"- {warning}" for warning in report["warnings"]])
    lines.extend(["", report["interpretation"], ""])
    return "\n".join(lines) + render_report_extension(report)


def _display(value: object) -> str:
    return "未评" if value is None else str(value)

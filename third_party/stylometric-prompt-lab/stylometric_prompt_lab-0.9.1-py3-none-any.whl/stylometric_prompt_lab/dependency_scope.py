"""Conditional paragraph scope budgets from full, verified dependency feedback."""
from __future__ import annotations

from fractions import Fraction
from itertools import combinations
import json
import re

from .construction_budget import actual, entry, integer_interval, validate_joint
from .dependency_edit import render_sparse
from .dependency_feedback import fraction, sha
from .dependency_metrics import analyze_dependencies
from .io import ContractError, digest
from .local_edit import apply_response, paragraph_index
from .metrics import measure
from .extended_metrics import extended_statistics
from .reporting import normalization_evidence

SCHEMA = 'style-tree-edit-scope/v1'
VERSION = '0.1.0'
NONADDITIVE = ('word_mattr_50',)


def paragraph_rows(base):
    text, parsed = base['initial_text'], base['initial_parse']
    analysis = analyze_dependencies(parsed)
    lines, starts, offset = text.splitlines(keepends=True), [], 0
    for line in lines:
        starts.append(offset)
        offset += len(line)
    rows, assigned = [], []
    for para in paragraph_index(text):
        start = starts[para['line_offset']]
        end = start + len(lines[para['line_offset']])
        pairs = [(s, a) for s, a in zip(parsed['sentences'], analysis['sentences'])
                 if start <= s['start'] and s['end'] <= end]
        ids = [s['id'] for s, _ in pairs]
        assigned += ids
        evidence = normalization_evidence(measure(para['text']), extended_statistics(para['text']),
            base['prompt']['targets'], base['prompt']['secondary_targets'], base['prompt']['lexical_targets'])
        counts = {f'{group}:{key}': value for group in ('primary', 'secondary', 'lexical')
                  for key, value in evidence[group].items() if key not in NONADDITIVE}
        counts['dependency:mhd'] = {'numerator': sum(a['metrics']['mhd']['numerator'] for _, a in pairs),
                                   'denominator': sum(a['metrics']['mhd']['denominator'] for _, a in pairs), 'scale': 1}
        rows.append({**para, 'start': start, 'end': end, 'sentence_ids': ids,
                     'han_count': measure(para['text'])['han_count'], 'counts': counts})
    if assigned != [s['id'] for s in parsed['sentences']]:
        raise ContractError('scope requires every real sentence wholly in one indexed paragraph')
    for item in base['metric_inventory']:
        if item['key'] in NONADDITIVE:
            continue
        key = f"{item['group']}:{item['key']}"
        if key not in rows[0]['counts']:
            raise ContractError('scope v1 supports the selected MHD dependency target only')
        for field in ('numerator', 'denominator'):
            if sum(row['counts'][key][field] for row in rows) != item['basis'][field]:
                raise ContractError(f'paragraph additive count closure failed: {key}:{field}')
    return rows


def measured_cap(joint):
    values = [actual(entry(row['embedded'], 'dependency', 'mhd')['basis'])
              for row in joint['construction_measurements'] if row['pair_id'] in joint['selected_pairs']]
    if not values:
        raise ContractError('scope needs selected, measured MHD constructions')
    return max(values)


def choose_scope(rows, inventory, cap):
    if not 1 <= len(rows) <= 20:
        raise ContractError('exact scope search supports 1..20 original paragraphs, without truncation')
    mhd = next(r for r in inventory if r['group'] == 'dependency' and r['key'] == 'mhd')
    quote = next(r for r in inventory if r['key'] == 'quote_spans_per_1000_han')
    target_depth = integer_interval(mhd['target'], mhd['basis']['denominator'], 1)['min']
    quote_max = integer_interval(quote['target'], quote['basis']['denominator'], 1000)['max']
    needed_gain = cap.denominator * (target_depth - mhd['basis']['numerator'])
    gains = [cap.numerator*r['counts']['dependency:mhd']['denominator']
             - cap.denominator*r['counts']['dependency:mhd']['numerator'] for r in rows]
    quotes = [r['counts']['secondary:quote_spans_per_1000_han']['numerator'] for r in rows]
    candidates_by_size = []
    for size in range(1, len(rows) + 1):
        best, count = None, 0
        for indices in combinations(range(len(rows)), size):
            gain, removed = sum(gains[i] for i in indices), sum(quotes[i] for i in indices)
            if gain < needed_gain or quote['basis']['numerator'] - removed > quote_max:
                continue
            count += 1
            score = (sum(rows[i]['han_count'] for i in indices), -removed, indices)
            if best is None or score < best:
                best = score
        candidates_by_size.append({'paragraph_count': size, 'conditionally_feasible_scopes': count})
        if best is not None:
            return [rows[i]['paragraph_id'] for i in best[2]], candidates_by_size
    raise ContractError('no scope meets fixed-count MHD/quote scenario; this is not a universal impossibility')


def scoped_constraints(rows, inventory, selected):
    kept = [row for row in rows if row['paragraph_id'] not in selected]
    result = []
    for item in inventory:
        if item['key'] in NONADDITIVE:
            continue
        key, b = f"{item['group']}:{item['key']}", item['basis']
        kn = sum(row['counts'][key]['numerator'] for row in kept)
        kd = sum(row['counts'][key]['denominator'] for row in kept)
        bounds = integer_interval(item['target'], b['denominator'], b['scale'])
        lower, upper = max(0, bounds['min'] - kn), bounds['max'] - kn
        result.append({'group': item['group'], 'key': item['key'], 'target': item['target'],
                       'scale': b['scale'], 'kept_numerator': kn, 'kept_denominator': kd,
                       'original_edit_numerator': b['numerator']-kn, 'original_edit_denominator': b['denominator']-kd,
                       'replacement_numerator_interval_at_original_denominator':
                           {'min': lower, 'max': upper, 'attainable': lower <= upper},
                       'whole_original_denominator': b['denominator'],
                       'actual_rule': 'min*(kept_d+new_d)<=scale*(kept_n+new_n)<=max*(kept_d+new_d)'})
    return result


def render_scope(joint, rows, selected, scoped, cap):
    sparse, omitted = render_sparse(joint, rows, len(selected))
    lines = [sparse, '## 冻结可编辑范围与剩余计数',
             f"只允许替换原段落{','.join(map(str, selected))}；最多{len(selected)}项。范围外原文逐字保留。",
             '这里按未编辑原段的实测贡献，给出需由替换段承担的计数。所有18项仍适用，不能只改五项偏差。',
             '下表假设全文各项分母保持源稿大小，仅作可编辑范围估算；实际分母可变化，工具按完整新稿精确重测。',
             f'范围选择使用已实测结构的最大MHD={cap.numerator}/{cap.denominator}，不是汉语树深上界或效果保证。',
             '| 指标 | 保留段贡献n/d | 原编辑段n/d | 固定原全篇分母下替换段所需分子 |',
             '| --- | --- | --- | --- |']
    for row in scoped:
        v = row['replacement_numerator_interval_at_original_denominator']
        lines.append(f"| {row['group']}:{row['key']} | {row['kept_numerator']}/{row['kept_denominator']} | "
                     f"{row['original_edit_numerator']}/{row['original_edit_denominator']} | {v['min']}–{v['max']} |")
    lines += ['MATTR50不在此可加表；必须按修订全文的完整滑窗重测，不平均段落MATTR。',
              '保持需要的直接对白汉字，但合并同一次发言的碎片引号；不要通过大量新对白冲淡密度。',
              '将部分≤20汉字的浅短句改为内容所需的21–30汉字关系句，保留13–19汉字全文均值和长句比例。',
              '优先让已有动作的使令、转交、先后关系嵌入句法，不新增人物或事件。避免靠堆“的”及重复句套增加树深。',
              '平均词长还略低；语义准确地用双音节词替换单音节词，新增“把”须与词长、功能词和名动形比例共同核对。',
              '只返回同一JSON补丁格式，不输出以上估算、解释、思考过程或自评。', '']
    return '\n'.join(lines), omitted


def prepare_scope(joint, corpus):
    validate_joint(joint, corpus)
    base = joint['base_feedback_plan']
    if set(base['prompt']['dependency_targets']) != {'mhd'}:
        raise ContractError('scope v1 requires exactly the MHD dependency target')
    rows, cap = paragraph_rows(base), measured_cap(joint)
    selected, search = choose_scope(rows, base['metric_inventory'], cap)
    scoped = scoped_constraints(rows, base['metric_inventory'], selected)
    instruction, omitted = render_scope(joint, rows, selected, scoped, cap)
    result = {'schema': SCHEMA, 'version': VERSION, 'joint_guidance': joint,
              'paragraphs': rows, 'allowed_paragraph_ids': selected, 'max_paragraphs': len(selected),
              'scope_search': search, 'scoped_constraints': scoped, 'measured_construction_cap': fraction(cap),
              'selection': 'smallest paragraph count satisfying fixed-count MHD/quote scenario; then smallest edited Han, most removed quotes, lexicographic ids',
              'scope_assumptions': 'original complete denominators; unchanged unedited sentences; selected example max MHD; not a general reachability claim',
              'nonadditive_metrics': list(NONADDITIVE), 'input_text': instruction, 'input_sha256': sha(instruction),
              'omitted_parent_delivery_lines': omitted, 'web_modes': joint['web_modes'],
              'experiment_design': 'target_only', 'quality_status': 'unverified', 'length_in_gate': False}
    result['scope_plan_sha256'] = digest(result)
    return result


def validate_scope(plan, corpus):
    if plan.get('schema') != SCHEMA or plan.get('scope_plan_sha256') != digest({k:v for k,v in plan.items() if k != 'scope_plan_sha256'}):
        raise ContractError('scope schema/hash differs')
    if prepare_scope(plan['joint_guidance'], corpus) != plan:
        raise ContractError('scope differs from real counts, conditional search or all-target guidance')


def apply_scope(plan, response, corpus):
    validate_scope(plan, corpus)
    payload = response.strip()
    match = re.fullmatch(r'```(?:json)?\s*\n(.*)\n```', payload, re.S)
    if match:
        payload = match.group(1).strip()
    candidate = apply_response(plan['joint_guidance']['base_feedback_plan']['initial_text'], payload,
                               max_paragraphs=plan['max_paragraphs'], allowed_paragraph_ids=plan['allowed_paragraph_ids'])
    patches = json.loads(payload)['patches']
    record = {'schema': 'style-tree-scope-import/v1', 'scope_plan_sha256': plan['scope_plan_sha256'],
              'raw_response_sha256': sha(response), 'payload_sha256': sha(payload), 'fence_removed': bool(match),
              'paragraph_ids': [r['paragraph_id'] for r in patches], 'patch_count': len(patches),
              'candidate_text_sha256': sha(candidate), 'unedited_original_lines_preserved': True,
              'assessment_status': 'requires_fresh_complete_parse'}
    record['import_sha256'] = digest(record)
    return candidate, record

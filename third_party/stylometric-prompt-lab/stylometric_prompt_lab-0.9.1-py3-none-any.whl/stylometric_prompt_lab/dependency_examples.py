"""Experimental prompt guidance from recomputed real construction examples."""
from __future__ import annotations

from decimal import Decimal
import hashlib
import math

from .dependency_metrics import analyze_dependencies
from .dependency_targets import AXES
from .io import ContractError, digest


def validate_library(library: dict, measurement: dict) -> list[dict]:
    if library.get("schema") != "style-dependency-examples/v1" or library.get("library_sha256") != digest(
            {key: value for key, value in library.items() if key != "library_sha256"}):
        raise ContractError("dependency example library hash/schema differs")
    expected_model = measurement["model_manifest_hash"]
    if library.get("model_manifest_hash") != expected_model:
        raise ContractError("dependency examples use a different model")
    source = {row["id"]: row for row in library["manifest"]["pairs"]}
    if not library.get("pairs") or len(source) != len(library["pairs"]):
        raise ContractError("dependency example pairs are missing or duplicated")
    seen = set()
    for pair in library["pairs"]:
        if pair["id"] in seen or pair["id"] not in source or pair["facts"] != source[pair["id"]]["facts"]:
            raise ContractError("dependency pair identity or declared facts differ")
        seen.add(pair["id"])
        for kind in ("separate", "embedded"):
            row = pair[kind]
            parsed = row["parsed"]
            result = analyze_dependencies(parsed)
            if (row["text"] != source[pair["id"]][kind] or parsed["text"] != row["text"]
                    or row["metrics"] != result["summary"]["metrics"] or row["analysis_hash"] != result["analysis_hash"]):
                raise ContractError("dependency example text or recomputed metrics differ")
            if (parsed["annotation_scheme"] != measurement["annotation_scheme"] or
                    parsed["annotator"]["model_manifest_hash"] != expected_model):
                raise ContractError("dependency example model/annotation differs from prompt")
    return sorted(library["pairs"], key=lambda row: row["id"])


def choose_examples(pairs: list[dict], key: str, band: dict) -> list[dict]:
    if key not in AXES or band.get("unit") != AXES[key][1]:
        raise ContractError("unknown dependency axis/unit for examples")
    if any(type(band.get(name)) not in (int, float) or not math.isfinite(band[name]) for name in ("min", "max")):
        raise ContractError("example target bounds must be finite numbers")
    if not AXES[key][2] <= band["min"] <= band["max"] <= AXES[key][3]:
        raise ContractError("example target bounds exceed the axis definition")
    low, high = Decimal(str(band["min"])), Decimal(str(band["max"]))
    selected = []
    for pair in pairs:
        for kind in ("separate", "embedded"):
            value = pair[kind]["metrics"][key]
            if value["denominator"] and low <= Decimal(value["numerator"]) / value["denominator"] <= high:
                other = "embedded" if kind == "separate" else "separate"
                second = pair[other]["metrics"][key]
                if second["denominator"] and not low <= Decimal(second["numerator"]) / second["denominator"] <= high:
                    selected.append({"pair_id": pair["id"], "kind": kind, "selected": pair[kind], "other": pair[other]})
                    break
        if len(selected) == 3:
            break
    if not selected:
        raise ContractError(f"no real contrasted construction example inside target range for {key}")
    return selected


def deepest_chain(parsed: dict) -> str:
    result = analyze_dependencies(parsed)
    sentence = max(result["sentences"], key=lambda row: row["metrics"]["max_tree_depth"] or 0)
    source = next(row for row in parsed["sentences"] if row["id"] == sentence["sentence_id"])
    tokens = {row["id"]: row for row in source["tokens"]}
    depth = max((row for row in sentence["tree_depths"] if not row["punctuation"]), key=lambda row: row["depth"])
    chain, token_id = [], depth["id"]
    while token_id:
        token = tokens[token_id]
        chain.append(f"{token['form']}[{token['relation']}]")
        token_id = token["head"]
    return " → ".join(chain + ["ROOT"])


def compile_examples(prompt: dict, library: dict) -> dict:
    if prompt.get("schema") != "literary-style-prompt/v1" or prompt.get("prompt_artifact_sha256") != digest(
            {key: value for key, value in prompt.items() if key != "prompt_artifact_sha256"}):
        raise ContractError("base prompt artifact hash/schema differs")
    if hashlib.sha256(prompt["prompt_markdown"].encode()).hexdigest() != prompt["prompt_sha256"]:
        raise ContractError("base prompt text hash differs")
    if prompt.get("compiler_version") != "0.15.0" or not prompt.get("dependency_targets"):
        raise ContractError("compile-examples needs an explicit version 0.15.0 dependency target prompt")
    pairs = validate_library(library, prompt["dependency_measurement"])
    selected = {key: choose_examples(pairs, key, band) for key, band in prompt["dependency_targets"].items()}
    markdown = prompt["prompt_markdown"] + render_examples(selected)
    result = {key: value for key, value in prompt.items() if key != "prompt_artifact_sha256"}
    result.update(compiler_version="0.16.0", parent_prompt_sha256=prompt["prompt_sha256"],
                  dependency_example_compiler_version="0.1.0", dependency_example_library_sha256=library["library_sha256"],
                  dependency_example_selection={key: [{"pair_id": row["pair_id"], "kind": row["kind"],
                                                       "parse_hash": row["selected"]["parsed"]["parse_hash"]} for row in rows]
                                                for key, rows in selected.items()},
                  prompt_markdown=markdown, prompt_sha256=hashlib.sha256(markdown.encode()).hexdigest())
    result["warnings"] = [*prompt["warnings"], "句式范例是人工构造、模型实测的校准样本；语义等价和文风控制未独立验证。"]
    result["prompt_artifact_sha256"] = digest(result)
    return result


def render_examples(selected: dict) -> str:
    lines = ["", "## 用实测句式组织结构", "",
             "在保持前述全部句段、对白、词性、MATTR与词频目标的同时，用下面的结构差异安排句子。",
             "范例仅展示结构，不把范例的物件、人物或新事实加入正文，也不要重复范例原句。",
             "每个值由同一LTP标注器对例句实测，不代表这种写法总会产生相同数值。", ""]
    for key, rows in selected.items():
        lines.append(f"### {AXES[key][0]}")
        for row in rows:
            chosen, other = row["selected"], row["other"]
            for label, example in (("对照结构", other), ("本次范围内结构", chosen)):
                value = example["metrics"][key]
                lines.append(f"- {label}：{example['text']} 实测{value['numerator']}/{value['denominator']}="
                             f"{value['value']:.6f} {AXES[key][1]}。")
            lines.append("  范围内句子的最长实测父链：" + deepest_chain(chosen["parsed"]) + "。")
        lines += ["", "学习词如何通过中间词连接到主干，分散使用多种合适结构；不是要求每句复用同一个修饰链。"]
    lines += ["", "完整表达事件后，再核对前述所有目标；不靠添无关限定、重复动作或删事实改变统计。",
              "只输出完整叙事正文；不输出范例、句法标注、计算过程或自评。", ""]
    return "\n".join(lines)


def add_commands(commands, path_type):
    command = commands.add_parser("compile-examples", help="实验0.16.0：给依存目标提示词加入实测句式范例")
    command.add_argument("--prompt", type=path_type, required=True)
    command.add_argument("--library", type=path_type, required=True)
    command.add_argument("--out", type=path_type, required=True)


def run_command(args):
    from .io import read_object, write_object, write_text
    if (args.out / "prompt.json").exists() or (args.out / "prompt.md").exists():
        raise ContractError("example prompt output already exists")
    result = compile_examples(read_object(args.prompt, "literary-style-prompt/v1"),
                              read_object(args.library, "style-dependency-examples/v1"))
    write_object(args.out / "prompt.json", result)
    write_text(args.out / "prompt.md", result["prompt_markdown"])
    print(f"实验提示词：{args.out / 'prompt.md'}")
    return 0

"""Exploratory complete finite-pool ranking; no quality score or unseen-text guarantee."""
from fractions import Fraction
from itertools import product

from .dependency_feedback import actual, gap, sha
from .dependency_variants import validate_variant_library
from .io import digest
from .tree_candidate_selection import assess_choice


def pool_choices(library):
    grouped={}
    for row in library['candidates']:
        grouped.setdefault(row['paragraph_id'],{}).setdefault(row['text_sha256'],row)
    fixed={k:next(iter(v.values())) for k,v in grouped.items() if len(v)==1}
    varying=[(k,list(v.values())) for k,v in sorted(grouped.items()) if len(v)>1]
    return fixed,varying


def additive_table(rows,specs):
    return [(sum(r['counts'][f"{s['group']}:{s['key']}"]['numerator'] for r in rows),
             sum(r['counts'][f"{s['group']}:{s['key']}"]['denominator'] for r in rows)) for s in specs]


def nonworse(indices,options,constant,specs,before):
    for j,s in enumerate(specs):
        n=constant[j][0]+sum(options[i][v][j][0] for i,v in enumerate(indices))
        d=constant[j][1]+sum(options[i][v][j][1] for i,v in enumerate(indices))
        if d<=0 or gap(Fraction(n*s['basis']['scale'],d),s['target'])>before[j]:
            return False
    return True


def rank(candidate):
    gaps=[]
    for r in candidate['metric_inventory']:
        value=Fraction(r['distance_exact']['numerator'],r['distance_exact']['denominator'])
        width=Fraction(str(r['target']['max']))-Fraction(str(r['target']['min']))
        gaps.append(value/max(width,Fraction(1,1000)))
    return (len(gaps)-candidate['provisional_hits'],max(gaps),sum(gaps),
            tuple(candidate['selected_candidate_ids'].values()))


def explore_pool(library,corpus):
    validate_variant_library(library,corpus)
    scope=library['plan']['scope'];base={**scope['joint_guidance']['base_feedback_plan'],'paragraphs':scope['paragraphs']}
    specs=[r for r in base['metric_inventory'] if r['key']!='word_mattr_50']
    specs.sort(key=lambda r:(r['group']!='dependency',r['group'],r['key']))
    fixed,varying=pool_choices(library);constant=additive_table(fixed.values(),specs)
    options=[[additive_table([r],specs) for r in rows] for _,rows in varying]
    before=[gap(actual(s['basis']),s['target']) for s in specs]
    state={'base':base,'allowed':scope['allowed_paragraph_ids'],'mode':'all_nonworse',
           'missing_full_measurement':0,'full_mattr_or_precision_rejected':0}
    candidates=[];enumerated=0;additive_nonworse=0
    for indices in product(*(range(len(v)) for v in options)):
        enumerated+=1
        if not nonworse(indices,options,constant,specs,before):continue
        additive_nonworse+=1;chosen=dict(fixed)
        chosen.update({key:rows[indices[i]] for i,(key,rows) in enumerate(varying)})
        candidate=assess_choice(state,chosen)
        if candidate:candidates.append(candidate)
    selected=min(candidates,key=rank) if candidates else None
    result={'schema':'style-tree-pool-exploration/v1','version':'0.1.0','library_sha256':library['library_sha256'],
            'design':'retrospective_exploratory_complete_finite_pool','enumerated_combinations':enumerated,
            'additive_nonworse_count':additive_nonworse,'actual_full_mattr_nonworse_and_strict_gain_count':len(candidates),
            'candidates':candidates,'selected':selected,'requires_fresh_complete_parse':True,
            'rule':'fewest original target misses, minimum largest and sum width-normalized exact gaps, deterministic candidate IDs; no quality score',
            'proof_scope':'finite cached paragraph-tree pool; actual whole-text MATTR and legacy counts; final real tree may differ',
            'quality_status':'unverified','additional_model_calls':0}
    result['exploration_sha256']=digest(result)
    return result

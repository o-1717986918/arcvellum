"""Style-first audit: length is descriptive, never an acceptance condition."""

from __future__ import annotations

import math
from typing import Any

from .candidate_selection import SYNTAX_PROXIES
from .io import ContractError, digest
from .dependency_targets import attach_audit


SCHEMA = "style-first-audit/v1"
HUMAN_FIELDS = ("style_fit_1_to_5", "content_preservation_1_to_5", "naturalness_1_to_5")


def audit(report: dict[str, Any], prompt: dict[str, Any], *, min_pairs: int = 6) -> dict[str, Any]:
    if report.get("schema") != "style-report/v1" or prompt.get("schema") != "literary-style-prompt/v1":
        raise ContractError("style audit needs a report and literary prompt")
    if report.get("experiment_prompt_sha256") != prompt.get("prompt_sha256"):
        raise ContractError("report and style prompt hashes differ")
    if min_pairs < 1:
        raise ContractError("min_pairs must be positive")
    pairs = int(report["paired_count"])
    rows = [row for row in report["runs"] if row.get("arm") == "target" and row.get("status") == "completed"]
    target_only = report.get("experiment_design") == "target_only"
    sample_size = len(rows) if target_only else pairs
    required_hits = math.ceil(2 * min_pairs / 3)

    def summarize(keys: list[str], distance_field: str) -> dict[str, dict[str, int]]:
        return {key: {"target_in_range": sum(row.get(distance_field, {}).get(key) == 0 for row in rows),
                      "target_measured": sum(row.get(distance_field, {}).get(key) is not None for row in rows)}
                for key in keys}

    primary = summarize(list(prompt["targets"]), "target_distance")
    secondary_targets = prompt.get("secondary_targets") or {}
    syntax_keys = [key for key in SYNTAX_PROXIES if key in secondary_targets]
    other_keys = [key for key in secondary_targets if key not in SYNTAX_PROXIES]
    syntax = summarize(syntax_keys, "secondary_target_distance")
    other = summarize(other_keys, "secondary_target_distance")
    lexical = summarize([str(item["word"]) for item in prompt.get("lexical_targets") or []],
                        "lexical_target_distance")
    primary_joint = sum(all(row["target_distance"].get(key) == 0 for key in primary) for row in rows)
    all_joint = sum((all(row.get("target_distance", {}).get(key) == 0 for key in primary) and
                     all(row.get("secondary_target_distance", {}).get(key) == 0 for key in syntax | other) and
                     all(row.get("lexical_target_distance", {}).get(key) == 0 for key in lexical))
                    for row in rows)
    metric_checks = {"primary_joint": primary_joint >= required_hits,
                     "each_primary": all(item["target_in_range"] >= required_hits for item in primary.values()),
                     "each_syntax_proxy": all(item["target_in_range"] >= required_hits for item in syntax.values()),
                     "each_other_secondary": all(item["target_in_range"] >= required_hits for item in other.values()),
                     "each_lexical": all(item["target_in_range"] >= required_hits for item in lexical.values())}
    if target_only:
        metric_checks["all_targets_joint"] = all_joint >= required_hits
    metric_status = ("not-evaluable" if sample_size < min_pairs else
                     "pass" if all(metric_checks.values()) else "fail")
    human = report.get("human_ratings") or {}
    human_checks: dict[str, bool | None] = {}
    for key in HUMAN_FIELDS:
        arms = human.get(key) or {}
        target, base = arms.get("target") or {}, arms.get("baseline") or {}
        if target_only:
            human_checks[key] = None if (target.get("rated_count") or 0) < min_pairs else target["mean"] >= 4.0
        elif min(target.get("rated_count") or 0, base.get("rated_count") or 0) < min_pairs:
            human_checks[key] = None
        else:
            human_checks[key] = bool(target["mean"] >= 4.0 and target["mean"] >= base["mean"] - 0.5)
    overall = ("fail" if metric_status == "fail" or any(value is False for value in human_checks.values()) else
               "pass" if metric_status == "pass" and all(value is True for value in human_checks.values()) else
               "not-evaluable")
    bounds = prompt.get("derived_structure") or {}
    lower, upper = bounds.get("min_han"), bounds.get("max_han")
    length_hits = (sum(lower <= row["han_count"] <= upper for row in rows)
                   if lower is not None and upper is not None else None)
    result = {"schema": SCHEMA, "objective": "style_first", "report_sha256": digest(report),
              "prompt_sha256": prompt["prompt_sha256"], "pair_count": pairs,
              "min_pairs": min_pairs, "required_target_hits_per_metric": required_hits,
              "primary": primary, "syntax_proxies": syntax, "other_secondary": other,
              "lexical": lexical, "target_primary_joint": primary_joint,
              "target_all_measured_joint": all_joint, "metric_checks": metric_checks,
              "metric_status": metric_status, "human_checks": human_checks,
              "overall_status": overall,
              "length_descriptive": {"target_in_prompt_band": length_hits,
                                     "target_completed": len(rows), "counts_as_gate": False},
              "note": "句法指标是标点与自动词性代理；文学风格仍须独立匿名审读。"}
    if target_only:
        result.pop("pair_count")
        result.pop("min_pairs")
        result.update(experiment_design="target_only", target_sample_count=sample_size,
                      min_target_samples=min_pairs)
    attach_audit(result, report, prompt, min_pairs)
    result["audit_sha256"] = digest(result)
    return result


def render_audit(value: dict[str, Any]) -> str:
    if value.get("schema") != SCHEMA or value.get("audit_sha256") != digest({
            key: row for key, row in value.items() if key != "audit_sha256"}):
        raise ContractError("style audit hash or schema is invalid")
    lines = ["# 文风优先验收审计", "", f"- 指标门槛：`{value['metric_status']}`",
             f"- 含人工审读的整体状态：`{value['overall_status']}`",
             (f"- 参数组可测样本：{value['target_sample_count']}；" if value.get("experiment_design") == "target_only" else
              f"- 有效配对：{value['pair_count']}；") + f"每项至少需 {value['required_target_hits_per_metric']} 篇命中。",
             f"- 四主轴共同命中：{value['target_primary_joint']} 篇；所有已设指标共同命中："
             f"{value['target_all_measured_joint']} 篇。", "",
             "| 指标组 | 指标 | 目标组命中 / 可测 |", "| --- | --- | ---: |"]
    for group, label in (("primary", "四主轴"), ("syntax_proxies", "句法代理"),
                         ("other_secondary", "其他次级"), ("lexical", "高频词"), ("dependency_axes", "依存句法")):
        for key, row in value.get(group, {}).items():
            lines.append(f"| {label} | `{key}` | {row['target_in_range']}/{row['target_measured']} |")
    length = value["length_descriptive"]
    lines.extend(["", f"篇幅：{length['target_in_prompt_band']} 篇处于旧提示词区间"
                  if length["target_in_prompt_band"] is not None else "篇幅：仅记录实际汉字数；提示词不设区间",
                  "篇幅不参加排序或验收。句法代理不等于句法树分析；风格、内容与自然度需独立匿名审读。", ""])
    return "\n".join(lines)
